<?php
// Ambil foto profil langsung dari database
$profilePicture = '';

if (isset($_SESSION['user']['id']) && isset($conn)) {

    $navbar_user_id = (int) $_SESSION['user']['id'];

    $navbar_stmt = mysqli_prepare(
        $conn,
        "SELECT profile_picture FROM users WHERE id = ? LIMIT 1"
    );

    if ($navbar_stmt) {
        mysqli_stmt_bind_param($navbar_stmt, "i", $navbar_user_id);
        mysqli_stmt_execute($navbar_stmt);

        $navbar_result = mysqli_stmt_get_result($navbar_stmt);
        $navbar_data = mysqli_fetch_assoc($navbar_result);

        $profilePicture = $navbar_data['profile_picture'] ?? '';

        mysqli_stmt_close($navbar_stmt);
    }
}

if (isset($_SESSION['user'])) {
    $_SESSION['user']['profile_picture'] = $profilePicture;
}
?>

<div class="promo-bar">
    Read Book, and get
    <span>10% OFF</span>
    for all books
</div>

<nav>
    <div class="container navbar">

        <h2 class="logo">BOOKISSE</h2>

        <form class="search" action="/Bookisse/index.php" method="GET">
    <input
        type="text"
        name="search"
        placeholder="Search Book..."
        value="<?= htmlspecialchars($_GET['search'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" >
      </form>
        <div class="menu">

            <!-- WISHLIST -->
            <?php if (isset($_SESSION['user'])): ?>
                <a href="/Bookisse/pages/wishlist.php"
                   aria-label="My Wishlist"
                   title="Wishlist">
                    <i class="fa-regular fa-heart"></i>
                </a>
            <?php else: ?>
                <a href="/Bookisse/pages/login.php"
                   aria-label="Wishlist"
                   title="Login to access Wishlist">
                    <i class="fa-regular fa-heart"></i>
                </a>
            <?php endif; ?>

            <!-- CART -->
            <a href="/Bookisse/pages/cart.php">
                <i class="fa-solid fa-cart-shopping"></i>
            </a>

            <!-- PROFILE -->
            <?php if (isset($_SESSION['user'])): ?>

                <a href="/Bookisse/pages/profile.php"
                   class="navbar-profile"
                   aria-label="My Profile">

                    <?php
                    $photo_file = __DIR__ . '/../' . $profilePicture;
                    ?>

                    <?php if (
                        !empty($profilePicture) &&
                        is_file($photo_file)
                    ): ?>

                        <img
                            src="/Bookisse/<?= htmlspecialchars($profilePicture, ENT_QUOTES, 'UTF-8'); ?>"
                            alt="Profile"
                            class="navbar-avatar">

                    <?php else: ?>

                        <i class="fa-solid fa-user"></i>

                    <?php endif; ?>

                </a>

            <?php else: ?>

                <a href="/Bookisse/pages/login.php">
                    <i class="fa-solid fa-user"></i>
                </a>

            <?php endif; ?>

            <a href="/Bookisse/pages/about.php"
                title="About Us"
              aria-label="About Us">
             <i class="fa-solid fa-circle-info"></i>
              </a>
        </div>
    </div>
</nav>

<style>
/* NAVBAR */
.navbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 20px;
}

.navbar .logo {
    flex-shrink: 0;
    margin: 0;
}

.navbar .search {
    width: 40%;
    flex: 1;
    max-width: 450px;
}

.navbar .search input {
    width: 100%;
}

/* MENU */
.menu {
    display: flex;
    align-items: center;
    gap: 22px;
    flex-shrink: 0;
}

.menu > a {
    display: inline-flex;
    justify-content: center;
    align-items: center;
    width: 40px;
    height: 40px;
    color: #41204E;
}

.menu > a i {
    font-size: 22px;
}

.navbar-profile {
    display: inline-flex;
    justify-content: center;
    align-items: center;
}

.navbar-avatar {
    width: 35px;
    height: 35px;
    border-radius: 50%;
    object-fit: cover;
    border: 2px solid #41204E;
}

/* RESPONSIVE */
@media (max-width: 768px) {
    .navbar {
        flex-wrap: wrap;
        gap: 12px;
    }

    .navbar .search {
        order: 3;
        flex-basis: 100%;
        max-width: none;
    }

    .menu {
        gap: 10px;
    }
}
</style>
