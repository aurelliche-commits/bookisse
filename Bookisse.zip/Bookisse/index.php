<?php
session_start();
require 'config/database.php';

/* =========================
   SEARCH BOOK
========================= */

$searchKeyword = trim($_GET['search'] ?? '');
$isSearching = ($searchKeyword !== '');

if ($isSearching) {

    $query = mysqli_prepare(
        $conn,
        "SELECT * FROM books
         WHERE title LIKE CONCAT('%', ?, '%')
         OR author LIKE CONCAT('%', ?, '%')
         ORDER BY id DESC"
    );

    mysqli_stmt_bind_param(
        $query,
        "ss",
        $searchKeyword,
        $searchKeyword
    );

    mysqli_stmt_execute($query);
    $bookResult = mysqli_stmt_get_result($query);

} else {

    $bookResult = mysqli_query(
        $conn,
        "SELECT * FROM books LIMIT 6"
    );

}

/* =========================
   BEST SELLER 
========================= */

$bestSellerQuery = mysqli_query(
    $conn,
    "SELECT * FROM books
     WHERE is_best_seller = 1
     LIMIT 1"
);

$bestSeller = $bestSellerQuery
    ? mysqli_fetch_assoc($bestSellerQuery)
    : null;

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>BOOKISSE</title>

    <link rel="stylesheet" href="assets/css/style.css?v=<?php echo time(); ?>">

    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"
    >

    <link
        href="https://fonts.googleapis.com/css2?family=Irish+Grover&display=swap"
        rel="stylesheet"
    >

</head>

<body>

<?php include "includes/navbar.php"; ?>


<!-- =========================
     HERO SECTION
========================= -->

<section class="hero">

    <div class="container hero-content">

        <!-- HERO TEXT -->

        <div class="hero-text">

            <h1>
                Every page
                <br>
                Holds a Story
            </h1>

            <p>
                A place where stories come alive.
                Browse our curated collection and discover your next unforgettable journey.
            </p>

            <div class="hero-btn">

                <button
                    class="btn1"
                    type="button"
                    onclick="scrollToCatalogue()"
                >
                    Explore Collection
                </button>

            </div>

        </div>


        <!-- BEST SELLER BOOK -->

        <div class="hero-book">

            <?php if ($bestSeller): ?>

                <?php
                $bestStock = (int)($bestSeller['stock'] ?? 0);
                ?>

                <div class="book-card">

                    <span class="badge best-seller-label">
                        <i class="fa-solid fa-crown"></i>
                        BEST SELLER
                    </span>

                    <img
                        src="assets/images/books/<?= htmlspecialchars($bestSeller['image'], ENT_QUOTES, 'UTF-8'); ?>"
                        alt="<?= htmlspecialchars($bestSeller['title'], ENT_QUOTES, 'UTF-8'); ?>"
                    >

                    <h3>
                        <?= htmlspecialchars($bestSeller['title'], ENT_QUOTES, 'UTF-8'); ?>
                    </h3>

                    <p class="hero-book-price">
                        Rp. <?= htmlspecialchars($bestSeller['price'], ENT_QUOTES, 'UTF-8'); ?>
                    </p>

                    <p class="stock-info">

                        <?php if ($bestStock <= 0): ?>

                            <span class="out-stock">
                                Out of Stock
                            </span>

                        <?php elseif ($bestStock <= 10): ?>

                            <span class="low-stock">
                                Stock: <?= $bestStock; ?> left
                            </span>

                        <?php else: ?>

                            <span class="in-stock">
                                Stock: <?= $bestStock; ?>
                            </span>

                        <?php endif; ?>

                    </p>


                    <!-- BEST SELLER ACTIONS -->

                    <div class="book-actions hero-book-actions">

                        <a
                            href="pages/book_detail.php?id=<?= (int)$bestSeller['id']; ?>"
                            class="detail-btn"
                        >
                            View Details
                            <i class="fa-solid fa-arrow-right"></i>
                        </a>

                        <?php if ($bestStock > 0): ?>

                            <a
                                href="process/add_cart.php?id=<?= (int)$bestSeller['id']; ?>"
                                class="cart-icon"
                                title="Add to Cart"
                            >
                                <i class="fa-solid fa-cart-shopping"></i>
                            </a>

                        <?php else: ?>

                            <span
                                class="cart-icon disabled"
                                title="Out of Stock"
                            >
                                <i class="fa-solid fa-cart-shopping"></i>
                            </span>

                        <?php endif; ?>

                    </div>

                </div>

            <?php else: ?>

                <div class="book-card empty-best-seller">

                    <i class="fa-solid fa-book-open"></i>

                    <h3>No Best Seller Yet</h3>

                    <p>
                        Admin has not selected a Best Seller book.
                    </p>

                </div>

            <?php endif; ?>

        </div>

    </div>

</section>


<!-- =========================
     BOOK CATALOGUE
========================= -->

<section class="catalogue" id="catalogue">

    <div class="container">

        <h2>Book Catalogue</h2>

        <?php if ($isSearching): ?>

            <div class="search-result-info">

                Search results for:

                <strong>
                    <?= htmlspecialchars($searchKeyword, ENT_QUOTES, 'UTF-8'); ?>
                </strong>

                <a href="index.php" class="clear-search">
                    Clear Search
                </a>

            </div>

        <?php endif; ?>


        <!-- CATEGORY FILTER -->

        <div class="filter">

            <button
                class="filter-btn active"
                data-genre="all"
                <?= $isSearching ? 'disabled' : ''; ?>
            >
                All
            </button>

            <button
                class="filter-btn"
                data-genre="Fiction"
                <?= $isSearching ? 'disabled' : ''; ?>
            >
                Fiction
            </button>

            <button
                class="filter-btn"
                data-genre="Self Improvement"
                <?= $isSearching ? 'disabled' : ''; ?>
            >
                Self Improvement
            </button>

            <button
                class="filter-btn"
                data-genre="Business"
                <?= $isSearching ? 'disabled' : ''; ?>
            >
                Business
            </button>

            <button
                class="filter-btn"
                data-genre="Fantasy"
                <?= $isSearching ? 'disabled' : ''; ?>
            >
                Fantasy
            </button>

            <button
                class="filter-btn"
                data-genre="Mystery"
                <?= $isSearching ? 'disabled' : ''; ?>
            >
                Mystery
            </button>

            <button
                class="filter-btn"
                data-genre="Romance"
                <?= $isSearching ? 'disabled' : ''; ?>
            >
                Romance
            </button>

        </div>


        <!-- BOOK LIST -->

        <div class="book-list" id="book-list">

            <?php if ($bookResult && mysqli_num_rows($bookResult) > 0): ?>

                <?php while ($book = mysqli_fetch_assoc($bookResult)): ?>

                    <?php
                    $stock = (int)($book['stock'] ?? 0);
                    ?>

                    <div class="book-item">

                        <?php if (!empty($book['badge'])): ?>

                            <span class="badge">
                                <?= htmlspecialchars($book['badge'], ENT_QUOTES, 'UTF-8'); ?>
                            </span>

                        <?php endif; ?>


                        <img
                            src="assets/images/books/<?= htmlspecialchars($book['image'], ENT_QUOTES, 'UTF-8'); ?>"
                            alt="<?= htmlspecialchars($book['title'], ENT_QUOTES, 'UTF-8'); ?>"
                        >

                        <h4>
                            <?= htmlspecialchars($book['title'], ENT_QUOTES, 'UTF-8'); ?>
                        </h4>

                        <small>
                            <?= htmlspecialchars($book['author'], ENT_QUOTES, 'UTF-8'); ?>
                        </small>

                        <p>
                            Rp. <?= htmlspecialchars($book['price'], ENT_QUOTES, 'UTF-8'); ?>
                        </p>


                        <!-- STOCK -->

                        <p class="stock-info">

                            <?php if ($stock <= 0): ?>

                                <span class="out-stock">
                                    Out of Stock
                                </span>

                            <?php elseif ($stock <= 10): ?>

                                <span class="low-stock">
                                    Stock: <?= $stock; ?> left
                                </span>

                            <?php else: ?>

                                <span class="in-stock">
                                    Stock: <?= $stock; ?>
                                </span>

                            <?php endif; ?>

                        </p>


                        <!-- BOOK ACTIONS -->

                        <div class="book-actions">

                            <a
                                href="pages/book_detail.php?id=<?= (int)$book['id']; ?>"
                                class="detail-btn"
                            >
                                View Details
                                <i class="fa-solid fa-arrow-right"></i>
                            </a>

                            <?php if ($stock > 0): ?>

                                <a
                                    class="cart-icon"
                                    href="process/add_cart.php?id=<?= (int)$book['id']; ?>"
                                    title="Add to Cart"
                                >
                                    <i class="fa-solid fa-cart-shopping"></i>
                                </a>

                            <?php else: ?>

                                <span
                                    class="cart-icon disabled"
                                    title="Out of Stock"
                                >
                                    <i class="fa-solid fa-cart-shopping"></i>
                                </span>

                            <?php endif; ?>

                        </div>

                    </div>

                <?php endwhile; ?>

            <?php else: ?>

                <p class="no-books">
                    No books found.
                </p>

            <?php endif; ?>

        </div>


        <!-- VIEW ALL -->

        <?php if (!$isSearching): ?>

            <div class="view-all-container">

                <a
                    href="category.php?genre=all"
                    id="view-all-btn"
                    class="view-all-btn"
                >
                    View All Books →
                </a>

            </div>

        <?php endif; ?>

    </div>

</section>


<!-- =========================
     SPECIAL OFFERS
========================= -->

<section class="offer">

    <div class="container">

        <h2>Special Offers</h2>

        <div class="book-list">

            <?php

            $offer = mysqli_query(
                $conn,
                "SELECT * FROM books WHERE is_offer='1'"
            );

            if ($offer && mysqli_num_rows($offer) > 0):

                while ($book = mysqli_fetch_assoc($offer)):

                    $stock = (int)($book['stock'] ?? 0);

            ?>

                <div class="book-item">

                    <?php if (!empty($book['badge'])): ?>

                        <span class="badge">
                            <?= htmlspecialchars($book['badge'], ENT_QUOTES, 'UTF-8'); ?>
                        </span>

                    <?php endif; ?>


                    <img
                        src="assets/images/books/<?= htmlspecialchars($book['image'], ENT_QUOTES, 'UTF-8'); ?>"
                        alt="<?= htmlspecialchars($book['title'], ENT_QUOTES, 'UTF-8'); ?>"
                    >

                    <h4>
                        <?= htmlspecialchars($book['title'], ENT_QUOTES, 'UTF-8'); ?>
                    </h4>

                    <small>
                        <?= htmlspecialchars($book['author'], ENT_QUOTES, 'UTF-8'); ?>
                    </small>

                    <p>
                        Rp. <?= htmlspecialchars($book['price'], ENT_QUOTES, 'UTF-8'); ?>
                    </p>


                    <!-- STOCK -->

                    <p class="stock-info">

                        <?php if ($stock <= 0): ?>

                            <span class="out-stock">
                                Out of Stock
                            </span>

                        <?php elseif ($stock <= 10): ?>

                            <span class="low-stock">
                                Stock: <?= $stock; ?> left
                            </span>

                        <?php else: ?>

                            <span class="in-stock">
                                Stock: <?= $stock; ?>
                            </span>

                        <?php endif; ?>

                    </p>


                    <!-- BOOK ACTIONS -->

                    <div class="book-actions">

                        <a
                            href="pages/book_detail.php?id=<?= (int)$book['id']; ?>"
                            class="detail-btn"
                        >
                            View Details
                            <i class="fa-solid fa-arrow-right"></i>
                        </a>

                        <?php if ($stock > 0): ?>

                            <a
                                class="cart-icon"
                                href="process/add_cart.php?id=<?= (int)$book['id']; ?>"
                                title="Add to Cart"
                            >
                                <i class="fa-solid fa-cart-shopping"></i>
                            </a>

                        <?php else: ?>

                            <span
                                class="cart-icon disabled"
                                title="Out of Stock"
                            >
                                <i class="fa-solid fa-cart-shopping"></i>
                            </span>

                        <?php endif; ?>

                    </div>

                </div>

            <?php

                endwhile;

            endif;

            ?>

        </div>

    </div>

</section>


<!-- =========================
     FOOTER TITLE
========================= -->

<section class="footer-title">

    <h2>
        GET MORE TO KNOW
        <span>BOOKISSE</span>
    </h2>

    <h3>
        BUY BOOKS MORE EASILY AT BOOKISSE
    </h3>

</section>


<!-- =========================
     FOOTER
========================= -->

<footer>

    <div class="container footer-content">

        <!-- STORE IDENTITY -->

        <div class="footer-brand">

            <h4>BOOKISSE</h4>

            <p>
                A trusted online bookstore with thousands
                of book collections for every reader.
            </p>

        </div>


        <!-- STORE INFORMATION -->

        <div class="footer-information">

            <h4>Information</h4>

            <ul>

                <li>
                    <i class="fa-solid fa-envelope"></i>

                    <a href="mailto:bookisseu@gmail.com">
                        bookisseu@gmail.com
                    </a>
                </li>

                <li>
                    <i class="fa-solid fa-location-dot"></i>

                    Jl. Buku Ceria No. 15, Jakarta Selatan, DKI Jakarta
                </li>

                <li>
                    <i class="fa-solid fa-phone"></i>

                    <a href="tel:08993457821">
                        08993457821
                    </a>
                </li>

            </ul>

        </div>

    </div>

</footer>


<!-- =========================
     JAVASCRIPT
========================= -->

<script>

/* SCROLL TO CATALOGUE */

function scrollToCatalogue() {

    const catalogue = document.getElementById("catalogue");

    if (catalogue) {

        catalogue.scrollIntoView({
            behavior: "smooth",
            block: "start"
        });

    }

}


/* CATEGORY FILTER */

const filterButtons = document.querySelectorAll(".filter-btn");

const bookList = document.getElementById("book-list");

const viewAllButton = document.getElementById("view-all-btn");


filterButtons.forEach(button => {

    button.addEventListener("click", function() {

        const genre = this.dataset.genre;

        filterButtons.forEach(btn => {
            btn.classList.remove("active");
        });

        this.classList.add("active");


        fetch(
            "process/filter_books.php?genre=" +
            encodeURIComponent(genre)
        )

        .then(response => {

            if (!response.ok) {
                throw new Error("Failed to load books.");
            }

            return response.text();

        })

        .then(data => {

            bookList.innerHTML = data;

        })

        .catch(error => {

            console.error(error);

            bookList.innerHTML =
                '<p class="no-books">Failed to load books. Please try again.</p>';

        });


        if (viewAllButton) {

            viewAllButton.href =
                "category.php?genre=" +
                encodeURIComponent(genre);

            if (genre === "all") {

                viewAllButton.innerHTML = "View All Books →";

            } else {

                viewAllButton.innerHTML =
                    "View All " + genre + " Books →";

            }

        }

    });

});

</script>

<!-- =========================
     ADDITIONAL STYLE
========================= -->

<style>
html {
    scroll-behavior: smooth;
}

#catalogue {
    scroll-margin-top: 20px;
}

.no-books {
    width: 100%;
    text-align: center;
    color: #FFFFFF;
    font-size: 18px;
    padding: 40px 20px;
}

.search-result-info {
    color: #FFFFFF;
    margin: 15px 0 20px;
}

.clear-search {
    color: #F4B43A;
    margin-left: 12px;
    text-decoration: underline;
}

.filter-btn:disabled {
    opacity: 0.5;
    cursor: not-allowed;
}


/* =========================
   FOOTER INFORMATION
========================= */

.footer-content {
    display: grid;
    grid-template-columns: 1.2fr 1fr;
    gap: 80px;
    align-items: start;
}

.footer-information ul {
    display: flex;
    flex-direction: column;
    gap: 15px;
}

.footer-information li {
    display: flex;
    align-items: flex-start;
    gap: 12px;
    color: #FFFFFF;
    line-height: 1.7;
    cursor: default;
}

.footer-information li i {
    color: #F4B43A;
    min-width: 18px;
    margin-top: 5px;
}

.footer-information li a {
    color: #FFFFFF;
    text-decoration: none;
}

.footer-information li a:hover {
    color: #F4B43A;
}


/* RESPONSIVE FOOTER */

@media (max-width: 650px) {

    .footer-content {
        grid-template-columns: 1fr;
        gap: 35px;
    }

}

</style>
</body>
</html>
