
<?php
session_start();

require_once __DIR__ . '/../config/database.php';

// ========================================
// 1. CEK LOGIN
// ========================================

if (!isset($_SESSION['user'])) {
    header("Location: ../pages/login.php");
    exit;
}

$user_id = (int) $_SESSION['user']['id'];

// ========================================
// 2. CEK REQUEST
// ========================================

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: ../pages/cart.php");
    exit;
}

// Data pelanggan
$name = trim($_POST['name'] ?? '');
$email = trim($_POST['email'] ?? '');
$phone = trim($_POST['phone'] ?? '');
$address = trim($_POST['address'] ?? '');

if ($name === '' || $email === '' || $phone === '' || $address === '') {
    echo "<script>
        alert('Please complete all customer information.');
        window.location='../pages/cart.php';
    </script>";
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo "<script>
        alert('Please enter a valid email address.');
        window.location='../pages/cart.php';
    </script>";
    exit;
}

// ========================================
// 3. AMBIL BUKU YANG DIPILIH SAJA
// ========================================

$selected_ids = $_POST['selected_ids'] ?? [];

if (!is_array($selected_ids)) {
    $selected_ids = [];
}

$selected_ids = array_values(array_unique(array_filter(
    array_map('intval', $selected_ids),
    function ($id) {
        return $id > 0;
    }
)));

if (empty($selected_ids)) {
    echo "<script>
        alert('Please select at least one book.');
        window.location='../pages/cart.php';
    </script>";
    exit;
}

// Buat placeholder sesuai jumlah buku terpilih
$placeholders = implode(',', array_fill(0, count($selected_ids), '?'));

try {

    // ========================================
    // 4. MULAI TRANSAKSI
    // ========================================

    $conn->begin_transaction();

    // Ambil hanya buku yang dipilih oleh user.
    // FOR UPDATE mengunci baris selama transaksi.

    $sql = "
        SELECT
            b.id,
            b.title,
            b.price,
            b.stock,
            c.qty
        FROM cart c
        INNER JOIN books b ON c.book_id = b.id
        WHERE c.user_id = ?
        AND b.id IN ($placeholders)
        FOR UPDATE
    ";

    $stmt = $conn->prepare($sql);

    $params = array_merge([$user_id], $selected_ids);
    $types = str_repeat('i', count($params));

    $bind = [$types];

    foreach ($params as $key => $value) {
        $bind[] = &$params[$key];
    }

    call_user_func_array(
        [$stmt, 'bind_param'],
        $bind
    );

    $stmt->execute();

    $result = $stmt->get_result();

    $items = [];
    $total = 0;

    while ($item = $result->fetch_assoc()) {

        $qty = (int) $item['qty'];
        $stock = (int) $item['stock'];

        if ($qty <= 0) {
            throw new Exception(
                "Invalid quantity for " . $item['title']
            );
        }

        if ($stock < $qty) {
            throw new Exception(
                "Stock is insufficient for: " . $item['title']
            );
        }

        $item['price'] = (float) $item['price'];

        $total += $item['price'] * $qty;

        $items[] = $item;
    }

    $stmt->close();

    // Pastikan semua buku yang dipilih ditemukan.
    if (count($items) !== count($selected_ids)) {
        throw new Exception(
            "Some selected books are no longer in your cart. Please refresh your cart."
        );
    }

    if (empty($items)) {
        throw new Exception("No selected books found.");
    }

// ========================================
// 5. BUAT KODE PESANAN OTOMATIS
// ========================================

// Gunakan tanggal server PHP.
$order_date = date('Y-m-d');
$order_date_code = date('Ymd');

// Buat baris tanggal jika belum tersedia.
$sequence_insert = $conn->prepare("
    INSERT IGNORE INTO order_sequences
    (order_date, last_number)
    VALUES (?, 0)
");

$sequence_insert->bind_param("s", $order_date);
$sequence_insert->execute();
$sequence_insert->close();

// Kunci nomor urut tanggal ini agar tidak bentrok.
$sequence_select = $conn->prepare("
    SELECT last_number
    FROM order_sequences
    WHERE order_date = ?
    FOR UPDATE
");

$sequence_select->bind_param("s", $order_date);
$sequence_select->execute();

$sequence_result = $sequence_select->get_result();
$sequence_row = $sequence_result->fetch_assoc();

$sequence_select->close();

if (!$sequence_row) {
    throw new Exception("Failed to generate order number.");
}

// Tambahkan nomor transaksi.
$next_number = (int)$sequence_row['last_number'] + 1;

// Simpan nomor terakhir.
$sequence_update = $conn->prepare("
    UPDATE order_sequences
    SET last_number = ?
    WHERE order_date = ?
");

$sequence_update->bind_param(
    "is",
    $next_number,
    $order_date
);

$sequence_update->execute();
$sequence_update->close();

// Format kode: YYYYMMDD-NNN
$order_code = $order_date_code . '-' .
    str_pad($next_number, 3, '0', STR_PAD_LEFT);


// ========================================
// 6. SIMPAN ORDER
// ========================================

$order_stmt = $conn->prepare("
    INSERT INTO orders
    (order_code, user_id, total, status, payment_status)
    VALUES (?, ?, ?, 'pending', 'pending')
");

$order_stmt->bind_param(
    "sid",
    $order_code,
    $user_id,
    $total
);

if (!$order_stmt->execute()) {
    throw new Exception($order_stmt->error);
}

$order_id = $conn->insert_id;

$order_stmt->close();

    // ========================================
    // 6. SIMPAN DETAIL ORDER
    // ========================================

    $item_stmt = $conn->prepare("
        INSERT INTO order_items
        (order_id, book_id, quantity, price)
        VALUES (?, ?, ?, ?)
    ");

    $stock_stmt = $conn->prepare("
        UPDATE books
        SET stock = stock - ?
        WHERE id = ?
        AND stock >= ?
    ");

    foreach ($items as $item) {

        $book_id = (int) $item['id'];
        $qty = (int) $item['qty'];
        $price = (float) $item['price'];

        // Kurangi stok buku yang dibeli saja.
        $stock_stmt->bind_param(
            "iii",
            $qty,
            $book_id,
            $qty
        );

        if (!$stock_stmt->execute()) {
            throw new Exception($stock_stmt->error);
        }

        if ($stock_stmt->affected_rows !== 1) {
            throw new Exception(
                "Stock changed or is insufficient for: " . $item['title']
            );
        }

        // Simpan detail buku ke order_items.
        $item_stmt->bind_param(
            "iiid",
            $order_id,
            $book_id,
            $qty,
            $price
        );

        if (!$item_stmt->execute()) {
            throw new Exception($item_stmt->error);
        }
    }

    $item_stmt->close();
    $stock_stmt->close();

    // ========================================
    // 7. HAPUS HANYA BUKU YANG DIPILIH
    // ========================================

    $delete_sql = "
        DELETE FROM cart
        WHERE user_id = ?
        AND book_id IN ($placeholders)
    ";

    $delete_stmt = $conn->prepare($delete_sql);

    $delete_params = array_merge([$user_id], $selected_ids);
    $delete_types = str_repeat('i', count($delete_params));

    $delete_bind = [$delete_types];

    foreach ($delete_params as $key => $value) {
        $delete_bind[] = &$delete_params[$key];
    }

    call_user_func_array(
        [$delete_stmt, 'bind_param'],
        $delete_bind
    );

    if (!$delete_stmt->execute()) {
        throw new Exception($delete_stmt->error);
    }

    $delete_stmt->close();

    // ========================================
    // 8. SELESAIKAN TRANSAKSI
    // ========================================

    $conn->commit();

    header(
        "Location: ../pages/payment.php?order_id=" . $order_id
    );

    exit;

} catch (Throwable $e) {

    // Batalkan semua perubahan jika terjadi error.
    $conn->rollback();

    error_log(
        "BOOKISSE CHECKOUT ERROR: " . $e->getMessage()
    );

    echo "<script>
        alert(" . json_encode(
            "Order failed: " . $e->getMessage()
        ) . ");
        window.location='../pages/cart.php';
    </script>";

    exit;
}
?>
