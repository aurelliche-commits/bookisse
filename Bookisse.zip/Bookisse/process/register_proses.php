<?php

require "../config/database.php";

$fullname = mysqli_real_escape_string($conn, $_POST['fullname']);
$email = mysqli_real_escape_string($conn, $_POST['email']);
$password = $_POST['password'];
$confirm = $_POST['confirm'];


/* =========================
   CEK PASSWORD
========================= */

if ($password != $confirm) {

    echo "<script>
        alert('Password tidak sama!');
        window.location='../pages/register.php';
    </script>";

    exit;
}


/* =========================
   CEK EMAIL
========================= */

$cek = mysqli_query(
    $conn,
    "SELECT * FROM users WHERE email='$email'"
);

if (mysqli_num_rows($cek) > 0) {

    echo "<script>
        alert('Email sudah digunakan!');
        window.location='../pages/register.php';
    </script>";

    exit;
}


/* =========================
   HASH PASSWORD
========================= */

$password = password_hash(
    $password,
    PASSWORD_DEFAULT
);


/* =========================
   ROLE USER
========================= */

$role = "user";


/* =========================
   INSERT USER
========================= */

$query = mysqli_query(
    $conn,
    "INSERT INTO users
    (
        name,
        email,
        password,
        role
    )
    VALUES
    (
        '$fullname',
        '$email',
        '$password',
        '$role'
    )"
);


/* =========================
   HASIL REGISTER
========================= */

if ($query) {

    echo "<script>
        alert('Register Berhasil!');
        window.location='../pages/login.php';
    </script>";

} else {

    echo "<script>
        alert('Register gagal: " . mysqli_error($conn) . "');
        window.location='../pages/register.php';
    </script>";
}

?>