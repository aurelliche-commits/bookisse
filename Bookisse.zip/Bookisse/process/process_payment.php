<?php
session_start();
require "../config/database.php";

// 1. Cek login
if (!isset($_SESSION['user'])) {
    header("Location: ../pages/login.php");
    exit;
}
$user_id = (int) $_SESSION['user']['id'];

// 2. Cek metode request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: ../pages/profile.php");
    exit;
}

// 3. Ambil data form
$order_id = (int) ($_POST['order_id'] ?? 0);
$payment_method = $_POST['payment_method'] ?? '';
$payment_provider = $_POST['payment_provider'] ?? '';

$allowed_methods = [
    'E-Wallet',
    'Bank Transfer'
];

$allowed_providers = [
    'QRIS',
    'DANA',
    'GoPay'
];

if (
    $order_id <= 0 ||
    !in_array($payment_method, $allowed_methods, true)
) {
    die("Invalid payment data.");
}

if ($payment_method === 'E-Wallet') {
    if (!in_array($payment_provider, $allowed_providers, true)) {
        die("Please select a valid E-Wallet.");
    }
} else {
    $payment_provider = null;
}

// 4. Periksa pesanan milik user
$stmt = mysqli_prepare($conn, "
    SELECT id, payment_status
    FROM orders
    WHERE id = ? AND user_id = ?
    LIMIT 1
");

if (!$stmt) {
    die("Database query failed.");
}

mysqli_stmt_bind_param($stmt, "ii", $order_id, $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$order = mysqli_fetch_assoc($result);
mysqli_stmt_close($stmt);

if (!$order) {
    die("Order not found.");
}

// 5. Cek status pembayaran
if ($order['payment_status'] === 'paid') {
    die("This order has already been paid.");
}

if ($order['payment_status'] === 'waiting_verification') {
    header("Location: ../pages/payment.php?order_id=$order_id&submitted=1");
    exit;
}

// 6. Validasi file upload
if (!isset($_FILES['payment_proof'])) {
    die("Please upload your payment proof.");
}

$file = $_FILES['payment_proof'];

if ($file['error'] !== UPLOAD_ERR_OK) {
    if ($file['error'] === UPLOAD_ERR_INI_SIZE || $file['error'] === UPLOAD_ERR_FORM_SIZE) {
        die("File is too large. Maximum allowed size is 10 MB.");
    }

    if ($file['error'] === UPLOAD_ERR_NO_FILE) {
        die("Please upload your payment proof.");
    }

    die("The file could not be uploaded. Please try again.");
}

// Batas upload diperbesar menjadi 10 MB
$max_size = 10 * 1024 * 1024;

if ($file['size'] <= 0 || $file['size'] > $max_size) {
    die("File size must be greater than 0 and must not exceed 10 MB.");
}

// 7. Validasi MIME file di server
if (!is_uploaded_file($file['tmp_name'])) {
    die("Invalid uploaded file.");
}

$finfo = new finfo(FILEINFO_MIME_TYPE);
$mime = $finfo->file($file['tmp_name']);

$allowed_types = [
    'image/jpeg'      => 'jpg',
    'image/png'       => 'png',
    'image/webp'      => 'webp',
    'application/pdf' => 'pdf'
];

if (!isset($allowed_types[$mime])) {
    die("Only JPG, JPEG, PNG, WEBP and PDF files are allowed.");
}

// 8. Buat folder penyimpanan
$upload_dir = __DIR__ . '/../uploads/payment_proofs/';

if (!is_dir($upload_dir) && !mkdir($upload_dir, 0755, true)) {
    die("Cannot create payment upload folder.");
}

// 9. Buat nama file unik
$extension = $allowed_types[$mime];
$file_name = bin2hex(random_bytes(16)) . '.' . $extension;
$file_path = $upload_dir . $file_name;

if (!move_uploaded_file($file['tmp_name'], $file_path)) {
    die("Failed to upload payment proof.");
}

// 10. Simpan data pembayaran
$stmt = mysqli_prepare($conn, "
    UPDATE orders
    SET
        payment_status = 'waiting_verification',
        payment_method = ?,
        payment_provider = ?,
        payment_proof = ?,
        paid_at = NULL
    WHERE id = ?
      AND user_id = ?
      AND payment_status <> 'paid'
      AND payment_status <> 'waiting_verification'
");

if (!$stmt) {
    unlink($file_path);
    die("Database preparation failed.");
}

mysqli_stmt_bind_param(
    $stmt,
    "sssii",
    $payment_method,
    $payment_provider,
    $file_name,
    $order_id,
    $user_id
);

if (!mysqli_stmt_execute($stmt)) {
    mysqli_stmt_close($stmt);
    unlink($file_path);
    die("Failed to save payment information.");
}

$affected_rows = mysqli_stmt_affected_rows($stmt);
mysqli_stmt_close($stmt);

if ($affected_rows !== 1) {
    unlink($file_path);
    die("Payment could not be submitted. Please refresh your order.");
}

// 11. Berhasil
header("Location: ../pages/payment.php?order_id=$order_id&submitted=1");
exit;
?>