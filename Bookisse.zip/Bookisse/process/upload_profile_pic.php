
<?php
session_start();

echo "UPLOAD PROCESS TERPANGGIL!<br>";

echo "Request Method: " . $_SERVER['REQUEST_METHOD'] . "<br>";

echo "Session User ID: ";
var_dump($_SESSION['user']['id'] ?? null);

echo "<br>File Upload:<br>";
var_dump($_FILES);

exit;
?>
