<?php
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: ../pages/login.php");
    exit;
}

require_once __DIR__ . "/../config/database.php";

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: ../pages/cart.php");
    exit;
}

$user_id = $_SESSION['user']['id'];
$book_id = (int)($_POST['book_id'] ?? 0);
$action = $_POST['action'] ?? '';

if ($book_id <= 0) {
    header("Location: ../pages/cart.php");
    exit;
}

$stmt = mysqli_prepare($conn, "
    SELECT cart.qty, books.stock
    FROM cart
    JOIN books ON cart.book_id = books.id
    WHERE cart.user_id = ? AND cart.book_id = ?
");

mysqli_stmt_bind_param($stmt, "ii", $user_id, $book_id);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);
$item = mysqli_fetch_assoc($result);

if ($item) {

    $qty = (int)$item['qty'];
    $stock = (int)$item['stock'];

    if ($action === 'increase' && $qty < $stock) {

        $new_qty = $qty + 1;

        $update = mysqli_prepare($conn, "
            UPDATE cart
            SET qty = ?
            WHERE user_id = ? AND book_id = ?
        ");

        mysqli_stmt_bind_param($update, "iii", $new_qty, $user_id, $book_id);
        mysqli_stmt_execute($update);

    } elseif ($action === 'decrease') {

        if ($qty > 1) {
            $new_qty = $qty - 1;

            $update = mysqli_prepare($conn, "
                UPDATE cart
                SET qty = ?
                WHERE user_id = ? AND book_id = ?
            ");

            mysqli_stmt_bind_param($update, "iii", $new_qty, $user_id, $book_id);
            mysqli_stmt_execute($update);

        } else {
            $delete = mysqli_prepare($conn, "
                DELETE FROM cart
                WHERE user_id = ? AND book_id = ?
            ");

            mysqli_stmt_bind_param($delete, "ii", $user_id, $book_id);
            mysqli_stmt_execute($delete);
        }

    } elseif ($action === 'remove') {

        $delete = mysqli_prepare($conn, "
            DELETE FROM cart
            WHERE user_id = ? AND book_id = ?
        ");

        mysqli_stmt_bind_param($delete, "ii", $user_id, $book_id);
        mysqli_stmt_execute($delete);
    }
}
header("Location: ../pages/cart.php");
exit;
