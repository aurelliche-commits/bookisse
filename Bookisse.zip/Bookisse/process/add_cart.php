<?php
session_start();
require "../config/database.php";

if (!isset($_SESSION['user'])) {
    header("Location: ../pages/login.php");
    exit;
}

$user = (int) $_SESSION['user']['id'];
$book = (int) ($_GET['id'] ?? 0);

if ($book <= 0) {
    header("Location: ../index.php");
    exit;
}

// Periksa stok buku
$check = mysqli_prepare(
    $conn,
    "SELECT stock FROM books WHERE id = ?"
);

mysqli_stmt_bind_param($check, "i", $book);
mysqli_stmt_execute($check);

$result = mysqli_stmt_get_result($check);
$data = mysqli_fetch_assoc($result);

if (!$data || (int)$data['stock'] <= 0) {
    echo "<script>
        alert('Sorry, this book is out of stock!');
        window.location='../index.php';
    </script>";
    exit;
}

// Tambahkan atau perbarui keranjang
mysqli_begin_transaction($conn);

try {
    $cart = mysqli_prepare(
        $conn,
        "SELECT id, qty FROM cart
         WHERE user_id = ? AND book_id = ?
         FOR UPDATE"
    );

    mysqli_stmt_bind_param($cart, "ii", $user, $book);
    mysqli_stmt_execute($cart);

    $cart_result = mysqli_stmt_get_result($cart);
    $existing = mysqli_fetch_assoc($cart_result);

    if ($existing) {
        if ((int)$existing['qty'] >= (int)$data['stock']) {
            throw new Exception("Quantity exceeds available stock!");
        }

        $update = mysqli_prepare(
            $conn,
            "UPDATE cart SET qty = qty + 1 WHERE id = ?"
        );

        mysqli_stmt_bind_param($update, "i", $existing['id']);
        mysqli_stmt_execute($update);

    } else {
        $insert = mysqli_prepare(
            $conn,
            "INSERT INTO cart (user_id, book_id, qty)
             VALUES (?, ?, 1)"
        );

        mysqli_stmt_bind_param($insert, "ii", $user, $book);
        mysqli_stmt_execute($insert);
    }

    mysqli_commit($conn);

    header("Location: ../pages/cart.php");
    exit;

} catch (Exception $e) {
    mysqli_rollback($conn);

    echo "<script>
        alert(" . json_encode($e->getMessage()) . ");
        window.location='../index.php';
    </script>";
    exit;
}
