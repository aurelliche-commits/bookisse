<?php

session_start();

require "../config/database.php";


$email = mysqli_real_escape_string(
    $conn,
    $_POST['email']
);

$password = $_POST['password'];


/* =========================
   CARI USER
========================= */

$query = mysqli_query(
    $conn,
    "SELECT * FROM users WHERE email='$email'"
);


if (mysqli_num_rows($query) == 1) {

    $user = mysqli_fetch_assoc($query);

    $login = false;


    /* =========================
       CEK PASSWORD BARU
       password_hash()
    ========================= */

    if (password_verify($password, $user['password'])) {

        $login = true;

    }


    /* =========================
       CEK PASSWORD LAMA
       MD5
    ========================= */

    elseif (md5($password) == $user['password']) {

        $login = true;

        /*
         * Setelah login berhasil,
         * ubah password lama MD5
         * menjadi password_hash()
         */

        $new_password = password_hash(
            $password,
            PASSWORD_DEFAULT
        );

        mysqli_query(
            $conn,
            "UPDATE users
             SET password='$new_password'
             WHERE id=" . $user['id']
        );

    }


    /* =========================
       LOGIN BERHASIL
    ========================= */

    if ($login) {

        $_SESSION['user'] = $user;

        /*
         * Ambil ulang password terbaru
         * kalau tadi password MD5 sudah diubah
         */

        $user['password'] = isset($new_password)
            ? $new_password
            : $user['password'];

        $_SESSION['user'] = $user;

        $_SESSION['role'] = $user['role'];

        $_SESSION['name'] = $user['name'];


        /* =========================
           REDIRECT
        ========================= */

        if ($user['role'] == "admin") {

            header(
                "Location: ../admin/admin.php"
            );

        } else {

            header(
                "Location: ../pages/profile.php"
            );

        }

        exit;

    }

}


/* =========================
   LOGIN GAGAL
========================= */

echo "
<script>

alert('Email atau Password salah!');

window.location='../pages/login.php';

</script>
";

?>