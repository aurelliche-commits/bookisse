
<?php
session_start();

header('Content-Type: application/json');

require "../config/database.php";

// CEK LOGIN
if (!isset($_SESSION['user'])) {
    http_response_code(401);

    echo json_encode([
        'success' => false,
        'message' => 'Please login first.'
    ]);

    exit;
}

$user_id = (int) $_SESSION['user']['id'];
$order_id = (int) ($_GET['order_id'] ?? 0);

// VALIDASI ORDER ID
if ($order_id <= 0) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'message' => 'Invalid order.'
    ]);

    exit;
}

// AMBIL DATA ORDER
$stmt = mysqli_prepare($conn, "
    SELECT
        id,
        order_code,
        payment_status,
        payment_method,
        payment_provider,
        total,
        created_at,
        paid_at,
        status
    FROM orders
    WHERE id = ?
    AND user_id = ?
    LIMIT 1
");

mysqli_stmt_bind_param($stmt, "ii", $order_id, $user_id);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);
$order = mysqli_fetch_assoc($result);

// CEK ORDER
if (!$order) {
    http_response_code(404);

    echo json_encode([
        'success' => false,
        'message' => 'Order not found.'
    ]);

    exit;
}

// DATA RESPONSE
$response = [
    'success' => true,
    'payment_status' => $order['payment_status'],
    'order_status' => $order['status'],
    'order_id' => (int) $order['id']
];

// JIKA PEMBAYARAN SUDAH BERHASIL
if ($order['payment_status'] === 'paid') {

    // AMBIL DETAIL PRODUK
    $items_stmt = mysqli_prepare($conn, "
        SELECT
            order_items.quantity,
            order_items.price,
            books.title
        FROM order_items
        JOIN books
            ON order_items.book_id = books.id
        WHERE order_items.order_id = ?
    ");

    mysqli_stmt_bind_param($items_stmt, "i", $order_id);
    mysqli_stmt_execute($items_stmt);

    $items_result = mysqli_stmt_get_result($items_stmt);

    $items = [];

    while ($item = mysqli_fetch_assoc($items_result)) {

        $items[] = [
            'title' => $item['title'],
            'quantity' => (int) $item['quantity'],
            'price' => (float) $item['price']
        ];
    }

    // DATA RECEIPT
    $response['receipt'] = [

        'order_id' => (int) $order['id'],

        'order_code' => !empty($order['order_code'])
            ? $order['order_code']
            : '#' . $order['id'],

        'total' => (float) $order['total'],

        'created_at' => $order['created_at'],

        'paid_at' => $order['paid_at'],

        'payment_method' => $order['payment_method'],

        'payment_provider' => $order['payment_provider'],

        'items' => $items
    ];
}

echo json_encode(
    $response,
    JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
);

exit;
?>
