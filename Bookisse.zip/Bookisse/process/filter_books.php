<?php
require "../config/database.php";
$genre = trim($_GET['genre'] ?? 'all');
if ($genre === 'all') {

    $query = mysqli_query(
        $conn,
        "SELECT * FROM books LIMIT 6"
    );

} else {

    $stmt = mysqli_prepare(
        $conn,
        "SELECT * FROM books
         WHERE LOWER(TRIM(category)) = LOWER(?)
         LIMIT 6"
    );

    if (!$stmt) {
        http_response_code(500);
        exit("Failed to prepare query.");
    }

    mysqli_stmt_bind_param($stmt, "s", $genre);
    mysqli_stmt_execute($stmt);

    $query = mysqli_stmt_get_result($stmt);
}

if (!$query) {
    http_response_code(500);
    exit("Failed to load books.");
}

if (mysqli_num_rows($query) === 0) {
    echo '<p class="no-books">No books found in this category.</p>';
    exit;
}

while ($book = mysqli_fetch_assoc($query)) {

    $stock = (int)($book['stock'] ?? 0);
?>

<div class="book-item">

    <?php if (!empty($book['badge'])): ?>
        <span class="badge">
            <?= htmlspecialchars($book['badge']); ?>
        </span>
    <?php endif; ?>

    <img
        src="assets/images/books/<?= htmlspecialchars($book['image']); ?>"
        alt="<?= htmlspecialchars($book['title']); ?>"
    >

    <h4>
        <?= htmlspecialchars($book['title']); ?>
    </h4>

    <small>
        <?= htmlspecialchars($book['author']); ?>
    </small>

    <p>
        Rp. <?= htmlspecialchars($book['price']); ?>
    </p>

    <p class="stock-info">

        <?php if ($stock <= 0): ?>

            <span class="out-stock">Out of Stock</span>

        <?php elseif ($stock <= 10): ?>

            <span class="low-stock">
                Stock: <?= $stock; ?> left
            </span>

        <?php else: ?>

            <span class="in-stock">
                Stock: <?= $stock; ?>
            </span>

        <?php endif; ?>

    </p>

    <!-- DETAIL DAN CART -->

    <div class="book-actions">

        <a
            href="book_detail.php?id=<?= (int)$book['id']; ?>"
            class="detail-btn"
        >
            View Details
            <i class="fa-solid fa-arrow-right"></i>
        </a>

        <?php if ($stock > 0): ?>

            <a
                class="cart-icon"
                href="../process/add_cart.php?id=<?= (int)$book['id']; ?>"
                title="Add to Cart"
            >
                <i class="fa-solid fa-cart-shopping"></i>
            </a>

        <?php else: ?>
            <span
                class="cart-icon disabled"
                title="Out of Stock"
            >
                <i class="fa-solid fa-cart-shopping"></i>
            </span>

        <?php endif; ?>

    </div>
</div>
<?php } ?>