<?php
session_start();
require "../config/database.php";

// =====================================
// CEK LOGIN
// =====================================

if (!isset($_SESSION['user']['id'])) {
    header("Location: ../pages/login.php");
    exit;
}

$user_id = (int) $_SESSION['user']['id'];

// =====================================
// CEK REQUEST
// =====================================

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: ../index.php");
    exit;
}

// =====================================
// AMBIL DATA FORM
// =====================================

$book_id = (int) ($_POST['book_id'] ?? 0);
$action = $_POST['action'] ?? '';
$from = $_POST['from'] ?? 'detail';

// Pastikan asal halaman valid
if (!in_array($from, ['detail', 'wishlist'], true)) {
    $from = 'detail';
}

// =====================================
// FUNGSI REDIRECT
// =====================================

function redirectWishlist($book_id, $from, $status)
{
    if ($from === 'wishlist' && $status === 'removed') {
        header("Location: ../pages/wishlist.php");
        exit;
    }

    $url = "../pages/book_detail.php?id=" . $book_id;

    if ($from === 'wishlist') {
        $url .= "&from=wishlist";
    }

    $url .= "&wishlist=" . $status;

    header("Location: " . $url);
    exit;
}

// =====================================
// VALIDASI BOOK ID DAN ACTION
// =====================================

if ($book_id <= 0 || !in_array($action, ['add', 'remove'], true)) {
    header("Location: ../index.php");
    exit;
}

// =====================================
// CEK APAKAH BUKU TERSEDIA
// =====================================

$book_stmt = mysqli_prepare(
    $conn,
    "SELECT id FROM books WHERE id = ? LIMIT 1"
);

if (!$book_stmt) {
    header("Location: ../index.php");
    exit;
}

mysqli_stmt_bind_param($book_stmt, "i", $book_id);
mysqli_stmt_execute($book_stmt);

$book_result = mysqli_stmt_get_result($book_stmt);
$book = mysqli_fetch_assoc($book_result);

mysqli_stmt_close($book_stmt);

if (!$book) {
    header("Location: ../index.php");
    exit;
}

// =====================================
// TAMBAHKAN KE WISHLIST
// =====================================

if ($action === 'add') {

    $stmt = mysqli_prepare(
        $conn,
        "INSERT IGNORE INTO wishlist (user_id, book_id)
         VALUES (?, ?)"
    );

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "ii", $user_id, $book_id);
        $success = mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        if ($success) {
            redirectWishlist($book_id, $from, 'added');
        }
    }
}

// =====================================
// HAPUS DARI WISHLIST
// =====================================

if ($action === 'remove') {

    $stmt = mysqli_prepare(
        $conn,
        "DELETE FROM wishlist
         WHERE user_id = ? AND book_id = ?"
    );

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "ii", $user_id, $book_id);
        $success = mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        if ($success) {
            redirectWishlist($book_id, $from, 'removed');
        }
    }
}

// =====================================
// JIKA GAGAL
// =====================================

redirectWishlist($book_id, $from, 'error');
?>
