
<?php
session_start();
require "../config/database.php";

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != "admin") {
    header("Location: ../pages/login.php");
    exit;
}

if (!isset($_GET['id'])) {
    header("Location: booklist.php");
    exit;
}

$id = (int)$_GET['id'];

$query = mysqli_query($conn, "SELECT * FROM books WHERE id = $id");
$book = mysqli_fetch_assoc($query);

if (!$book) {
    echo "<script>
        alert('Book not found!');
        window.location='booklist.php';
    </script>";
    exit;
}

$category_query = mysqli_query(
    $conn,
    "SELECT * FROM kategori ORDER BY nama_kategori ASC"
);

if (isset($_POST['update'])) {

    $title = mysqli_real_escape_string($conn, trim($_POST['title']));
    $author = mysqli_real_escape_string($conn, trim($_POST['author']));
    $description = mysqli_real_escape_string($conn, trim($_POST['description']));
    $price = (float)$_POST['price'];
    $stock = max(0, (int)($_POST['stock'] ?? 0));
    $category = mysqli_real_escape_string($conn, $_POST['category']);
    $badge = mysqli_real_escape_string($conn, trim($_POST['badge'] ?? ''));

    $is_offer = isset($_POST['is_offer']) ? 1 : 0;
    $is_best_seller = isset($_POST['is_best_seller']) ? 1 : 0;

    $image_name = $book['image'];
    $old_image = $book['image'];
    $new_uploaded_image = false;

    /* UPLOAD GAMBAR */
    if (isset($_FILES['image']) && $_FILES['image']['error'] != UPLOAD_ERR_NO_FILE) {

        if ($_FILES['image']['error'] !== UPLOAD_ERR_OK) {
            $error = "Gambar gagal diupload.";
        } else {

            $image = $_FILES['image']['name'];
            $tmp_name = $_FILES['image']['tmp_name'];

            $extension = strtolower(pathinfo($image, PATHINFO_EXTENSION));
            $allowed = ['jpg', 'jpeg', 'png', 'webp'];

            if (!in_array($extension, $allowed, true)) {
                $error = "Format gambar harus JPG, JPEG, PNG, atau WEBP!";
            } else {

                $upload_folder = "../assets/images/books/";
                $new_image = uniqid('book_', true) . '.' . $extension;

                if (move_uploaded_file($tmp_name, $upload_folder . $new_image)) {
                    $image_name = $new_image;
                    $new_uploaded_image = true;
                } else {
                    $error = "Gambar gagal diupload.";
                }
            }
        }
    }

    /* UPDATE DATABASE */
    if (!isset($error)) {

        mysqli_begin_transaction($conn);

        try {

            /*
             * Jika buku ini dipilih sebagai Best Seller,
             * nonaktifkan status Best Seller buku lainnya.
             */
            if ($is_best_seller === 1) {
                $reset = mysqli_query(
                    $conn,
                    "UPDATE books SET is_best_seller = 0"
                );

                if (!$reset) {
                    throw new Exception(mysqli_error($conn));
                }
            }

            $update = mysqli_query(
                $conn,
                "UPDATE books SET
                    title = '$title',
                    author = '$author',
                    description = '$description',
                    price = '$price',
                    category = '$category',
                    image = '$image_name',
                    badge = '$badge',
                    is_offer = '$is_offer',
                    stock = '$stock',
                    is_best_seller = '$is_best_seller'
                 WHERE id = $id"
            );

            if (!$update) {
                throw new Exception(mysqli_error($conn));
            }

            mysqli_commit($conn);

            /* Hapus gambar lama setelah database berhasil diupdate */
            if (
                $new_uploaded_image &&
                !empty($old_image) &&
                file_exists("../assets/images/books/" . $old_image)
            ) {
                unlink("../assets/images/books/" . $old_image);
            }

            echo "<script>
                alert('Book successfully updated!');
                window.location='booklist.php';
            </script>";
            exit;

        } catch (Exception $e) {

            mysqli_rollback($conn);

            /* Hapus gambar baru jika update database gagal */
            if (
                $new_uploaded_image &&
                file_exists("../assets/images/books/" . $image_name)
            ) {
                unlink("../assets/images/books/" . $image_name);
            }

            $error = "Failed to update book: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>BOOKISSE | Edit Book</title>

    <link rel="stylesheet" href="css/admin.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Irish+Grover&display=swap" rel="stylesheet">
</head>

<body>

<?php include "include/sidebar.php"; ?>

<div class="main">

    <?php include "include/header.php"; ?>

    <div class="content">

        <h2>Edit Book</h2>

        <p style="color:#777; margin-bottom:25px;">
            Update book information
        </p>

        <?php if (isset($error)) { ?>
            <div style="
                background:#ffdede;
                color:#b30000;
                padding:15px;
                border-radius:8px;
                margin-bottom:20px;
            ">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php } ?>

        <div class="table-box">

            <form method="POST" enctype="multipart/form-data">

                <label>Book Title</label>
                <input
                    type="text"
                    name="title"
                    value="<?php echo htmlspecialchars($book['title']); ?>"
                    required
                    style="width:100%;padding:12px;margin:8px 0 20px;border:1px solid #ddd;border-radius:8px;"
                >

                <label>Author</label>
                <input
                    type="text"
                    name="author"
                    value="<?php echo htmlspecialchars($book['author']); ?>"
                    required
                    style="width:100%;padding:12px;margin:8px 0 20px;border:1px solid #ddd;border-radius:8px;"
                >

                <label>Description</label>
                <textarea
                    name="description"
                    rows="5"
                    style="width:100%;padding:12px;margin:8px 0 20px;border:1px solid #ddd;border-radius:8px;resize:vertical;"
                ><?php echo htmlspecialchars($book['description']); ?></textarea>

                <label>Price</label>
                <input
                    type="number"
                    name="price"
                    step="0.01"
                    min="0"
                    value="<?php echo htmlspecialchars($book['price']); ?>"
                    required
                    style="width:100%;padding:12px;margin:8px 0 20px;border:1px solid #ddd;border-radius:8px;"
                >

                <label>Stock Quantity</label>
                <input
                    type="number"
                    name="stock"
                    min="0"
                    value="<?php echo (int)($book['stock'] ?? 0); ?>"
                    required
                    style="width:100%;padding:12px;margin:8px 0 20px;border:1px solid #ddd;border-radius:8px;"
                >

                <label>Category</label>
                <select
                    name="category"
                    required
                    style="width:100%;padding:12px;margin:8px 0 20px;border:1px solid #ddd;border-radius:8px;background:white;"
                >
                    <?php while ($category = mysqli_fetch_assoc($category_query)) { ?>
                        <option
                            value="<?php echo htmlspecialchars($category['nama_kategori']); ?>"
                            <?php echo ($book['category'] == $category['nama_kategori']) ? 'selected' : ''; ?>
                        >
                            <?php echo htmlspecialchars($category['nama_kategori']); ?>
                        </option>
                    <?php } ?>
                </select>

                <label>Badge</label>
                <input
                    type="text"
                    name="badge"
                    value="<?php echo htmlspecialchars($book['badge'] ?? ''); ?>"
                    placeholder="Example: NEW, LIMITED, PROMO"
                    style="width:100%;padding:12px;margin:8px 0 20px;border:1px solid #ddd;border-radius:8px;"
                >

                <label style="display:flex;align-items:center;gap:10px;margin-bottom:20px;">
                    <input
                        type="checkbox"
                        name="is_offer"
                        value="1"
                        <?php echo ((int)$book['is_offer'] === 1) ? 'checked' : ''; ?>
                    >
                    This book is on offer
                </label>

                <div style="
                    background:#fff8e8;
                    border:1px solid #f4d58a;
                    padding:15px;
                    border-radius:10px;
                    margin-bottom:20px;
                ">

                    <label style="
                        display:flex;
                        align-items:center;
                        gap:10px;
                        font-weight:bold;
                        color:#6b4810;
                    ">
                        <input
                            type="checkbox"
                            name="is_best_seller"
                            value="1"
                            <?php echo ((int)($book['is_best_seller'] ?? 0) === 1) ? 'checked' : ''; ?>
                        >

                        <i class="fa-solid fa-star"></i>
                        Set as Best Seller
                    </label>

                    <p style="font-size:13px;color:#806b45;margin:8px 0 0 25px;">
                        Only one book can be selected as Best Seller.
                        Selecting this book will replace the previous Best Seller.
                    </p>

                </div>

                <label>Current Image</label>

                <div style="margin:10px 0 20px;">
                    <?php if (!empty($book['image'])) { ?>
                        <img
                            src="../assets/images/books/<?php echo htmlspecialchars($book['image']); ?>"
                            width="100"
                            height="130"
                            style="object-fit:cover;border-radius:8px;"
                            alt="Current book cover"
                        >
                    <?php } else { ?>
                        <p>No image</p>
                    <?php } ?>
                </div>

                <label>Change Image</label>
                <input
                    type="file"
                    name="image"
                    accept=".jpg,.jpeg,.png,.webp"
                    style="display:block;margin:10px 0 25px;"
                >

                <button
                    type="submit"
                    name="update"
                    style="
                        background:#F4B43A;
                        color:#2B1033;
                        padding:12px 20px;
                        border:none;
                        border-radius:8px;
                        font-weight:bold;
                        cursor:pointer;
                    "
                >
                    <i class="fa-solid fa-save"></i>
                    Update Book
                </button>

                <a
                    href="booklist.php"
                    style="margin-left:15px;text-decoration:none;color:#2B1033;"
                >
                    Cancel
                </a>

            </form>
        </div>
    </div>
</div>
</body>
</html>
