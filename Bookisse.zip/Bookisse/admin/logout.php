
<?php
session_start();

// Kosongkan seluruh session
$_SESSION = [];

// Hapus session
session_unset();
session_destroy();

// Arahkan admin ke halaman login
header("Location: ../pages/login.php");
exit;
?>
