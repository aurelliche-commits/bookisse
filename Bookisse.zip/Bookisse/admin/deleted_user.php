<?php

session_start();
require "../config/database.php";

/* =========================
   CEK ADMIN
========================= */

if (!isset($_SESSION['user'])) {

    header("Location: ../pages/login.php");
    exit;

}

if ($_SESSION['user']['role'] != "admin") {

    header("Location: ../index.php");
    exit;

}

/* =========================
   CEK ID USER
========================= */

if (!isset($_GET['id'])) {

    header("Location: user.php");
    exit;

}

$id = (int) $_GET['id'];


/* =========================
   JANGAN HAPUS ADMIN
========================= */

$check = mysqli_query(
    $conn,
    "
    SELECT role
    FROM users
    WHERE id='$id'
    "
);

$user = mysqli_fetch_assoc($check);


if (!$user) {

    echo "<script>

        alert('User not found!');

        window.location='user.php';

    </script>";

    exit;

}


if ($user['role'] == 'admin') {

    echo "<script>

        alert('Admin account cannot be deleted!');

        window.location='user.php';

    </script>";

    exit;

}


/* =========================
   HAPUS USER
========================= */

$delete = mysqli_query(
    $conn,
    "
    DELETE FROM users
    WHERE id='$id'
    "
);


if ($delete) {

    echo "<script>

        alert('User successfully deleted!');

        window.location='user.php';

    </script>";

    exit;

} else {

    echo "<script>

        alert('Failed to delete user: " .
        addslashes(mysqli_error($conn)) .
        "');

        window.location='user.php';

    </script>";

    exit;

}

?>