
<?php
session_start();
require "../config/database.php";

/* =========================
   CEK ADMIN
========================= */

if (!isset($_SESSION['user'])) {
    header("Location: ../pages/login.php");
    exit;
}

if ($_SESSION['user']['role'] != "admin") {
    header("Location: ../index.php");
    exit;
}

if (!isset($_GET['id'])) {
    header("Location: orders.php");
    exit;
}

$order_id = (int) $_GET['id'];

/* =========================
   PROSES VERIFIKASI PEMBAYARAN
========================= */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $action = $_POST['payment_action'] ?? '';

    if (in_array($action, ['approve', 'reject'], true)) {

        mysqli_begin_transaction($conn);

        try {

            // Kunci pesanan agar tidak diproses dua kali
            $stmt = mysqli_prepare($conn, "
                SELECT payment_status
                FROM orders
                WHERE id = ?
                FOR UPDATE
            ");

            mysqli_stmt_bind_param($stmt, "i", $order_id);
            mysqli_stmt_execute($stmt);

            $result = mysqli_stmt_get_result($stmt);
            $current_order = mysqli_fetch_assoc($result);

            if (
                !$current_order ||
                $current_order['payment_status'] !== 'waiting_verification'
            ) {
                throw new Exception(
                    "Order is not waiting for payment verification."
                );
            }

            if ($action === 'approve') {

                // SETUJUI PEMBAYARAN
                $stmt = mysqli_prepare($conn, "
                    UPDATE orders
                    SET
                        payment_status = 'paid',
                        paid_at = NOW(),
                        status = 'processing'
                    WHERE id = ?
                    AND payment_status = 'waiting_verification'
                ");

                mysqli_stmt_bind_param($stmt, "i", $order_id);
                mysqli_stmt_execute($stmt);

                if (mysqli_stmt_affected_rows($stmt) !== 1) {
                    throw new Exception("Failed to approve payment.");
                }

            } else {

                // TOLAK PEMBAYARAN DAN KEMBALIKAN STOK
                $items_stmt = mysqli_prepare($conn, "
                    SELECT book_id, quantity
                    FROM order_items
                    WHERE order_id = ?
                ");

                mysqli_stmt_bind_param(
                    $items_stmt,
                    "i",
                    $order_id
                );

                mysqli_stmt_execute($items_stmt);

                $items_result = mysqli_stmt_get_result($items_stmt);

                while ($item = mysqli_fetch_assoc($items_result)) {

                    $book_id = (int) $item['book_id'];
                    $quantity = (int) $item['quantity'];

                    $stock_stmt = mysqli_prepare($conn, "
                        UPDATE books
                        SET stock = stock + ?
                        WHERE id = ?
                    ");

                    mysqli_stmt_bind_param(
                        $stock_stmt,
                        "ii",
                        $quantity,
                        $book_id
                    );

                    mysqli_stmt_execute($stock_stmt);

                    if (mysqli_stmt_affected_rows($stock_stmt) !== 1) {
                        throw new Exception(
                            "Failed to restore book stock."
                        );
                    }
                }

                // UPDATE STATUS PENOLAKAN
                $stmt = mysqli_prepare($conn, "
                    UPDATE orders
                    SET
                        payment_status = 'rejected',
                        status = 'cancelled',
                        paid_at = NULL
                    WHERE id = ?
                    AND payment_status = 'waiting_verification'
                ");

                mysqli_stmt_bind_param($stmt, "i", $order_id);
                mysqli_stmt_execute($stmt);

                if (mysqli_stmt_affected_rows($stmt) !== 1) {
                    throw new Exception("Failed to reject payment.");
                }
            }

            mysqli_commit($conn);

            $message = $action === 'approve'
                ? 'Payment approved successfully!'
                : 'Payment rejected. Book stock has been restored.';

            echo "<script>
                alert(" . json_encode($message) . ");
                window.location='order_detail.php?id=$order_id';
            </script>";

            exit;

        } catch (Throwable $e) {

            mysqli_rollback($conn);

            echo "<script>
                alert(" . json_encode(
                    'Error: ' . $e->getMessage()
                ) . ");
                window.location='order_detail.php?id=$order_id';
            </script>";

            exit;
        }
    }
}

/* =========================
   AMBIL DATA ORDER
========================= */

$stmt = mysqli_prepare($conn, "
    SELECT
        orders.*,
        users.name,
        users.email,
        users.phone,
        users.address
    FROM orders
    JOIN users ON orders.user_id = users.id
    WHERE orders.id = ?
");

mysqli_stmt_bind_param($stmt, "i", $order_id);
mysqli_stmt_execute($stmt);

$order_query = mysqli_stmt_get_result($stmt);
$order = mysqli_fetch_assoc($order_query);

if (!$order) {
    echo "<script>
        alert('Order not found!');
        window.location='orders.php';
    </script>";
    exit;
}

/* =========================
   KODE TRANSAKSI
========================= */

$order_code = !empty($order['order_code'])
    ? $order['order_code']
    : '#' . $order['id'];

/* =========================
   AMBIL ORDER ITEMS
========================= */

$items_stmt = mysqli_prepare($conn, "
    SELECT
        order_items.*,
        books.title,
        books.author,
        books.image
    FROM order_items
    JOIN books ON order_items.book_id = books.id
    WHERE order_items.order_id = ?
");

mysqli_stmt_bind_param($items_stmt, "i", $order_id);
mysqli_stmt_execute($items_stmt);

$items_query = mysqli_stmt_get_result($items_stmt);

/* =========================
   UPDATE STATUS PESANAN
   ADMIN MAKSIMAL SHIPPED
========================= */

if (isset($_POST['update_status'])) {

    $status = $_POST['status'] ?? '';

    // Admin hanya boleh mengubah status menjadi processing atau shipped.
    // Status complete hanya boleh diubah oleh pembeli.
    $allowed_status = ['processing', 'shipped'];

    if (
        in_array($status, $allowed_status, true) &&
        $order['payment_status'] === 'paid' &&
        in_array($order['status'], ['pending', 'processing'], true)
    ) {

        $stmt = mysqli_prepare($conn, "
            UPDATE orders
            SET status = ?
            WHERE id = ?
            AND payment_status = 'paid'
            AND status IN ('pending', 'processing')
        ");

        mysqli_stmt_bind_param($stmt, "si", $status, $order_id);
        mysqli_stmt_execute($stmt);

        if (mysqli_stmt_affected_rows($stmt) === 1) {
            $message = 'Order status updated successfully!';
        } else {
            $message = 'Status could not be updated. Please check the current order status.';
        }

        echo "<script>
            alert(" . json_encode($message) . ");
            window.location='order_detail.php?id=$order_id';
        </script>";

        exit;

    } else {

        echo "<script>
            alert('Admin can only update order status until shipped!');
            window.location='order_detail.php?id=$order_id';
        </script>";

        exit;
    }
}

/* =========================
   LOKASI BUKTI PEMBAYARAN
========================= */

$proof_name = basename($order['payment_proof'] ?? '');

$proof_path = "../uploads/payment_proofs/" . $proof_name;

$proof_exists = (
    $proof_name !== '' &&
    is_file(__DIR__ . "/../uploads/payment_proofs/" . $proof_name)
);

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>BOOKISSE | Order Detail</title>

<link
    rel="stylesheet"
    href="css/admin.css?v=<?php echo time(); ?>"
>

<link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"
>

<style>

.detail-box {
    background:white;
    padding:25px;
    border-radius:15px;
    margin-bottom:25px;
}

.detail-grid {
    display:grid;
    grid-template-columns:1fr 1fr;
    gap:20px;
}

.detail-item {
    background:#f7f7f7;
    padding:15px;
    border-radius:10px;
}

.detail-item span {
    display:block;
    color:#777;
    font-size:13px;
    margin-bottom:5px;
}

.items {
    margin-top:20px;
}

.item {
    display:flex;
    align-items:center;
    gap:15px;
    padding:15px 0;
    border-bottom:1px solid #ddd;
}

.item img {
    width:60px;
    height:80px;
    object-fit:cover;
    border-radius:7px;
}

.item-info {
    flex:1;
}

.status-form {
    margin-top:25px;
}

.status-form select {
    padding:12px;
    border-radius:8px;
    border:1px solid #ddd;
    margin-right:10px;
}

.status-form button {
    padding:12px 20px;
    border:none;
    border-radius:8px;
    background:#F4B43A;
    color:#2B1033;
    font-weight:bold;
    cursor:pointer;
}

@media (max-width: 600px) {

    .detail-grid {
        grid-template-columns:1fr;
    }

    .item {
        flex-wrap:wrap;
    }

}

</style>

</head>

<body>

<?php include "include/sidebar.php"; ?>

<div class="main">

<?php include "include/header.php"; ?>

<div class="content">

<!-- ORDER TITLE -->

<h2>
    Order <?= htmlspecialchars(
        $order_code,
        ENT_QUOTES,
        'UTF-8'
    ); ?>
</h2>

<p style="color:#777;">
    Order details and shipping management.
</p>

<!-- CUSTOMER INFORMATION -->

<div class="detail-box">

<h3>Customer Information</h3>

<div class="detail-grid">

    <div class="detail-item">
        <span>Name</span>
        <strong>
            <?= htmlspecialchars($order['name']); ?>
        </strong>
    </div>

    <div class="detail-item">
        <span>Email</span>
        <strong>
            <?= htmlspecialchars($order['email']); ?>
        </strong>
    </div>

    <div class="detail-item">
        <span>Phone</span>
        <strong>
            <?= htmlspecialchars($order['phone'] ?? '-'); ?>
        </strong>
    </div>

    <div class="detail-item">
        <span>Address</span>
        <strong>
            <?= htmlspecialchars($order['address'] ?? '-'); ?>
        </strong>
    </div>

</div>

</div>

<!-- PAYMENT INFORMATION -->

<div class="detail-box">

<h3>Payment Information</h3>

<div class="detail-grid">

    <div class="detail-item">
        <span>Payment Status</span>
        <strong>
            <?= strtoupper(
                htmlspecialchars($order['payment_status'])
            ); ?>
        </strong>
    </div>

    <div class="detail-item">
        <span>Payment Method</span>
        <strong>
            <?= htmlspecialchars($order['payment_method'] ?? '-'); ?>
        </strong>
    </div>

    <div class="detail-item">
        <span>Paid At</span>
        <strong>
            <?= !empty($order['paid_at'])
                ? date(
                    "d M Y H:i",
                    strtotime($order['paid_at'])
                )
                : '-';
            ?>
        </strong>
    </div>

    <div class="detail-item">
        <span>Total</span>
        <strong>
            Rp <?= number_format(
                (float)$order['total'],
                2,
                '.',
                ','
            ); ?>
        </strong>
    </div>

</div>

</div>

<!-- PAYMENT PROOF -->

<div class="detail-box">

    <h3>Payment Proof</h3>

    <div class="detail-grid">

        <div class="detail-item">

            <span>Payment Method</span>

            <strong>
                <?= htmlspecialchars($order['payment_method'] ?? '-'); ?>

                <?php if (!empty($order['payment_provider'])) { ?>
                    - <?= htmlspecialchars($order['payment_provider']); ?>
                <?php } ?>
            </strong>

        </div>

        <div class="detail-item">

            <span>Verification Status</span>

            <strong>
                <?= strtoupper(
                    htmlspecialchars($order['payment_status'])
                ); ?>
            </strong>

        </div>

    </div>

    <div style="margin-top:20px;">

        <?php if ($proof_exists) { ?>

            <?php
            $extension = strtolower(
                pathinfo($proof_name, PATHINFO_EXTENSION)
            );
            ?>

            <?php if (in_array($extension, ['jpg', 'jpeg', 'png', 'webp'])) { ?>

                <img
                    src="<?= htmlspecialchars($proof_path); ?>"
                    alt="Payment Proof"
                    style="
                        display:block;
                        max-width:100%;
                        max-height:450px;
                        object-fit:contain;
                        border-radius:12px;
                        border:1px solid #ddd;
                        margin-bottom:15px;
                    "
                >

            <?php } elseif ($extension === 'pdf') { ?>

                <p>Customer uploaded a PDF payment proof.</p>

            <?php } ?>

            <a
                href="<?= htmlspecialchars($proof_path); ?>"
                target="_blank"
                style="
                    display:inline-block;
                    padding:10px 16px;
                    background:#4B2154;
                    color:white;
                    border-radius:8px;
                    text-decoration:none;
                    font-weight:bold;
                "
            >
                <i class="fa-solid fa-eye"></i>
                View / Download Proof
            </a>

        <?php } else { ?>

            <p style="color:#c0392b;">
                No payment proof uploaded.
            </p>

        <?php } ?>

    </div>

    <!-- APPROVE / REJECT -->

    <?php if (
        $order['payment_status'] === 'waiting_verification' &&
        $proof_exists
    ) { ?>

        <div style="
            display:flex;
            gap:12px;
            margin-top:25px;
            flex-wrap:wrap;
        ">

            <form method="POST"
                onsubmit="return confirm('Approve this payment?');">

                <button
                    type="submit"
                    name="payment_action"
                    value="approve"
                    style="
                        padding:12px 20px;
                        border:none;
                        border-radius:8px;
                        background:#28a745;
                        color:white;
                        font-weight:bold;
                        cursor:pointer;
                    "
                >
                    <i class="fa-solid fa-check"></i>
                    Approve Payment
                </button>

            </form>

            <form method="POST"
                onsubmit="return confirm('Reject this payment and restore book stock?');">

                <button
                    type="submit"
                    name="payment_action"
                    value="reject"
                    style="
                        padding:12px 20px;
                        border:none;
                        border-radius:8px;
                        background:#dc3545;
                        color:white;
                        font-weight:bold;
                        cursor:pointer;
                    "
                >
                    <i class="fa-solid fa-xmark"></i>
                    Reject Payment
                </button>

            </form>

        </div>

    <?php } ?>

</div>

<!-- ORDER ITEMS -->

<div class="detail-box">

<h3>Order Items</h3>

<div class="items">

<?php while ($item = mysqli_fetch_assoc($items_query)) { ?>

    <div class="item">

        <img
            src="../assets/images/books/<?= htmlspecialchars($item['image']); ?>"
            alt="<?= htmlspecialchars($item['title']); ?>"
        >

        <div class="item-info">

            <strong>
                <?= htmlspecialchars($item['title']); ?>
            </strong>

            <br>

            <small>
                <?= htmlspecialchars($item['author']); ?>
            </small>

            <br>

            <small>
                Qty: <?= (int)$item['quantity']; ?>
            </small>

        </div>

        <strong>
            Rp <?= number_format(
                (float)$item['price'] * (int)$item['quantity'],
                2,
                '.',
                ','
            ); ?>
        </strong>

    </div>

<?php } ?>

</div>

</div>

<!-- ORDER STATUS -->

<div class="detail-box">

    <h3>Order Status</h3>

    <p>
        Current Status:

        <strong>
            <?= ucfirst(htmlspecialchars($order['status'])); ?>
        </strong>
    </p>

    <?php if (
        $order['payment_status'] === 'paid' &&
        in_array($order['status'], ['pending', 'processing'], true)
    ) { ?>

        <form method="POST" class="status-form">

            <select name="status" required>

                <option value="">
                    -- Update Status --
                </option>

                <option value="processing">
                    Processing
                </option>

                <option value="shipped">
                    Shipped
                </option>

            </select>

            <button
                type="submit"
                name="update_status"
            >
                <i class="fa-solid fa-save"></i>
                Update Status
            </button>

        </form>

    <?php } elseif ($order['status'] === 'shipped') { ?>

        <p style="color:#28a745; margin-top:15px;">
            <i class="fa-solid fa-truck"></i>
            Order has been shipped. Waiting for customer confirmation.
        </p>

    <?php } elseif ($order['status'] === 'complete') { ?>

        <p style="color:#28a745; margin-top:15px;">
            <i class="fa-solid fa-check-circle"></i>
            Order has been completed by the customer.
        </p>

    <?php } elseif ($order['status'] === 'cancelled') { ?>

        <p style="color:#dc3545; margin-top:15px;">
            This order has been cancelled.
        </p>

    <?php } else { ?>

        <p style="color:#777; margin-top:15px;">
            Payment must be approved before processing this order.
        </p>

    <?php } ?>

</div>

<a
    href="orders.php"
    style="
        text-decoration:none;
        color:#2B1033;
    "
>
    ← Back to Orders
</a>

</div>

</div>

</body>
</html>
