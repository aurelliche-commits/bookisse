
<?php
session_start();
require "../config/database.php";

/* CEK LOGIN ADMIN */
if (!isset($_SESSION['user'])) {
    header("Location: ../pages/login.php");
    exit;
}

if ($_SESSION['user']['role'] != "admin") {
    header("Location: ../index.php");
    exit;
}

/* PROSES BEST SELLER */
$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['best_seller_action'])) {

    $action = $_POST['best_seller_action'];
    $book_id = (int) ($_POST['book_id'] ?? 0);

    if ($action === 'set' && $book_id > 0) {

        mysqli_begin_transaction($conn);

        try {
            // Pastikan buku tersedia
            $check = mysqli_prepare(
                $conn,
                "SELECT id FROM books WHERE id = ? LIMIT 1"
            );

            mysqli_stmt_bind_param($check, "i", $book_id);
            mysqli_stmt_execute($check);
            $result = mysqli_stmt_get_result($check);
            $bookExists = mysqli_fetch_assoc($result);
            mysqli_stmt_close($check);

            if (!$bookExists) {
                throw new Exception("Book not found.");
            }

            // Hapus status Best Seller sebelumnya
            mysqli_query(
                $conn,
                "UPDATE books SET is_best_seller = 0"
            );

            // Tetapkan buku baru
            $update = mysqli_prepare(
                $conn,
                "UPDATE books SET is_best_seller = 1 WHERE id = ?"
            );

            mysqli_stmt_bind_param($update, "i", $book_id);
            mysqli_stmt_execute($update);
            mysqli_stmt_close($update);

            mysqli_commit($conn);

            $message = "Best Seller successfully updated!";

        } catch (Throwable $e) {
            mysqli_rollback($conn);
            $message = "Failed to update Best Seller.";
        }

    } elseif ($action === 'remove' && $book_id > 0) {

        $remove = mysqli_prepare(
            $conn,
            "UPDATE books SET is_best_seller = 0 WHERE id = ?"
        );

        mysqli_stmt_bind_param($remove, "i", $book_id);
        mysqli_stmt_execute($remove);
        mysqli_stmt_close($remove);

        $message = "Best Seller successfully removed.";
    }
}

/* DATA BUKU */
$query = mysqli_query(
    $conn,
    "SELECT * FROM books ORDER BY id DESC"
);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>BOOKISSE | Books</title>

    <link rel="stylesheet"
        href="css/admin.css?v=<?php echo time(); ?>">

    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">

    <link href="https://fonts.googleapis.com/css2?family=Irish+Grover&display=swap"
        rel="stylesheet">

    <style>
        .best-seller-status {
            display: inline-block;
            padding: 6px 10px;
            border-radius: 6px;
            background: #fff1bd;
            color: #704500;
            font-size: 12px;
            font-weight: bold;
            white-space: nowrap;
        }

        .best-seller-actions {
            display: flex;
            flex-direction: column;
            gap: 7px;
            min-width: 145px;
        }

        .best-seller-actions button {
            padding: 8px 10px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-family: Arial, sans-serif;
            font-size: 12px;
            font-weight: bold;
        }

        .set-best-btn {
            background: #F4B43A;
            color: #2B1033;
        }

        .remove-best-btn {
            background: #dc3545;
            color: white;
        }

        .best-seller-actions button:hover {
            opacity: .85;
        }

        .best-message {
            padding: 12px 16px;
            margin-bottom: 20px;
            border-radius: 8px;
            background: #e8f7e9;
            color: #216b2a;
            font-family: Arial, sans-serif;
        }

        .table-box {
            overflow-x: auto;
        }
    </style>
</head>

<body>

<?php include "include/sidebar.php"; ?>

<div class="main">

    <?php include "include/header.php"; ?>

    <div class="content">

        <div class="page-title">

            <div>
                <h2>Books</h2>
                <p>Manage all books</p>
            </div>

            <a href="add_book.php" class="add-btn">
                <i class="fa-solid fa-plus"></i>
                Add Book
            </a>

        </div>

        <?php if (!empty($message)): ?>
            <div class="best-message">
                <?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8'); ?>
            </div>
        <?php endif; ?>

        <div class="table-box">

            <table>

                <thead>
                    <tr>
                        <th>No</th>
                        <th>Image</th>
                        <th>Title</th>
                        <th>Author</th>
                        <th>Category</th>
                        <th>Price</th>
                        <th>Stock</th>
                        <th>Badge</th>
                        <th>Offer</th>
                        <th>Best Seller</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>

                <?php
                $no = 1;

                if ($query && mysqli_num_rows($query) > 0):

                    while ($book = mysqli_fetch_assoc($query)):
                        $stock = (int) $book['stock'];
                        $isBestSeller = (int) $book['is_best_seller'] === 1;
                ?>

                    <tr>

                        <td><?= $no++; ?></td>

                        <td>
                            <?php if (!empty($book['image'])): ?>
                                <img
                                    src="../assets/images/books/<?= htmlspecialchars($book['image'], ENT_QUOTES, 'UTF-8'); ?>"
                                    width="60"
                                    height="80"
                                    style="object-fit:cover; border-radius:6px;">
                            <?php else: ?>
                                No Image
                            <?php endif; ?>
                        </td>

                        <td>
                            <?= htmlspecialchars($book['title'], ENT_QUOTES, 'UTF-8'); ?>
                        </td>

                        <td>
                            <?= htmlspecialchars($book['author'], ENT_QUOTES, 'UTF-8'); ?>
                        </td>

                        <td>
                            <?= htmlspecialchars($book['category'], ENT_QUOTES, 'UTF-8'); ?>
                        </td>

                        <td>
                            Rp <?= number_format((float)$book['price'], 0, ',', '.'); ?>
                        </td>

                        <td>
                            <?php
                            if ($stock == 0) {
                                echo '<span style="color:red;font-weight:bold;">Out of Stock</span>';
                            } elseif ($stock <= 10) {
                                echo '<span style="color:#d97706;font-weight:bold;">Low Stock (' . $stock . ')</span>';
                            } else {
                                echo '<span style="color:green;font-weight:bold;">In Stock (' . $stock . ')</span>';
                            }
                            ?>
                        </td>

                        <td>
                            <?= htmlspecialchars($book['badge'] ?? '', ENT_QUOTES, 'UTF-8'); ?>
                        </td>

                        <td>
                            <?= ((int)$book['is_offer'] === 1) ? 'Yes' : 'No'; ?>
                        </td>

                        <!-- BEST SELLER -->
                        <td>

                            <?php if ($isBestSeller): ?>

                                <div class="best-seller-actions">

                                    <span class="best-seller-status">
                                        <i class="fa-solid fa-crown"></i>
                                        Best Seller
                                    </span>

                                    <form method="POST"
                                          onsubmit="return confirm('Remove this book from Best Seller?');">

                                        <input type="hidden"
                                               name="book_id"
                                               value="<?= (int)$book['id']; ?>">

                                        <button
                                            type="submit"
                                            name="best_seller_action"
                                            value="remove"
                                            class="remove-best-btn">

                                            Remove Best Seller

                                        </button>

                                    </form>

                                </div>

                            <?php else: ?>

                                <form method="POST"
                                      onsubmit="return confirm('Set this book as the new Best Seller?');">

                                    <input type="hidden"
                                           name="book_id"
                                           value="<?= (int)$book['id']; ?>">

                                    <button
                                        type="submit"
                                        name="best_seller_action"
                                        value="set"
                                        class="set-best-btn">

                                        <i class="fa-solid fa-crown"></i>
                                        Set as Best Seller

                                    </button>

                                </form>

                            <?php endif; ?>

                        </td>

                        <!-- ACTION -->
                        <td>

                            <a href="edit.php?id=<?= (int)$book['id']; ?>">
                                <i class="fa-solid fa-pen-to-square"></i>
                            </a>

                            <a
                                href="deleted.php?id=<?= (int)$book['id']; ?>"
                                onclick="return confirm('Are you sure you want to delete this book?');">

                                <i class="fa-solid fa-trash"></i>

                            </a>

                        </td>

                    </tr>

                <?php
                    endwhile;

                else:
                ?>

                    <tr>
                        <td colspan="11" style="text-align:center;">
                            No books found.
                        </td>
                    </tr>

                <?php endif; ?>

                </tbody>

            </table>

        </div>

    </div>

</div>

</body>
</html>
