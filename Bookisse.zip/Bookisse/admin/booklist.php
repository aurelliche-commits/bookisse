<?php
session_start();
require "../config/database.php";

if (!isset($_SESSION['user'])) {
    header("Location: ../pages/login.php");
    exit;
}

if ($_SESSION['user']['role'] != "admin") {
    header("Location: ../index.php");
    exit;
}

$query = mysqli_query($conn, "SELECT * FROM books ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BOOKISSE | Books</title>

    <link rel="stylesheet" href="css/admin.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Irish+Grover&display=swap" rel="stylesheet">
</head>

<body>

<?php include "include/sidebar.php"; ?>

<div class="main">

    <?php include "include/header.php"; ?>

    <div class="content">

        <div class="page-title">
            <div>
                <h2>Books</h2>
                <p>Manage all books</p>
            </div>

            <a href="add_book.php" class="add-btn">
                <i class="fa-solid fa-plus"></i>
                Add Book
            </a>
        </div>

        <div class="table-box">

            <table>
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Image</th>
                        <th>Title</th>
                        <th>Author</th>
                        <th>Category</th>
                        <th>Price</th>
                        <th>Stock</th>
                        <th>Badge</th>
                        <th>Offer</th>
                        <th>Best Seller</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>
                <?php
                $no = 1;

                if ($query && mysqli_num_rows($query) > 0) {
                    while ($book = mysqli_fetch_assoc($query)) {
                ?>

                    <tr>
                        <td><?php echo $no++; ?></td>

                        <td>
                            <?php if (!empty($book['image'])) { ?>
                                <img
                                    src="../assets/images/books/<?php echo htmlspecialchars($book['image']); ?>"
                                    width="60"
                                    height="80"
                                    style="object-fit:cover; border-radius:6px;"
                                    alt="Book cover"
                                >
                            <?php } else { ?>
                                No Image
                            <?php } ?>
                        </td>

                        <td><?php echo htmlspecialchars($book['title']); ?></td>
                        <td><?php echo htmlspecialchars($book['author']); ?></td>
                        <td><?php echo htmlspecialchars($book['category']); ?></td>

                        <td>
                            Rp <?php echo number_format((float)$book['price'], 0, ',', '.'); ?>
                        </td>

                        <td>
                            <?php
                            $stock = (int)$book['stock'];

                            if ($stock == 0) {
                                echo '<span style="color:red;font-weight:bold;">Out of Stock</span>';
                            } elseif ($stock <= 10) {
                                echo '<span style="color:#d97706;font-weight:bold;">Low Stock (' . $stock . ')</span>';
                            } else {
                                echo '<span style="color:green;font-weight:bold;">In Stock (' . $stock . ')</span>';
                            }
                            ?>
                        </td>

                        <td>
                            <?php
                            echo !empty($book['badge'])
                                ? htmlspecialchars($book['badge'])
                                : '-';
                            ?>
                        </td>

                        <td>
                            <?php echo ((int)$book['is_offer'] === 1) ? 'Yes' : 'No'; ?>
                        </td>

                        <td>
                            <?php if ((int)$book['is_best_seller'] === 1) { ?>
                                <span style="
                                    display:inline-block;
                                    background:#fff0c2;
                                    color:#8a5a00;
                                    padding:6px 10px;
                                    border-radius:20px;
                                    font-size:12px;
                                    font-weight:bold;
                                ">
                                    <i class="fa-solid fa-star"></i> Yes
                                </span>
                            <?php } else { ?>
                                <span style="
                                    display:inline-block;
                                    background:#eeeeee;
                                    color:#666;
                                    padding:6px 10px;
                                    border-radius:20px;
                                    font-size:12px;
                                ">
                                    No
                                </span>
                            <?php } ?>
                        </td>

                        <td>
                            <a
                                href="edit.php?id=<?php echo (int)$book['id']; ?>"
                                title="Edit Book"
                            >
                                <i class="fa-solid fa-pen-to-square"></i>
                            </a>

                            <a
                                href="deleted.php?id=<?php echo (int)$book['id']; ?>"
                                onclick="return confirm('Are you sure you want to delete this book?');"
                                title="Delete Book"
                            >
                                <i class="fa-solid fa-trash"></i>
                            </a>
                        </td>
                    </tr>

                <?php
                    }
                } else {
                ?>
                    <tr>
                        <td colspan="11" style="text-align:center;">
                            No books found.
                        </td>
                    </tr>
                <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</body>
</html>
