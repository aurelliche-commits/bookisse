
<?php
session_start();
require "../config/database.php";

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != "admin") {
    header("Location: ../pages/login.php");
    exit;
}

/* AMBIL DATA KATEGORI */
$category_query = mysqli_query(
    $conn,
    "SELECT * FROM kategori ORDER BY nama_kategori ASC"
);

/* PROSES TAMBAH BUKU */
if (isset($_POST['submit'])) {

    $title = mysqli_real_escape_string($conn, trim($_POST['title']));
    $author = mysqli_real_escape_string($conn, trim($_POST['author']));
    $description = mysqli_real_escape_string($conn, trim($_POST['description']));
    $price = (float)$_POST['price'];
    $stock = max(0, (int)($_POST['stock'] ?? 0));
    $category = mysqli_real_escape_string($conn, $_POST['category']);
    $badge = mysqli_real_escape_string($conn, trim($_POST['badge'] ?? ''));

    $is_offer = isset($_POST['is_offer']) ? 1 : 0;

    /* UPLOAD GAMBAR */
    if (!isset($_FILES['image']) || $_FILES['image']['error'] != UPLOAD_ERR_OK) {

        $error = "Silakan pilih gambar buku!";

    } else {

        $image = $_FILES['image']['name'];
        $tmp_name = $_FILES['image']['tmp_name'];

        $extension = strtolower(pathinfo($image, PATHINFO_EXTENSION));
        $allowed = ['jpg', 'jpeg', 'png', 'webp'];

        if (!in_array($extension, $allowed, true)) {

            $error = "Format gambar harus JPG, JPEG, PNG, atau WEBP!";

        } else {

            $upload_folder = "../assets/images/books/";
            $new_image = uniqid('book_', true) . '.' . $extension;

            if (move_uploaded_file($tmp_name, $upload_folder . $new_image)) {

                /*
                 * Buku baru otomatis bukan Best Seller.
                 * Status Best Seller hanya diatur melalui Edit Book.
                 */
                $is_best_seller = 0;

                $query = mysqli_query($conn, "
                    INSERT INTO books
                    (
                        title,
                        author,
                        description,
                        price,
                        category,
                        image,
                        badge,
                        is_offer,
                        stock,
                        is_best_seller
                    )
                    VALUES
                    (
                        '$title',
                        '$author',
                        '$description',
                        '$price',
                        '$category',
                        '$new_image',
                        '$badge',
                        '$is_offer',
                        '$stock',
                        '$is_best_seller'
                    )
                ");

                if ($query) {
                    header("Location: booklist.php");
                    exit;
                } else {

                    $error = "Gagal menambahkan buku: " . mysqli_error($conn);

                    if (file_exists($upload_folder . $new_image)) {
                        unlink($upload_folder . $new_image);
                    }
                }

            } else {
                $error = "Gambar gagal diupload.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>BOOKISSE | Add Book</title>

    <link rel="stylesheet" href="css/admin.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Irish+Grover&display=swap" rel="stylesheet">
</head>

<body>

<?php include "include/sidebar.php"; ?>

<div class="main">

    <?php include "include/header.php"; ?>

    <div class="content">

        <h2>Add Book</h2>

        <p style="color:#777;margin-bottom:25px;">
            Add a new book to BOOKISSE
        </p>

        <?php if (isset($error)) { ?>
            <div style="
                background:#ffdede;
                color:#b30000;
                padding:15px;
                border-radius:8px;
                margin-bottom:20px;
            ">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php } ?>

        <div class="table-box">

            <form action="" method="POST" enctype="multipart/form-data">

                <label>Book Title</label>
                <input
                    type="text"
                    name="title"
                    placeholder="Enter book title"
                    required
                    style="width:100%;padding:12px;margin:8px 0 20px;border:1px solid #ddd;border-radius:8px;"
                >

                <label>Author</label>
                <input
                    type="text"
                    name="author"
                    placeholder="Enter author name"
                    required
                    style="width:100%;padding:12px;margin:8px 0 20px;border:1px solid #ddd;border-radius:8px;"
                >

                <label>Description</label>
                <textarea
                    name="description"
                    rows="5"
                    placeholder="Enter book description"
                    style="width:100%;padding:12px;margin:8px 0 20px;border:1px solid #ddd;border-radius:8px;resize:vertical;"
                ></textarea>

                <label>Price</label>
                <input
                    type="number"
                    name="price"
                    step="0.01"
                    min="0"
                    placeholder="Enter price"
                    required
                    style="width:100%;padding:12px;margin:8px 0 20px;border:1px solid #ddd;border-radius:8px;"
                >

                <label>Stock Quantity</label>
                <input
                    type="number"
                    name="stock"
                    min="0"
                    value="0"
                    required
                    placeholder="Enter book stock"
                    style="width:100%;padding:12px;margin:8px 0 20px;border:1px solid #ddd;border-radius:8px;"
                >

                <label>Category</label>
                <select
                    name="category"
                    required
                    style="width:100%;padding:12px;margin:8px 0 20px;border:1px solid #ddd;border-radius:8px;background:white;"
                >

                    <option value="">-- Select Category --</option>

                    <?php while ($category = mysqli_fetch_assoc($category_query)) { ?>
                        <option value="<?php echo htmlspecialchars($category['nama_kategori']); ?>">
                            <?php echo htmlspecialchars($category['nama_kategori']); ?>
                        </option>
                    <?php } ?>

                </select>

                <label>Badge</label>
                <input
                    type="text"
                    name="badge"
                    placeholder="Example: NEW, LIMITED, PROMO"
                    style="width:100%;padding:12px;margin:8px 0 20px;border:1px solid #ddd;border-radius:8px;"
                >

                <label style="display:flex;align-items:center;gap:10px;margin-bottom:20px;">
                    <input type="checkbox" name="is_offer" value="1">
                    This book is on offer
                </label>

                <label>Book Image</label>
                <input
                    type="file"
                    name="image"
                    accept=".jpg,.jpeg,.png,.webp"
                    required
                    style="display:block;margin:10px 0 25px;"
                >

                <button
                    type="submit"
                    name="submit"
                    style="
                        background:#F4B43A;
                        color:#2B1033;
                        padding:12px 20px;
                        border:none;
                        border-radius:8px;
                        font-weight:bold;
                        cursor:pointer;
                    "
                >
                    <i class="fa-solid fa-plus"></i>
                    Add Book
                </button>

                <a
                    href="booklist.php"
                    style="margin-left:15px;text-decoration:none;color:#2B1033;"
                >
                    Cancel
                </a>

            </form>

        </div>
    </div>
</div>
</body>
</html>
