
<?php
session_start();
require "../config/database.php";

// CEK LOGIN ADMIN
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != "admin") {
    header("Location: ../pages/login.php");
    exit;
}

// CEK ID USER
if (!isset($_GET['id'])) {
    header("Location: user.php");
    exit;
}

$id = (int) $_GET['id'];

// AMBIL DATA USER
$stmt = mysqli_prepare($conn, "SELECT * FROM users WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);
$user = mysqli_fetch_assoc($result);

mysqli_stmt_close($stmt);

if (!$user) {
    echo "<script>
        alert('User not found!');
        window.location='user.php';
    </script>";
    exit;
}

// PROSES UPDATE USER
if (isset($_POST['update'])) {

    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $role = $_POST['role'] ?? 'user';
    $password = $_POST['password'] ?? '';

    if (!in_array($role, ['admin', 'user'], true)) {
        $error = "Invalid role.";

    } elseif ($name === '' || $email === '') {
        $error = "Name and email are required.";

    } else {

        if (!empty($password)) {

            $hashedPassword = md5($password);

            $update = mysqli_prepare(
                $conn,
                "UPDATE users
                 SET name = ?, email = ?, password = ?,
                     phone = ?, address = ?, role = ?
                 WHERE id = ?"
            );

            mysqli_stmt_bind_param(
                $update,
                "ssssssi",
                $name,
                $email,
                $hashedPassword,
                $phone,
                $address,
                $role,
                $id
            );

        } else {

            $update = mysqli_prepare(
                $conn,
                "UPDATE users
                 SET name = ?, email = ?, phone = ?,
                     address = ?, role = ?
                 WHERE id = ?"
            );

            mysqli_stmt_bind_param(
                $update,
                "sssssi",
                $name,
                $email,
                $phone,
                $address,
                $role,
                $id
            );
        }

        if (mysqli_stmt_execute($update)) {

            mysqli_stmt_close($update);

            echo "<script>
                alert('User updated successfully!');
                window.location='user.php';
            </script>";
            exit;

        } else {

            $error = "Failed to update user: " . mysqli_error($conn);
            mysqli_stmt_close($update);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Edit User | BOOKISSE</title>

    <link rel="stylesheet" href="css/admin.css?v=<?php echo time(); ?>">

    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"
    >

    <style>

        /* PAGE */
        .main {
            min-height: 100vh;
        }

        .content {
            padding: 35px;
        }

        /* EDIT USER CARD */
        .edit-user-card {
            width: 100%;
            box-sizing: border-box;
            background: #FFFFFF;
            padding: 35px;
            border-radius: 18px;
            box-shadow: 0 8px 25px rgba(0,0,0,.07);
        }

        .edit-user-title {
            color: #2B1033;
            font-family: Arial, sans-serif;
            font-size: 28px;
            font-weight: bold;
            margin: 0 0 8px;
        }

        .edit-user-subtitle {
            color: #888888;
            font-family: Arial, sans-serif;
            font-size: 14px;
            margin: 0 0 30px;
        }

        /* FORM GRID */
        .edit-user-form {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 22px;
        }

        .edit-user-form .form-group {
            min-width: 0;
            margin: 0;
        }

        .edit-user-form label {
            display: block;
            color: #2B1033;
            font-family: Arial, sans-serif;
            font-size: 14px;
            font-weight: bold;
            margin-bottom: 9px;
        }

        .edit-user-form input,
        .edit-user-form textarea,
        .edit-user-form select {
            display: block;
            width: 100%;
            box-sizing: border-box;
            padding: 13px 15px;
            border: 1px solid #DDDDDD;
            border-radius: 9px;
            outline: none;
            background: #FFFFFF;
            color: #333333;
            font-family: Arial, sans-serif;
            font-size: 14px;
            transition: .2s;
        }

        .edit-user-form input:focus,
        .edit-user-form textarea:focus,
        .edit-user-form select:focus {
            border-color: #F4B43A;
            box-shadow: 0 0 0 3px rgba(244,180,58,.15);
        }

        .edit-user-form textarea {
            min-height: 110px;
            resize: vertical;
        }

        .full-width {
            grid-column: 1 / -1;
        }

        /* BUTTONS */
        .form-actions {
            grid-column: 1 / -1;
            display: flex;
            align-items: center;
            gap: 12px;
            margin-top: 8px;
        }

        .form-actions button,
        .form-actions a {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 9px;
            padding: 13px 22px;
            border: none;
            border-radius: 10px;
            font-family: Arial, sans-serif;
            font-size: 14px;
            font-weight: bold;
            text-decoration: none;
            cursor: pointer;
            transition: .3s;
        }

        .update-user-btn {
            background: #F4B43A;
            color: #2B1033;
        }

        .update-user-btn:hover {
            background: #E4A52F;
            transform: translateY(-2px);
        }

        .cancel-user-btn {
            background: #8B2635;
            color: #FFFFFF;
        }

        .cancel-user-btn:hover {
            background: #6F1D2A;
            transform: translateY(-2px);
        }

        /* ERROR MESSAGE */
        .edit-error {
            background: #FFE0E0;
            color: #A32222;
            padding: 13px 16px;
            border-radius: 9px;
            margin-bottom: 22px;
            font-family: Arial, sans-serif;
            font-size: 14px;
        }

        /* RESPONSIVE */
        @media (max-width: 768px) {

            .content {
                padding: 20px;
            }

            .edit-user-card {
                padding: 22px;
            }

            .edit-user-form {
                grid-template-columns: 1fr;
            }

            .full-width,
            .form-actions {
                grid-column: 1;
            }
        }

        @media (max-width: 480px) {

            .form-actions {
                flex-wrap: wrap;
            }

            .form-actions button,
            .form-actions a {
                width: 100%;
                box-sizing: border-box;
            }
        }

    </style>

</head>

<body>

    <!-- SIDEBAR -->
    <?php include __DIR__ . "/include/sidebar.php"; ?>

    <div class="main">

        <!-- HEADER -->
        <?php include __DIR__ . "/include/header.php"; ?>

        <div class="content">

            <div class="edit-user-card">

                <h2 class="edit-user-title">
                    <i class="fa-solid fa-user-pen"></i>
                    Edit User
                </h2>

                <p class="edit-user-subtitle">
                    Update user information and account details.
                </p>

                <?php if (isset($error)): ?>
                    <div class="edit-error">
                        <i class="fa-solid fa-circle-exclamation"></i>
                        <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?>
                    </div>
                <?php endif; ?>

                <form method="POST" class="edit-user-form">

                    <div class="form-group">
                        <label>Name</label>

                        <input
                            type="text"
                            name="name"
                            value="<?= htmlspecialchars($user['name'] ?? '', ENT_QUOTES, 'UTF-8'); ?>"
                            required
                        >
                    </div>

                    <div class="form-group">
                        <label>Email</label>

                        <input
                            type="email"
                            name="email"
                            value="<?= htmlspecialchars($user['email'] ?? '', ENT_QUOTES, 'UTF-8'); ?>"
                            required
                        >
                    </div>

                    <div class="form-group">
                        <label>New Password (optional)</label>

                        <input
                            type="password"
                            name="password"
                            placeholder="Leave blank if unchanged"
                        >
                    </div>

                    <div class="form-group">
                        <label>Phone</label>

                        <input
                            type="text"
                            name="phone"
                            value="<?= htmlspecialchars($user['phone'] ?? '', ENT_QUOTES, 'UTF-8'); ?>"
                        >
                    </div>

                    <div class="form-group full-width">
                        <label>Address</label>

                        <textarea name="address"><?= htmlspecialchars($user['address'] ?? '', ENT_QUOTES, 'UTF-8'); ?></textarea>
                    </div>

                    <div class="form-group">
                        <label>Role</label>

                        <select name="role">

                            <option
                                value="admin"
                                <?= $user['role'] == "admin" ? "selected" : ""; ?>
                            >
                                Admin
                            </option>

                            <option
                                value="user"
                                <?= $user['role'] == "user" ? "selected" : ""; ?>
                            >
                                User
                            </option>

                        </select>
                    </div>

                    <div class="form-actions">

                        <button
                            type="submit"
                            name="update"
                            class="update-user-btn"
                        >
                            <i class="fa-solid fa-floppy-disk"></i>
                            Update User
                        </button>

                        <a href="user.php" class="cancel-user-btn">
                            <i class="fa-solid fa-xmark"></i>
                            Cancel
                        </a>

                    </div>

                </form>

            </div>

        </div>

    </div>

</body>
</html>
