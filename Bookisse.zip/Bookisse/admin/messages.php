<?php

session_start();

require "../config/database.php";


/* =========================
   CEK LOGIN ADMIN
========================= */

if (!isset($_SESSION['user'])) {

    header("Location: ../pages/login.php");
    exit;

}

if ($_SESSION['user']['role'] != "admin") {

    header("Location: ../index.php");
    exit;

}


$admin_id = $_SESSION['user']['id'];


/* =========================
   KIRIM BALASAN
========================= */

if (isset($_POST['send_message'])) {

    $receiver_id = $_POST['receiver_id'];

    $message = trim($_POST['message']);

    if ($message != "") {

        $receiver_id = mysqli_real_escape_string(
            $conn,
            $receiver_id
        );

        $message = mysqli_real_escape_string(
            $conn,
            $message
        );

        mysqli_query(
            $conn,
            "
            INSERT INTO messages
            (
                sender_id,
                receiver_id,
                message
            )
            VALUES
            (
                '$admin_id',
                '$receiver_id',
                '$message'
            )
            "
        );

    }

    header(
        "Location: messages.php?user_id=" .
        $receiver_id
    );

    exit;

}


/* =========================
   AMBIL USER YANG CHAT
========================= */

$users_query = mysqli_query(
    $conn,
    "
    SELECT DISTINCT
        users.id,
        users.name,
        users.email
    FROM users
    JOIN messages
        ON users.id = messages.sender_id
        OR users.id = messages.receiver_id
    WHERE users.id != '$admin_id'
    ORDER BY users.name ASC
    "
);


/* =========================
   USER YANG DIPILIH
========================= */

$selected_user = null;

$messages_query = null;


if (isset($_GET['user_id'])) {

    $user_id = mysqli_real_escape_string(
        $conn,
        $_GET['user_id']
    );


    $user_query = mysqli_query(
        $conn,
        "
        SELECT *
        FROM users
        WHERE id = '$user_id'
        LIMIT 1
        "
    );


    $selected_user = mysqli_fetch_assoc(
        $user_query
    );


    $messages_query = mysqli_query(
        $conn,
        "
        SELECT *
        FROM messages
        WHERE

        (
            sender_id = '$admin_id'
            AND receiver_id = '$user_id'
        )

        OR

        (
            sender_id = '$user_id'
            AND receiver_id = '$admin_id'
        )

        ORDER BY created_at ASC
        "
    );

}

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta
name="viewport"
content="width=device-width, initial-scale=1.0"
>

<title>BOOKISSE | Messages</title>


<link
rel="stylesheet"
href="css/admin.css?v=<?php echo time(); ?>"
>


<link
rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"
>


<style>


.messages-layout{

    display:grid;

    grid-template-columns:280px 1fr;

    gap:25px;

    height:650px;

}


/* =========================
   USER LIST
========================= */

.user-list{

    background:#4B2154;

    border-radius:15px;

    padding:15px;

    overflow-y:auto;

}


.user-list h3{

    margin-top:5px;

    color:#F4B43A;

}


.user-item{

    display:block;

    padding:15px;

    margin-bottom:10px;

    background:#5C2A66;

    border-radius:10px;

    text-decoration:none;

    color:white;

    transition:.2s;

}


.user-item:hover{

    background:#6B3575;

}


.user-item.active{

    background:#F4B43A;

    color:#2B1033;

}


.user-item strong{

    display:block;

    margin-bottom:5px;

}


.user-item small{

    opacity:.8;

}


/* =========================
   CHAT AREA
========================= */

.chat-area{

    background:#4B2154;

    border-radius:15px;

    display:flex;

    flex-direction:column;

    overflow:hidden;

}


.chat-header{

    padding:20px;

    border-bottom:

    1px solid rgba(255,255,255,.15);

}


.chat-header h3{

    margin:0;

    color:#F4B43A;

}


.chat-box{

    flex:1;

    padding:25px;

    overflow-y:auto;

    display:flex;

    flex-direction:column;

    gap:15px;

}


.message{

    max-width:70%;

    padding:13px 17px;

    border-radius:15px;

}


.message.user{

    background:#5C2A66;

    align-self:flex-start;

}


.message.admin{

    background:#F4B43A;

    color:#2B1033;

    align-self:flex-end;

}


.message small{

    display:block;

    margin-top:7px;

    font-size:11px;

    opacity:.7;

}


/* =========================
   SEND FORM
========================= */

.chat-form{

    display:flex;

    gap:10px;

    padding:15px;

    border-top:

    1px solid rgba(255,255,255,.15);

}


.chat-form input{

    flex:1;

    border:none;

    outline:none;

    padding:15px;

    border-radius:10px;

    font-size:15px;

}


.chat-form button{

    border:none;

    background:#F4B43A;

    color:#2B1033;

    padding:0 22px;

    border-radius:10px;

    cursor:pointer;

    font-size:18px;

}


.empty-chat{

    display:flex;

    flex:1;

    justify-content:center;

    align-items:center;

    color:#ccc;

    font-size:18px;

}


/* =========================
   RESPONSIVE
========================= */

@media(max-width:900px){

    .messages-layout{

        grid-template-columns:1fr;

        height:auto;

    }


    .user-list{

        max-height:250px;

    }


    .chat-area{

        min-height:600px;

    }

}


</style>

</head>


<body>


<?php include "include/sidebar.php"; ?>


<div class="main">


<?php include "include/header.php"; ?>


<div class="content">


<h2>Messages</h2>

<p style="color:#777;margin-bottom:25px;">

Communicate directly with BOOKISSE customers.

</p>


<div class="messages-layout">


<!-- =========================
     USER LIST
========================= -->

<div class="user-list">


<h3>

<i class="fa-solid fa-users"></i>

Customers

</h3>


<?php

if (mysqli_num_rows($users_query) == 0) {

?>

<p style="color:#ccc;">

No messages yet.

</p>

<?php

}


while ($user = mysqli_fetch_assoc($users_query)) {

?>


<a

href="messages.php?user_id=<?= $user['id']; ?>"

class="user-item
<?=

isset($_GET['user_id'])
&& $_GET['user_id'] == $user['id']

? 'active'

: '';

?>"

>


<strong>

<?= htmlspecialchars($user['name']); ?>

</strong>


<small>

<?= htmlspecialchars($user['email']); ?>

</small>


</a>


<?php } ?>


</div>



<!-- =========================
     CHAT AREA
========================= -->

<div class="chat-area">


<?php if ($selected_user) { ?>


<div class="chat-header">


<h3>

<i class="fa-solid fa-comments"></i>

<?= htmlspecialchars($selected_user['name']); ?>

</h3>


</div>



<div class="chat-box">


<?php

if (mysqli_num_rows($messages_query) == 0) {

?>

<div class="empty-chat">

No messages yet.

</div>

<?php

}


while (
    $chat =
    mysqli_fetch_assoc($messages_query)
) {

?>


<div

class="message

<?=

$chat['sender_id'] == $admin_id

? 'admin'

: 'user';

?>"

>


<?= nl2br(
    htmlspecialchars($chat['message'])
); ?>


<small>

<?= date(

    "d M Y H:i",

    strtotime(
        $chat['created_at']
    )

); ?>

</small>


</div>


<?php } ?>


</div>



<form

method="POST"

class="chat-form"

>


<input

type="hidden"

name="receiver_id"

value="<?= $selected_user['id']; ?>"

>


<input

type="text"

name="message"

placeholder="Write a reply..."

autocomplete="off"

required

>

<button

type="submit"

name="send_message"

>

<i class="fa-solid fa-paper-plane"></i>

</button>


</form>


<?php } else { ?>


<div class="empty-chat">

<i
class="fa-solid fa-comments"
style="
font-size:35px;
margin-right:10px;
color:#F4B43A;
"
></i>

Select a customer to open the conversation.

</div>
<?php } ?>
</div>

</div>
</div>
</div>

</body>

</html>