<?php
session_start();

require "../config/database.php";


/* =========================
   CEK ADMIN
========================= */

if (
    !isset($_SESSION['user']) ||
    $_SESSION['user']['role'] != "admin"
) {
    header("Location: ../pages/login.php");
    exit;
}


/* =========================
   CEK ID
========================= */

if (!isset($_GET['id'])) {
    header("Location: booklist.php");
    exit;
}

$id = (int) $_GET['id'];


/* =========================
   AMBIL DATA BUKU
========================= */

$query = mysqli_query(
    $conn,
    "SELECT * FROM books WHERE id = $id"
);

$book = mysqli_fetch_assoc($query);


if (!$book) {

    echo "<script>
            alert('Book not found!');
            window.location='booklist.php';
          </script>";

    exit;
}


/* =========================
   HAPUS GAMBAR
========================= */

if (!empty($book['image'])) {

    $image_path =
        "../assets/images/books/" . $book['image'];

    if (file_exists($image_path)) {
        unlink($image_path);
    }
}


/* =========================
   HAPUS DATA DATABASE
========================= */

$delete = mysqli_query(
    $conn,
    "DELETE FROM books WHERE id = $id"
);


if ($delete) {

    echo "<script>
            alert('Book successfully deleted!');
            window.location='booklist.php';
          </script>";

    exit;

} else {

    echo "<script>
            alert('Failed to delete book!');
            window.location='booklist.php';
          </script>";

    exit;
}
?>