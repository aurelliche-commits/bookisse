<?php
session_start();
require "../config/database.php";

if (!isset($_SESSION['user'])) {
    header("Location: ../pages/login.php");
    exit;
}

if ($_SESSION['user']['role'] != "admin") {
    header("Location: ../index.php");
    exit;
}

if (!isset($_GET['id'])) {
    header("Location: categories.php");
    exit;
}

$id = (int) $_GET['id'];

$query = mysqli_query(
    $conn,
    "SELECT * FROM kategori WHERE id_kategori = $id"
);

$kategori = mysqli_fetch_assoc($query);

if (!$kategori) {
    echo "<script>
            alert('Category not found!');
            window.location='categories.php';
          </script>";
    exit;
}


if (isset($_POST['update'])) {

    $nama_kategori = mysqli_real_escape_string(
        $conn,
        $_POST['nama_kategori']
    );

    if ($nama_kategori == "") {

        echo "<script>
                alert('Category name cannot be empty!');
              </script>";

    } else {

        $update = mysqli_query(
            $conn,
            "UPDATE kategori
             SET nama_kategori = '$nama_kategori'
             WHERE id_kategori = $id"
        );

        if ($update) {

            echo "<script>
                    alert('Category successfully updated!');
                    window.location='categories.php';
                  </script>";

            exit;

        } else {

            echo "<script>
                    alert('Failed to update category!');
                  </script>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <title>BOOKISSE | Edit Category</title>

    <link rel="stylesheet" href="css/admin.css?v=<?php echo time(); ?>">

    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">

</head>

<body>

<?php include "include/sidebar.php"; ?>

<div class="main">

    <?php include "include/header.php"; ?>

    <div class="content">

        <div class="table-box">

            <h2>Edit Category</h2>

            <form method="POST">

                <div class="form-group">

                    <label>Category Name</label>

                    <input
                        type="text"
                        name="nama_kategori"
                        value="<?php echo htmlspecialchars($kategori['nama_kategori']); ?>"
                        required>

                </div>

                <button
                    type="submit"
                    name="update"
                    class="add-btn">

                    <i class="fa-solid fa-save"></i>
                    Update Category

                </button>

                <a
                    href="categories.php"
                    class="delete-btn">

                    Cancel

                </a>

            </form>

        </div>

    </div>

</div>

</body>
</html>