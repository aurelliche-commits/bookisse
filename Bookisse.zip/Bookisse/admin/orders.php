
<?php
session_start();
require "../config/database.php";

/* =========================
   CEK ADMIN
========================= */

if (!isset($_SESSION['user'])) {
    header("Location: ../pages/login.php");
    exit;
}

if ($_SESSION['user']['role'] != "admin") {
    header("Location: ../index.php");
    exit;
}

/* =========================
   AMBIL DATA ORDERS
========================= */

$query = mysqli_query(
    $conn,
    "
    SELECT
        orders.*,
        users.name,
        users.email
    FROM orders
    JOIN users
        ON orders.user_id = users.id
    ORDER BY orders.created_at DESC
    "
);

if (!$query) {
    die("Gagal mengambil data pesanan: " . mysqli_error($conn));
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>BOOKISSE | Orders</title>

<link
rel="stylesheet"
href="css/admin.css?v=<?php echo time(); ?>"
>

<link
rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"
>

</head>

<body>

<?php include "include/sidebar.php"; ?>

<div class="main">

<?php include "include/header.php"; ?>

<div class="content">

<h2>Orders</h2>

<p style="color:#777;margin-bottom:25px;">
Manage customer orders and shipping status.
</p>

<div class="table-box">

<table>

<thead>

<tr>
    <th>Order Code</th>
    <th>Customer</th>
    <th>Total</th>
    <th>Payment</th>
    <th>Order Status</th>
    <th>Date</th>
    <th>Action</th>
</tr>

</thead>

<tbody>

<?php if (mysqli_num_rows($query) == 0) { ?>

<tr>
    <td colspan="7" style="text-align:center;padding:30px;">
        No Orders
    </td>
</tr>

<?php } ?>

<?php while ($order = mysqli_fetch_assoc($query)) { ?>

<tr>

<!-- ORDER CODE -->
<td>

<strong style="color:#4B2154;">

<?= htmlspecialchars(
    !empty($order['order_code'])
        ? $order['order_code']
        : '#' . $order['id'],
    ENT_QUOTES,
    'UTF-8'
); ?>

</strong>

</td>

<!-- CUSTOMER -->
<td>

<strong>
<?= htmlspecialchars($order['name'], ENT_QUOTES, 'UTF-8'); ?>
</strong>

<br>

<small>
<?= htmlspecialchars($order['email'], ENT_QUOTES, 'UTF-8'); ?>
</small>

</td>

<!-- TOTAL -->
<td>

Rp <?= number_format(
    (float)$order['total'],
    2,
    '.',
    ','
); ?>

</td>

<!-- PAYMENT STATUS -->
<td>

<?php if ($order['payment_status'] == 'paid') { ?>

<span style="
background:#dff7e3;
color:#176b27;
padding:6px 10px;
border-radius:15px;
font-weight:bold;
">

✓ PAID

</span>

<?php } else { ?>

<span style="
background:#fff3cd;
color:#856404;
padding:6px 10px;
border-radius:15px;
font-weight:bold;
">

<?= htmlspecialchars(
    strtoupper($order['payment_status'] ?? 'PENDING'),
    ENT_QUOTES,
    'UTF-8'
); ?>

</span>

<?php } ?>

</td>

<!-- ORDER STATUS -->
<td>

<span style="
padding:6px 12px;
border-radius:15px;
background:#eee;
font-weight:bold;
">

<?= ucfirst(
    htmlspecialchars($order['status'], ENT_QUOTES, 'UTF-8')
); ?>

</span>

</td>

<!-- DATE -->
<td>

<?= !empty($order['created_at'])
    ? date("d M Y H:i", strtotime($order['created_at']))
    : '-'; ?>

</td>

<!-- ACTION -->
<td>

<a
href="order_detail.php?id=<?= (int)$order['id']; ?>"
style="
background:#F4B43A;
color:#2B1033;
padding:8px 12px;
border-radius:7px;
text-decoration:none;
font-weight:bold;
"
>

<i class="fa-solid fa-eye"></i>
View

</a>

</td>

</tr>

<?php } ?>

</tbody>

</table>

</div>

</div>

</div>

</body>
</html>
