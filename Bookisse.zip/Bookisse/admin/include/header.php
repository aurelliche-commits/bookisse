
<?php

if (!isset($_SESSION['user'])) {
    header("Location: ../pages/login.php");
    exit;
}

if ($_SESSION['user']['role'] != "admin") {
    header("Location: ../index.php");
    exit;
}

/* JUDUL HEADER BERDASARKAN HALAMAN */

$currentPage = basename($_SERVER['PHP_SELF']);

$pageTitles = [
    'orders.php'     => 'Orders',
    'user.php'       => 'Users',
    'booklist.php'   => 'Product',
    'add_book.php'   => 'Add Book',
    'edit.php'       => 'Edit Book',
    'categories.php' => 'Categories',
    'messages.php'   => 'Message',
];

$pageTitle = $pageTitles[$currentPage] ?? 'Admin Panel';

?>

<header>

    <div class="header">

        <div>
            <h2>
                <?= htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8'); ?>
            </h2>

            <p>
                Welcome back, <?= htmlspecialchars($_SESSION['user']['name'] ?? $_SESSION['name'] ?? 'Administrator', ENT_QUOTES, 'UTF-8'); ?>
            </p>
        </div>

    </div>

</header>
