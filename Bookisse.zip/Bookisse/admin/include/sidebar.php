
<div class="sidebar">

    <h1>BOOKISSE</h1>

    <ul>

        <li>
            <a href="orders.php">
                <i class="fa-solid fa-cart-shopping"></i>
                Orders
            </a>
        </li>

        <li>
            <a href="user.php">
                <i class="fa-solid fa-users"></i>
                Users
            </a>
        </li>

        <li>
            <a href="booklist.php">
                <i class="fa-solid fa-book"></i>
                Product
            </a>
        </li>

        <li>
            <a href="categories.php">
                <i class="fa-solid fa-layer-group"></i>
                Categories
            </a>
        </li>

        <li>
            <a href="messages.php">
                <i class="fa-solid fa-envelope"></i>
                Message
            </a>
        </li>

        <li class="logout-menu">
            <a href="../process/logout.php">
                <i class="fa-solid fa-right-from-bracket"></i>
                Logout
            </a>
        </li>

    </ul>

</div>
