<?php
session_start();
require "../config/database.php";

if (!isset($_SESSION['user'])) {
    header("Location: ../pages/login.php");
    exit;
}

if ($_SESSION['user']['role'] != "admin") {
    header("Location: ../index.php");
    exit;
}

$query = mysqli_query($conn, "SELECT * FROM kategori ORDER BY id_kategori DESC");
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>BOOKISSE | Categories</title>

    <link rel="stylesheet" href="css/admin.css?v=<?php echo time(); ?>">

    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">

    <link href="https://fonts.googleapis.com/css2?family=Irish+Grover&display=swap"
        rel="stylesheet">

</head>

<body>

<?php include "include/sidebar.php"; ?>

<div class="main">

    <?php include "include/header.php"; ?>

    <div class="content">

        <div class="page-title">

            <div>
                <h2>Categories</h2>
                <p>Manage book categories</p>
            </div>

            <a href="add_category.php" class="add-btn">
                <i class="fa-solid fa-plus"></i>
                Add Category
            </a>

        </div>


        <div class="table-box">

            <table>

                <thead>

                    <tr>
                        <th>No</th>
                        <th>Category Name</th>
                        <th>Action</th>
                    </tr>

                </thead>

                <tbody>

                <?php

                $no = 1;

                if (mysqli_num_rows($query) > 0) {

                    while ($kategori = mysqli_fetch_assoc($query)) {

                ?>

                    <tr>

                        <td>
                            <?php echo $no++; ?>
                        </td>

                        <td>
                            <?php echo htmlspecialchars($kategori['nama_kategori']); ?>
                        </td>

                        <td>

                            <a
                                href="edit_category.php?id=<?php echo $kategori['id_kategori']; ?>"
                                class="edit-btn">
                                <i class="fa-solid fa-pen"></i>
                                Edit
                            </a>

                            <a
                                href="delete_category.php?id=<?php echo $kategori['id_kategori']; ?>"
                                class="delete-btn"
                                onclick="return confirm('Are you sure you want to delete this category?');">
                                <i class="fa-solid fa-trash"></i>
                                Delete
                            </a>

                        </td>

                    </tr>

                <?php

                    }

                } else {

                ?>

                    <tr>

                        <td colspan="3" style="text-align:center;">
                            No categories found.
                        </td>

                    </tr>

                <?php } ?>

                </tbody>

            </table>

        </div>

    </div>

</div>

</body>
</html>