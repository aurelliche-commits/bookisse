<?php
session_start();
require "../config/database.php";

if (!isset($_SESSION['user'])) {
    header("Location: ../pages/login.php");
    exit;
}

if ($_SESSION['user']['role'] != "admin") {
    header("Location: ../index.php");
    exit;
}

if (!isset($_GET['id'])) {
    header("Location: categories.php");
    exit;
}

$id = (int) $_GET['id'];

$query = mysqli_query(
    $conn,
    "DELETE FROM kategori WHERE id_kategori = $id"
);

if ($query) {

    echo "<script>
            alert('Category successfully deleted!');
            window.location='categories.php';
          </script>";

} else {

    echo "<script>
            alert('Failed to delete category!');
            window.location='categories.php';
          </script>";
}
?>