<?php
session_start();

require "../config/database.php";

/* =========================
   CEK ADMIN
========================= */

if (
    !isset($_SESSION['user']) ||
    $_SESSION['user']['role'] != "admin"
) {
    header("Location: ../pages/login.php");
    exit;
}


/* =========================
   AMBIL DATA USERS
========================= */

$query = mysqli_query(
    $conn,
    "SELECT * FROM users ORDER BY id DESC"
);

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>BOOKISSE | Users</title>

    <link rel="stylesheet"
          href="css/admin.css?v=<?php echo time(); ?>">

    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">

    <link href="https://fonts.googleapis.com/css2?family=Irish+Grover&display=swap"
          rel="stylesheet">

</head>

<body>

<?php include "include/sidebar.php"; ?>

<div class="main">

    <?php include "include/header.php"; ?>


    <div class="content">

        <!-- TITLE -->

        <div style="
            display:flex;
            justify-content:space-between;
            align-items:center;
            margin-bottom:25px;
        ">

            <div>

                <h2>Users</h2>

                <p style="color:#777;">
                    Manage BOOKISSE users
                </p>

            </div>

        </div>


        <!-- TABLE -->

        <div class="table-box">

            <table>

                <thead>

                    <tr>

                        <th>No</th>

                        <th>Name</th>

                        <th>Email</th>

                        <th>Phone</th>

                        <th>Address</th>

                        <th>Role</th>

                        <th>Created</th>

                        <th>Action</th>

                    </tr>

                </thead>


                <tbody>

                <?php

                $no = 1;

                if (mysqli_num_rows($query) > 0) {

                    while ($user = mysqli_fetch_assoc($query)) {

                ?>

                    <tr>

                        <td>
                            <?php echo $no++; ?>
                        </td>

                        <td>
                            <?php
                            echo htmlspecialchars($user['name']);
                            ?>
                        </td>

                        <td>
                            <?php
                            echo htmlspecialchars($user['email']);
                            ?>
                        </td>

                        <td>
                            <?php
                          echo htmlspecialchars($user['phone'] ?? '', ENT_QUOTES, 'UTF-8');
                            ?>
                        </td>

                        <td>
                            <?php
                         echo htmlspecialchars($user['address'] ?? '', ENT_QUOTES, 'UTF-8');
                            ?>
                        </td>

                        <td>

                            <?php if ($user['role'] == "admin") { ?>

                                <span style="
                                    background:#2B1033;
                                    color:white;
                                    padding:5px 10px;
                                    border-radius:6px;
                                    font-size:13px;
                                ">
                                    Admin
                                </span>

                            <?php } else { ?>

                                <span style="
                                    background:#F4B43A;
                                    color:#2B1033;
                                    padding:5px 10px;
                                    border-radius:6px;
                                    font-size:13px;
                                ">
                                    User
                                </span>

                            <?php } ?>

                        </td>

                        <td>
                            <?php
                            echo htmlspecialchars($user['created_at']);
                            ?>
                        </td>

                        <td>

                            <!-- EDIT -->

                            <a
                                href="edit_user.php?id=<?php echo $user['id']; ?>"
                                style="
                                    color:#2B1033;
                                    margin-right:10px;
                                "
                            >

                                <i class="fa-solid fa-pen-to-square"></i>

                            </a>


                            <!-- DELETE -->

                            <a
                                href="deleted_user.php?id=<?php echo $user['id']; ?>"
                                onclick="return confirm('Are you sure you want to delete this user?');"
                                style="
                                    color:#9E2638;
                                "
                            >

                                <i class="fa-solid fa-trash"></i>

                            </a>

                        </td>

                    </tr>

                <?php

                    }

                } else {

                ?>

                    <tr>

                        <td
                            colspan="8"
                            style="text-align:center;"
                        >

                            No users found.

                        </td>

                    </tr>

                <?php } ?>

                </tbody>

            </table>

        </div>

    </div>
</div>
</body>
</html>