<?php
session_start();
require "../config/database.php";

if (!isset($_SESSION['user'])) {
    header("Location: ../pages/login.php");
    exit;
}

if ($_SESSION['user']['role'] != "admin") {
    header("Location: ../index.php");
    exit;
}

if (isset($_POST['save'])) {

    $nama_kategori = mysqli_real_escape_string(
        $conn,
        $_POST['nama_kategori']
    );

    if ($nama_kategori == "") {

        echo "<script>
                alert('Category name cannot be empty!');
                window.history.back();
              </script>";
        exit;
    }

    $query = mysqli_query(
        $conn,
        "INSERT INTO kategori (nama_kategori)
         VALUES ('$nama_kategori')"
    );

    if ($query) {

        echo "<script>
                alert('Category successfully added!');
                window.location='categories.php';
              </script>";

    } else {

        echo "<script>
                alert('Failed to add category!');
                window.history.back();
              </script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <title>BOOKISSE | Add Category</title>

    <link rel="stylesheet" href="css/admin.css?v=<?php echo time(); ?>">

    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">

</head>

<body>

<?php include "include/sidebar.php"; ?>

<div class="main">

    <?php include "include/header.php"; ?>

    <div class="content">

        <div class="table-box">

            <h2>Add Category</h2>

            <form method="POST">

                <div class="form-group">

                    <label>Category Name</label>

                    <input
                        type="text"
                        name="nama_kategori"
                        placeholder="Enter category name"
                        required>

                </div>

                <button
                    type="submit"
                    name="save"
                    class="add-btn">

                    <i class="fa-solid fa-save"></i>
                    Save Category

                </button>

                <a
                    href="categories.php"
                    class="delete-btn">

                    Cancel

                </a>

            </form>

        </div>

    </div>

</div>

</body>
</html>