<?php
session_start();
require "config/database.php";

/* =========================
   AMBIL GENERE DARI URL
========================= */

$genre = $_GET['genre'] ?? 'all';

$genre = trim($genre);

if (strtolower($genre) == 'all') {

    $query = mysqli_query(
        $conn,
        "SELECT * FROM books"
    );

    $page_title = "All Books";

} else {

    $query = mysqli_query(
        $conn,
        "SELECT * FROM books"
    );

    $page_title = ucfirst($genre) . " Books";

}

/* =========================
   QUERY BUKU
========================= */

if (strtolower($genre) == 'all') {

    $sql = "SELECT * FROM books";
    $page_title = "All Books";

} else {

    $genre_escaped = mysqli_real_escape_string($conn, $genre);

    $sql = "
        SELECT * FROM books
        WHERE LOWER(TRIM(category))
        LIKE LOWER('%$genre_escaped%')
    ";

    $page_title = ucfirst($genre) . " Books";
}

/* JALANKAN QUERY */

$query = mysqli_query($conn, $sql);

/* CEK ERROR DATABASES*/

if (!$query) {

    die("Database Error: " . mysqli_error($conn));

}

?>

<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        BOOKISSE | <?= htmlspecialchars($page_title); ?>
    </title>


    <link
        rel="stylesheet"
        href="assets/css/style.css?v=<?php echo time(); ?>"
    >

    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"
    >

    <link
        href="https://fonts.googleapis.com/css2?family=Irish+Grover&display=swap"
        rel="stylesheet"
    >

    <style>

        .category-page {
            padding: 60px 0;
            min-height: 70vh;
        }

        .category-page h1 {
            text-align: center;
            margin-bottom: 40px;
        }

        .book-list {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 25px;
        }

        .category-empty {
            grid-column: 1 / -1;
            text-align: center;
            padding: 50px;
        }

        .back-home-container {
            text-align: center;
            margin-top: 50px;
        }

        .back-home {
            display: inline-block;
            padding: 12px 30px;
            border: 1px solid #F4B43A;
            border-radius: 25px;
            color: #F4B43A;
            text-decoration: none;
        }

        .back-home:hover {
            background: #F4B43A;
            color: #2B1033;
        }

        @media(max-width:900px) {

            .book-list {
                grid-template-columns: repeat(2, 1fr);
            }

        }

        @media(max-width:600px) {

            .book-list {
                grid-template-columns: 1fr;
            }

        }
        /* CATEGORY PAGE CART ICON */

.category-page .book-item a.cart-icon,
.category-page .book-item span.cart-icon {
    display: inline-flex !important;
    align-items: center;
    justify-content: center;

    width: 38px;
    height: 38px;

    margin-top: 8px;
    border-radius: 50%;

    background: #F4B43A !important;
    color: #2B1033 !important;

    text-decoration: none;
    transition: all .3s ease;
}
.category-page .book-item .cart-icon i {
    color: #2B1033 !important;
}

.category-page .book-item a.cart-icon:hover {
    background: #FFFFFF !important;
    color: #2B1033 !important;
    transform: translateY(-4px) scale(1.08);
}

.category-page .book-item .cart-icon.disabled {
    background: #777777 !important;
    color: #DDDDDD !important;
    opacity: .55;
    cursor: not-allowed;
}

/* STOCK DISPLAY - CATEGORY PAGE */

.category-page .book-item .stock-info {
    margin: 8px 0 12px;
    font-size: 13px;
    font-weight: bold;
}

.category-page .book-item .in-stock {
    color: #8BE0A0;
}

.category-page .book-item .low-stock {
    color: #FFD166;
}

.category-page .book-item .out-stock {
    color: #FF8585;
}

/* CART ICON */

.category-page .book-item .cart-icon {
    display: inline-flex;
    justify-content: center;
    align-items: center;
    width: 38px;
    height: 38px;
    margin-top: 5px;
    border-radius: 50%;
    background: #F4B43A;
    color: #2B1033;
    text-decoration: none;
    transition: all .3s ease;
}

.category-page .book-item .cart-icon i {
    color: #2B1033;
}

.category-page .book-item .cart-icon:hover {
    background: white;
    transform: translateY(-4px) scale(1.08);
}

.category-page .book-item .cart-icon.disabled {
    background: #777;
    color: #DDD;
    opacity: .55;
    cursor: not-allowed;
}

    </style>

</head>

<body>

<?php include "includes/navbar.php"; ?>


<section class="category-page">

    <div class="container">


        <h1>
            <?= htmlspecialchars($page_title); ?>
        </h1>

        <div class="book-list">

            <?php if (mysqli_num_rows($query) > 0) { ?>

                <?php while ($book = mysqli_fetch_assoc($query)) { ?>

                    <div class="book-item">

                        <?php if (!empty($book['badge'])) { ?>

                            <span class="badge">
                                <?= htmlspecialchars($book['badge']); ?>
                            </span>

                        <?php } ?>


                        <img
                            src="assets/images/books/<?= htmlspecialchars($book['image']); ?>"
                            alt="<?= htmlspecialchars($book['title']); ?>"
                        >


                        <h4>
                            <?= htmlspecialchars($book['title']); ?>
                        </h4>


                        <small>
                            <?= htmlspecialchars($book['author']); ?>
                        </small>


                     
<p>
    Rp. <?= htmlspecialchars($book['price']); ?>
</p>

<?php $stock = (int)($book['stock'] ?? 0); ?>

<p class="stock-info">
    <?php if ($stock <= 0): ?>
        <span class="out-stock">Out of Stock</span>
    <?php elseif ($stock <= 10): ?>
        <span class="low-stock">
            Stock: <?= $stock; ?> left
        </span>
    <?php else: ?>
        <span class="in-stock">
            Stock: <?= $stock; ?>
        </span>
    <?php endif; ?>
</p>

<?php if ($stock > 0): ?>

    <a
        href="process/add_cart.php?id=<?= (int)$book['id']; ?>"
        class="cart-icon"
        title="Add to Cart"
    >
        <i class="fa-solid fa-cart-shopping"></i>
    </a>

<?php else: ?>

    <span class="cart-icon disabled" title="Out of Stock">
        <i class="fa-solid fa-cart-shopping"></i>
    </span>

<?php endif; ?>

                    </div>

                <?php } ?>

            <?php } else { ?>


                <div class="category-empty">

                    <h2>No Books Found </h2>

                    <p>
                        There are no books in this category yet.
                    </p>

                </div>

            <?php } ?>

        </div>

        <div class="back-home-container">

            <a
                href="index.php"
                class="back-home"
            >
                ← Back to Home
            </a>

        </div>
    </div>
</section>

</body>

</html>