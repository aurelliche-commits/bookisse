
<?php
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

require "../config/database.php";
$user_id = (int) $_SESSION['user']['id'];

if (!isset($_GET['order_id'])) {
    header("Location: profile.php");
    exit;
}

$order_id = (int) $_GET['order_id'];

$order_query = mysqli_query($conn, "
    SELECT *
    FROM orders
    WHERE id = '$order_id'
    AND user_id = '$user_id'
");

$order = mysqli_fetch_assoc($order_query);

if (!$order) {
    echo "<script>
        alert('Order not found!');
        window.location='profile.php';
    </script>";
    exit;
}

$items_query = mysqli_query($conn, "
    SELECT order_items.*, books.title, books.image
    FROM order_items
    JOIN books ON order_items.book_id = books.id
    WHERE order_items.order_id = '$order_id'
");

$receipt_items_query = mysqli_query($conn, "
    SELECT order_items.quantity, order_items.price, books.title
    FROM order_items
    JOIN books ON order_items.book_id = books.id
    WHERE order_items.order_id = '$order_id'
");

$receipt_items = [];

while ($receipt_item = mysqli_fetch_assoc($receipt_items_query)) {
    $receipt_items[] = [
        'title' => $receipt_item['title'],
        'quantity' => (int) $receipt_item['quantity'],
        'price' => (float) $receipt_item['price']
    ];
}

/* =========================
   DATA RECEIPT
========================= */

$initial_receipt = null;

if (($order['payment_status'] ?? '') === 'paid') {
    $initial_receipt = [
        'order_id' => (int) $order['id'],

        'order_code' => !empty($order['order_code'])
            ? $order['order_code']
            : '#' . $order['id'],

        'total' => (float) $order['total'],
        'created_at' => $order['created_at'],
        'paid_at' => $order['paid_at'],
        'payment_method' => $order['payment_method'],
        'payment_provider' => $order['payment_provider'],
        'items' => $receipt_items
    ];
}

// FORMAT HARGA
function rupiah($number) {
    return 'Rp ' . number_format((float)$number, 2, '.', ',');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://fonts.googleapis.com/css2?family=Irish+Grover&display=swap" rel="stylesheet">

<title>BOOKISSE | Payment</title>

<style>
* {
    box-sizing: border-box;
}

body {
    margin: 0;
    background: #2B1033;
    font-family: 'Irish Grover', cursive;
    color: white;
}

button,
input,
textarea,
select {
    font-family: 'Irish Grover', cursive;
}

.container {
    width: 90%;
    max-width: 850px;
    margin: auto;
    padding: 40px 0;
}

h1 {
    color: #F4B43A;
}

.payment-box {
    background: #4B2154;
    padding: 30px;
    border-radius: 20px;
    margin-top: 25px;
}

.order-number {
    color: #ddd;
    margin-bottom: 20px;
}

.item {
    display: flex;
    align-items: center;
    gap: 18px;
    padding: 15px 0;
    border-bottom: 1px solid rgba(255,255,255,.15);
}

.item img {
    width: 65px;
    height: 85px;
    object-fit: cover;
    border-radius: 7px;
}

.item-info {
    flex: 1;
}

.item-info h3 {
    margin: 0 0 8px;
}

.item-info p {
    margin: 5px 0;
    color: #ddd;
}

.total {
    display: flex;
    justify-content: space-between;
    margin-top: 25px;
    padding-top: 20px;
    border-top: 1px solid rgba(255,255,255,.2);
    font-size: 22px;
    font-weight: bold;
    color: #F4B43A;
}

.payment-method {
    margin-top: 30px;
}

.payment-method select,
.payment-method input[type="file"] {
    width: 100%;
    padding: 13px;
    border: none;
    border-radius: 9px;
    font-size: 15px;
    margin-top: 10px;
}

.payment-method label {
    display: block;
    margin-top: 20px;
    font-weight: bold;
}

.payment-info {
    display: none;
    background: #5C2A66;
    padding: 20px;
    border-radius: 12px;
    margin-top: 20px;
    line-height: 1.8;
}

.payment-info h3 {
    color: #F4B43A;
    margin-top: 0;
}

.payment-info strong {
    color: #F4B43A;
}

button {
    width: 100%;
    margin-top: 25px;
    padding: 15px;
    border: none;
    border-radius: 10px;
    background: #F4B43A;
    color: #2B1033;
    font-size: 17px;
    font-weight: bold;
    cursor: pointer;
}

button:hover {
    background: #e9a92e;
}

.back {
    display: block;
    margin-top: 20px;
    color: white;
    text-decoration: none;
}

.note {
    color: #ddd;
    font-size: 13px;
}

@media(max-width: 600px) {
    .payment-box {
        padding: 20px;
    }
}

/* PAYMENT NOTIFICATION */

.notification-overlay {
    display: none;
    position: fixed;
    inset: 0;
    background: rgba(0,0,0,.75);
    z-index: 9999;
    justify-content: center;
    align-items: center;
    padding: 20px;
}

.notification-overlay.active {
    display: flex;
}

.notification-box {
    width: 100%;
    max-width: 440px;
    background: #fff;
    color: #2B1033;
    padding: 30px;
    border-radius: 18px;
    text-align: center;
    box-shadow: 0 15px 40px rgba(0,0,0,.3);
}

.notification-icon {
    font-size: 45px;
    margin-bottom: 15px;
}

.notification-box h2 {
    color: #4B2154;
    margin-bottom: 10px;
}

.notification-box p {
    color: #666;
    line-height: 1.6;
}

.notification-buttons {
    display: flex;
    gap: 12px;
    margin-top: 25px;
}

.notification-buttons button {
    flex: 1;
    margin: 0;
    padding: 13px;
}

.btn-back {
    background: #eee;
    color: #333;
}

.btn-stay {
    background: #F4B43A;
    color: #2B1033;
}

/* RECEIPT MODAL */

#receiptModal {
    display: none;
    position: fixed;
    inset: 0;
    z-index: 10000;
    background: rgba(0,0,0,.75);
    justify-content: center;
    align-items: flex-start;
    padding: 35px 20px;
    overflow-y: auto;
}

#receiptModal.active {
    display: flex;
}

.receipt-content {
    background: white;
    color: #2B1033;
    border-radius: 16px;
    padding: 30px;
    width: 100%;
    max-width: 550px;
    max-height: calc(100vh - 70px);
    overflow-y: auto;
    font-family: Arial, sans-serif;
    position: relative;
    margin: 0 auto;
}

.receipt-content * {
    font-family: Arial, sans-serif;
    box-sizing: border-box;
}

.receipt-content h2 {
    color: #4B2154;
    text-align: center;
}

.receipt-content .receipt-total {
    color: #4B2154;
    font-size: 20px;
    font-weight: bold;
}

.receipt-item-row,
.receipt-info-row {
    display: flex;
    justify-content: space-between;
    gap: 15px;
    margin: 12px 0;
    font-size: 14px;
}

.receipt-content button {
    margin-top: 15px;
}

/* PRINT RECEIPT */

@page {
    size: A4 portrait;
    margin: 12mm;
}

@media print {

    html,
    body {
        margin: 0 !important;
        padding: 0 !important;
        width: 100% !important;
        min-height: 0 !important;
        height: auto !important;
        background: white !important;
        overflow: visible !important;
    }

    body > *:not(#receiptModal) {
        display: none !important;
    }

    body > #receiptModal.active {
        display: block !important;
        position: static !important;
        width: 100% !important;
        height: auto !important;
        min-height: 0 !important;
        margin: 0 !important;
        padding: 0 !important;
        background: white !important;
        overflow: visible !important;
    }

    #receiptModal.active .receipt-content {
        display: block !important;
        position: relative !important;
        width: 110mm !important;
        max-width: 110mm !important;
        height: auto !important;
        max-height: none !important;
        margin: 0 auto !important;
        padding: 10mm !important;
        overflow: visible !important;
        border: none !important;
        border-radius: 0 !important;
        box-shadow: none !important;
        background: white !important;
        color: #2B1033 !important;
        font-family: Arial, sans-serif !important;
        font-size: 12px !important;
        break-inside: avoid !important;
        page-break-inside: avoid !important;
    }

    .receipt-content * {
        font-family: Arial, sans-serif !important;
        box-sizing: border-box !important;
    }

    .receipt-content button {
        display: none !important;
    }

    #receiptDetails,
    #receiptItems,
    .receipt-total {
        break-inside: avoid !important;
        page-break-inside: avoid !important;
    }
}
</style>
</head>

<body>

<div class="container">

    <h1>Payment</h1>

    <div class="payment-box">

        <div class="order-number">
            Order <?= htmlspecialchars(
                !empty($order['order_code'])
                    ? $order['order_code']
                    : '#' . $order['id'],
                ENT_QUOTES,
                'UTF-8'
            ); ?>
        </div>

        <h2>Order Summary</h2>

        <?php while ($item = mysqli_fetch_assoc($items_query)) { ?>

            <div class="item">

                <img
                    src="../assets/images/books/<?= htmlspecialchars($item['image']); ?>"
                    alt="<?= htmlspecialchars($item['title']); ?>"
                >

                <div class="item-info">
                    <h3><?= htmlspecialchars($item['title']); ?></h3>
                    <p>Qty: <?= $item['quantity']; ?></p>
                    <p>
                        <?= rupiah($item['price']); ?>
                    </p>
                </div>

            </div>

        <?php } ?>

        <div class="total">
            <span>Total</span>
            <span>
                <?= rupiah($order['total']); ?>
            </span>
        </div>

        <div class="payment-method">

            <?php if ($order['payment_status'] === 'pending') { ?>

            <form
                action="../process/process_payment.php"
                method="POST"
                enctype="multipart/form-data"
            >

                <input type="hidden" name="order_id" value="<?= $order['id']; ?>">

                <label for="payment_method">Payment Method</label>

                <select name="payment_method" id="payment_method" required>
                    <option value="">-- Select Payment --</option>
                    <option value="E-Wallet">E-Wallet</option>
                    <option value="Bank Transfer">Bank Transfer</option>
                </select>

                <div id="ewallet_section" class="payment-info">

                    <h3>E-Wallet Payment</h3>

                    <label for="payment_provider">Select E-Wallet</label>

                    <select name="payment_provider" id="payment_provider">
                        <option value="">-- Select E-Wallet --</option>
                        <option value="QRIS">QRIS</option>
                        <option value="DANA">DANA</option>
                        <option value="GoPay">GoPay</option>
                    </select>

                    <div id="qris_info" class="payment-info">
                        <h3>QRIS</h3>
                        <p>Phone Number: <strong>0000000000</strong></p>
                        <p>Account Name: <strong>Aurell</strong></p>
                        <p class="note">Demo account only.</p>
                    </div>

                    <div id="dana_info" class="payment-info">
                        <h3>DANA</h3>
                        <p>Phone Number: <strong>0000000000</strong></p>
                        <p>Account Name: <strong>Aurell</strong></p>
                        <p class="note">Demo account only.</p>
                    </div>

                    <div id="gopay_info" class="payment-info">
                        <h3>GoPay</h3>
                        <p>Phone Number: <strong>0000000000</strong></p>
                        <p>Account Name: <strong>Aurell</strong></p>
                        <p class="note">Demo account only.</p>
                    </div>

                </div>

                <div id="bank_section" class="payment-info">
                    <h3>Bank Transfer</h3>
                    <p>Bank: <strong>BCA (Demo)</strong></p>
                    <p>Account Number: <strong>0000000000</strong></p>
                    <p>Account Name: <strong>Aurell</strong></p>
                    <p class="note">Demo account only.</p>
                </div>

                <label for="payment_proof">Payment Proof</label>

                <input
                    type="file"
                    name="payment_proof"
                    id="payment_proof"
                    accept=".jpg,.jpeg,.png,.webp,.pdf"
                    required
                >

                <p class="note">
                    Upload your payment receipt.
                    JPG, PNG, WEBP or PDF (maximum 10 MB).
                </p>

                <button type="submit">Submit Payment</button>

            </form>

            <?php } elseif ($order['payment_status'] === 'waiting_verification') { ?>

                <div class="payment-info" style="display:block;">
                    <h3>Payment Under Review</h3>
                    <p>Your payment proof has been submitted successfully.</p>
                    <p>Please wait while our admin verifies your payment.</p>
                    <p style="color:#F4B43A;font-weight:bold;">
                        Status: WAITING FOR VERIFICATION
                    </p>
                    <p class="note">
                        This page will check your payment status automatically.
                    </p>
                </div>

            <?php } elseif ($order['payment_status'] === 'paid') { ?>

                <div class="payment-info" style="display:block;">
                    <h3>Payment Approved</h3>
                    <p>Your payment has been verified by the admin.</p>
                    <p style="color:#F4B43A;font-weight:bold;">Status: PAID</p>
                    <button type="button" onclick="openReceipt()">View Receipt</button>
                </div>

            <?php } elseif ($order['payment_status'] === 'rejected') { ?>

                <div class="payment-info" style="display:block;">
                    <h3>Payment Rejected</h3>
                    <p>Your payment proof was rejected. Please contact the bookstore admin for assistance.</p>
                    <p>Do not submit another payment for this order until the stock and order have been reviewed.</p>
                </div>

            <?php } else { ?>

                <div class="payment-info" style="display:block;">
                    <h3>Payment Unavailable</h3>
                    <p>This order cannot accept payment in its current status. Please return to My Orders.</p>
                </div>

            <?php } ?>

        </div>
    </div>

    <a href="order.php" class="back">← Back to My Orders</a>

</div>

<!-- PAYMENT NOTIFICATION -->

<div class="notification-overlay" id="paymentNotification">

    <div class="notification-box">

        <div class="notification-icon" id="notificationIcon">💳</div>

        <h2 id="notificationTitle">Payment Submitted!</h2>

        <p id="notificationMessage">
            Your payment is waiting for admin verification.
        </p>

        <div class="notification-buttons" id="notificationButtons">

            <button type="button" class="btn-back" onclick="goToMyOrders()">
                Back
            </button>

            <button type="button" class="btn-stay" onclick="stayOnPayment()">
                Stay
            </button>

        </div>

        <button
            type="button"
            id="viewReceiptButton"
            style="display:none;"
            onclick="openReceipt()"
        >
            View Receipt
        </button>

        <button
            type="button"
            id="receiptBackButton"
            style="display:none;"
            onclick="goToMyOrders()"
        >
            Back to My Orders
        </button>

    </div>
</div>

<!-- RECEIPT POPUP -->

<div id="receiptModal">

    <div class="receipt-content">

        <h2>BOOKISSE</h2>

        <p style="text-align:center;">Your Favorite Bookstore</p>

        <hr>

        <h3 style="text-align:center;">PURCHASE RECEIPT</h3>

        <div id="receiptDetails"></div>

        <hr>

        <div id="receiptItems"></div>

        <hr>

        <div class="receipt-total">
            <div class="receipt-info-row">
                <span>Total Paid</span>
                <span id="receiptTotal"></span>
            </div>
        </div>

        <p style="text-align:center;color:green;font-weight:bold;">
            ✓ PAYMENT SUCCESSFUL
        </p>

        <button onclick="window.print()">Print Receipt</button>

        <button
            onclick="document.getElementById('receiptModal').classList.remove('active')"
            style="background:#ddd;color:#333;"
        >
            Close
        </button>

    </div>
</div>

<script>
const methodSelect = document.getElementById("payment_method");
const providerSelect = document.getElementById("payment_provider");
const ewalletSection = document.getElementById("ewallet_section");
const bankSection = document.getElementById("bank_section");
const proofInput = document.getElementById("payment_proof");
const qrisInfo = document.getElementById("qris_info");
const danaInfo = document.getElementById("dana_info");
const gopayInfo = document.getElementById("gopay_info");

function updateMethod() {

    if (!methodSelect || !providerSelect || !ewalletSection || !bankSection) return;

    ewalletSection.style.display = "none";
    bankSection.style.display = "none";
    providerSelect.required = false;
    providerSelect.disabled = true;

    if (methodSelect.value === "E-Wallet") {
        ewalletSection.style.display = "block";
        providerSelect.disabled = false;
        providerSelect.required = true;
    } else if (methodSelect.value === "Bank Transfer") {
        bankSection.style.display = "block";
    }

    updateProvider();
}

function updateProvider() {

    if (!providerSelect || !qrisInfo || !danaInfo || !gopayInfo) return;

    qrisInfo.style.display = "none";
    danaInfo.style.display = "none";
    gopayInfo.style.display = "none";

    if (providerSelect.value === "QRIS") {
        qrisInfo.style.display = "block";
    } else if (providerSelect.value === "DANA") {
        danaInfo.style.display = "block";
    } else if (providerSelect.value === "GoPay") {
        gopayInfo.style.display = "block";
    }
}

if (methodSelect && providerSelect) {
    methodSelect.addEventListener("change", updateMethod);
    providerSelect.addEventListener("change", updateProvider);
    updateMethod();
}

const orderId = <?= (int)$order_id ?>;
const paymentStatus = <?= json_encode($order['payment_status']) ?>;
let currentReceipt = <?= json_encode($initial_receipt, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
const submitted = <?= isset($_GET['submitted']) && $_GET['submitted'] === '1' ? 'true' : 'false' ?>;

let checkingPayment = false;
let pollingTimer = null;

const notification = document.getElementById("paymentNotification");

function goToMyOrders() {
    window.location.href = "order.php";
}

function stayOnPayment() {
    notification.classList.remove("active");
    startPaymentChecking();
}

function showNotification(title, message, icon) {
    document.getElementById("notificationTitle").textContent = title;
    document.getElementById("notificationMessage").textContent = message;
    document.getElementById("notificationIcon").textContent = icon || "💳";
    notification.classList.add("active");
}

function startPaymentChecking() {
    if (checkingPayment) return;

    checkingPayment = true;
    checkPaymentStatus();

    pollingTimer = setInterval(checkPaymentStatus, 5000);
}

async function checkPaymentStatus() {

    try {

        const response = await fetch(
            "../process/check_payment_status.php?order_id=" + orderId,
            { cache: "no-store" }
        );

        if (!response.ok) {
            throw new Error("Unable to check payment status.");
        }

        const data = await response.json();

        if (!data.success) return;

        if (data.payment_status === "paid") {

            clearInterval(pollingTimer);
            checkingPayment = false;
            currentReceipt = data.receipt;

            document.getElementById("notificationIcon").textContent = "🎉";

            showNotification(
                "Payment Approved!",
                "Your payment has been verified successfully. Your receipt is ready!",
                "🎉"
            );

            document.getElementById("notificationButtons").style.display = "none";
            document.getElementById("viewReceiptButton").style.display = "block";
            document.getElementById("receiptBackButton").style.display = "block";

        } else if (data.payment_status === "rejected") {

            clearInterval(pollingTimer);
            checkingPayment = false;

            showNotification(
                "Payment Rejected",
                "Your payment proof was rejected. Please return to My Orders for assistance.",
                "❌"
            );

            document.getElementById("notificationButtons").style.display = "none";
            document.getElementById("viewReceiptButton").style.display = "none";
            document.getElementById("receiptBackButton").style.display = "block";
        }

    } catch (error) {
        console.error("Payment checking error:", error);
    }
}

async function openReceipt() {

    try {

        if (!currentReceipt) {

            const response = await fetch(
                "../process/check_payment_status.php?order_id=" + orderId,
                {
                    cache: "no-store",
                    headers: { "Accept": "application/json" }
                }
            );

            const responseText = await response.text();

            let data;

            try {
                data = JSON.parse(responseText);
            } catch (parseError) {
                console.error("Receipt endpoint did not return JSON:", responseText);
                throw new Error("Server returned an invalid receipt response.");
            }

            if (!response.ok || !data.success || data.payment_status !== "paid" || !data.receipt) {
                throw new Error(data.message || "Receipt is not available yet.");
            }

            currentReceipt = data.receipt;
        }

        showPaymentReceipt();

    } catch (error) {
        console.error("Receipt loading error:", error);
        alert("Unable to load receipt: " + error.message);
    }
}

/* =========================
   SHOW PAYMENT RECEIPT
========================= */

function showPaymentReceipt() {

    if (!currentReceipt) return;

    const money = value =>
        "Rp " + Number(value).toLocaleString("en-US", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });

    document.getElementById("receiptDetails").innerHTML = "";

    const details = [
        [
            "Order Code",
            currentReceipt.order_code || "#" + currentReceipt.order_id
        ],
        ["Order Date", currentReceipt.created_at],
        ["Paid At", currentReceipt.paid_at || "-"],
        [
            "Payment Method",
            currentReceipt.payment_method +
            (currentReceipt.payment_provider
                ? " - " + currentReceipt.payment_provider
                : "")
        ]
    ];

    details.forEach(([label, value]) => {

        const row = document.createElement("div");
        row.className = "receipt-info-row";

        const left = document.createElement("span");
        left.textContent = label;

        const right = document.createElement("strong");
        right.textContent = value;

        row.append(left, right);

        document.getElementById("receiptDetails").appendChild(row);
    });

    const itemsContainer = document.getElementById("receiptItems");
    itemsContainer.innerHTML = "";

    (Array.isArray(currentReceipt.items) ? currentReceipt.items : []).forEach(item => {

        const row = document.createElement("div");
        row.className = "receipt-item-row";

        const title = document.createElement("span");
        title.textContent = item.title + " (" + item.quantity + "x)";

        const price = document.createElement("strong");
        price.textContent = money(item.price * item.quantity);

        row.append(title, price);
        itemsContainer.appendChild(row);
    });

    document.getElementById("receiptTotal").textContent =
        money(currentReceipt.total);

    document.getElementById("receiptModal").classList.add("active");
}

if (submitted) {

    showNotification(
        "Payment Submitted!",
        "Your payment proof has been uploaded. Please wait for admin verification.",
        "💳"
    );
}

if (paymentStatus === "waiting_verification") {
    startPaymentChecking();
}

if (paymentStatus === "paid" || paymentStatus === "rejected") {
    startPaymentChecking();
}
</script>
</body>
</html>
