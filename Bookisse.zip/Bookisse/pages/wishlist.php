
<?php
session_start();
require "../config/database.php";

// CEK LOGIN
if (!isset($_SESSION['user']['id'])) {
    header("Location: login.php");
    exit;
}

$user_id = (int) $_SESSION['user']['id'];

// AMBIL DATA WISHLIST
$stmt = mysqli_prepare(
    $conn,
    "SELECT
        wishlist.id AS wishlist_id,
        books.id AS book_id,
        books.title,
        books.author,
        books.image,
        books.price,
        books.stock,
        books.badge
    FROM wishlist
    INNER JOIN books ON wishlist.book_id = books.id
    WHERE wishlist.user_id = ?
    ORDER BY wishlist.id DESC"
);

if (!$stmt) {
    die("Database error: " . mysqli_error($conn));
}

mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);
$wishlist_books = [];

while ($row = mysqli_fetch_assoc($result)) {
    $wishlist_books[] = $row;
}

mysqli_stmt_close($stmt);

$total_wishlist = count($wishlist_books);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>BOOKISSE | My Wishlist</title>

<link href="https://fonts.googleapis.com/css2?family=Irish+Grover&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">

<style>
:root {
    --bg: #2B1033;
    --card: #4B2154;
    --card-light: #60306A;
    --gold: #F4B43A;
    --white: #fff;
    --muted: #D8CADA;
}

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    min-height: 100vh;
    background: radial-gradient(circle at top right, #51245B 0, var(--bg) 45%);
    font-family: 'Irish Grover', cursive;
    color: var(--white);
}

.wishlist-container {
    width: min(1100px, 92%);
    margin: 0 auto;
    padding: 30px 0 60px;
}

.back-link {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    color: var(--gold);
    text-decoration: none;
    margin-bottom: 25px;
}

.back-link:hover {
    color: #FFD06A;
}

.page-title {
    color: var(--gold);
    font-size: 32px;
    margin: 0 0 8px;
}

.subtitle {
    color: var(--muted);
    margin-bottom: 30px;
}

.wishlist-count {
    color: var(--gold);
    font-size: 15px;
    margin-bottom: 20px;
}

.wishlist-grid {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 22px;
}

.wishlist-card {
    position: relative;
    background: linear-gradient(140deg, var(--card), var(--card-light));
    border-radius: 18px;
    padding: 18px;
    text-align: center;
    border: 1px solid rgba(244,180,58,.15);
    box-shadow: 0 10px 25px rgba(0,0,0,.15);
    transition: .2s ease;
}

.wishlist-card:hover {
    transform: translateY(-4px);
    border-color: rgba(244,180,58,.5);
}

.wishlist-card img {
    width: 100%;
    height: 250px;
    object-fit: contain;
    border-radius: 10px;
    margin-bottom: 15px;
}

.wishlist-card h3 {
    font-size: 19px;
    margin: 8px 0;
}

.author {
    color: var(--muted);
    font-size: 13px;
}

.price {
    color: var(--gold);
    font-size: 20px;
    font-weight: bold;
    margin: 12px 0;
}

.stock {
    font-size: 13px;
    margin-bottom: 15px;
}

.in-stock {
    color: #A5F0B5;
}

.low-stock {
    color: #FFD06A;
}

.out-stock {
    color: #FF9999;
}

.badge {
    position: absolute;
    top: 12px;
    left: 12px;
    background: var(--gold);
    color: var(--bg);
    padding: 6px 10px;
    border-radius: 6px;
    font-size: 11px;
}

.book-actions {
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 10px;
    flex-wrap: wrap;
}

.detail-btn,
.remove-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 7px;
    padding: 10px 13px;
    border: none;
    border-radius: 8px;
    font-family: inherit;
    font-size: 12px;
    font-weight: bold;
    text-decoration: none;
    cursor: pointer;
    transition: .2s ease;
}

.detail-btn {
    background: var(--gold);
    color: var(--bg);
}

.detail-btn:hover {
    background: #FFD06A;
}

.remove-btn {
    background: #8E303B;
    color: white;
}

.remove-btn:hover {
    background: #A83A47;
}

.empty-wishlist {
    text-align: center;
    padding: 55px 20px;
    background: rgba(75,33,84,.8);
    border-radius: 18px;
    border: 1px solid rgba(244,180,58,.25);
    margin-top: 10px;
}

.empty-wishlist i {
    display: block;
    font-size: 50px;
    color: var(--gold);
    margin-bottom: 18px;
}

.empty-wishlist h2 {
    color: var(--gold);
    margin: 12px 0;
}

.empty-wishlist p {
    color: var(--muted);
    margin-bottom: 25px;
    line-height: 1.6;
}

.shop-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 12px 22px;
    background: var(--gold);
    color: var(--bg);
    border-radius: 9px;
    text-decoration: none;
    font-weight: bold;
    font-size: 14px;
}

@media(max-width: 850px) {
    .wishlist-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
    }
}

@media(max-width: 550px) {
    .wishlist-grid {
        grid-template-columns: 1fr;
    }

    .page-title {
        font-size: 26px;
    }
}
</style>
</head>

<body>

<div class="wishlist-container">

    <a href="../index.php" class="back-link">
        <i class="fa-solid fa-arrow-left"></i>
        Back to Store
    </a>

    <h1 class="page-title">
        <i class="fa-solid fa-heart"></i>
        My Wishlist
    </h1>

    <p class="subtitle">
        Your favorite books, all in one place.
    </p>

    <p class="wishlist-count">
        <?= $total_wishlist; ?> saved book(s)
    </p>

    <?php if ($total_wishlist > 0): ?>

        <div class="wishlist-grid">

            <?php foreach ($wishlist_books as $book): ?>

                <?php $stock = (int) $book['stock']; ?>

                <div class="wishlist-card">

                    <?php if (!empty($book['badge'])): ?>
                        <span class="badge">
                            <?= htmlspecialchars($book['badge'], ENT_QUOTES, 'UTF-8'); ?>
                        </span>
                    <?php endif; ?>

                    <img
                        src="../assets/images/books/<?= htmlspecialchars($book['image'], ENT_QUOTES, 'UTF-8'); ?>"
                        alt="<?= htmlspecialchars($book['title'], ENT_QUOTES, 'UTF-8'); ?>"
                    >

                    <h3>
                        <?= htmlspecialchars($book['title'], ENT_QUOTES, 'UTF-8'); ?>
                    </h3>

                    <p class="author">
                        <?= htmlspecialchars($book['author'], ENT_QUOTES, 'UTF-8'); ?>
                    </p>

                    <p class="price">
                        Rp. <?= htmlspecialchars($book['price']); ?>
                    </p>

                    <p class="stock">
                        <?php if ($stock <= 0): ?>
                            <span class="out-stock">Out of Stock</span>
                        <?php elseif ($stock <= 10): ?>
                            <span class="low-stock">
                                Stock: <?= $stock; ?> left
                            </span>
                        <?php else: ?>
                            <span class="in-stock">
                                Stock: <?= $stock; ?>
                            </span>
                        <?php endif; ?>
                    </p>

                    <div class="book-actions">

                        <a
                            href="book_detail.php?id=<?= (int)$book['book_id']; ?>&from=wishlist"
                            class="detail-btn"
                        >
                            View Details
                            <i class="fa-solid fa-arrow-right"></i>
                        </a>

                        <form
                            action="../process/wishlist_action.php"
                            method="POST"
                            onsubmit="return confirm('Remove this book from your Wishlist?')"
                        >
                            <input
                                type="hidden"
                                name="book_id"
                                value="<?= (int)$book['book_id']; ?>"
                            >

                            <input
                                type="hidden"
                                name="action"
                                value="remove"
                            >

                            <input
                                type="hidden"
                                name="from"
                                value="wishlist"
                            >

                            <button type="submit" class="remove-btn">
                                <i class="fa-solid fa-trash"></i>
                                Remove
                            </button>
                        </form>
                    </div>
                </div>
            <?php endforeach; ?>

        </div>

    <?php else: ?>

        <div class="empty-wishlist">
            <i class="fa-regular fa-heart"></i>
            <h2>Your Wishlist is Empty</h2>

            <p>
                You haven't saved any books yet.
                Start exploring and find your next favorite read!
            </p>

            <a href="../index.php" class="shop-btn">
                Explore Books
                <i class="fa-solid fa-arrow-right"></i>
            </a>

        </div>
    <?php endif; ?>
</div>
</body>
</html>
