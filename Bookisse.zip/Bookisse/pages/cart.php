
<?php
session_start();

if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit;
}

require __DIR__ . '/../config/database.php';

$user_id = (int) $_SESSION['user']['id'];

$stmt = $conn->prepare("
    SELECT
        c.id AS cart_id,
        c.qty,
        b.id AS book_id,
        b.title,
        b.author,
        b.price,
        b.image,
        b.stock
    FROM cart c
    INNER JOIN books b ON b.id = c.book_id
    WHERE c.user_id = ?
    ORDER BY c.id DESC
");

$stmt->bind_param('i', $user_id);
$stmt->execute();

$result = $stmt->get_result();

$items = [];
$cart_total = 0;

while ($row = $result->fetch_assoc()) {
    $row['subtotal'] = (float)$row['price'] * (int)$row['qty'];
    $cart_total += $row['subtotal'];
    $items[] = $row;
}

$stmt->close();

function rupiah($number) {
    return 'Rp ' . number_format((float)$number, 2, '.', ',');
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Shopping Cart | BOOKISSE</title>

<link href="https://fonts.googleapis.com/css2?family=Irish+Grover&display=swap" rel="stylesheet">

<style>
* {
    box-sizing: border-box;
}

body {
    margin: 0;
    min-height: 100vh;
    background: #2B1033;
    color: #fff;
    font-family: 'Irish Grover', cursive;
    padding: 35px 5%;
}

.container {
    max-width: 1100px;
    margin: auto;
}

h1 {
    color: #F4B43A;
    text-align: center;
    font-size: clamp(30px, 5vw, 44px);
    margin: 5px 0 28px;
}

.top-actions {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 12px;
    margin-bottom: 20px;
}

.back-button {
    display: inline-block;
    padding: 12px 22px;
    background: #F4B43A;
    color: #2B1033;
    border: 2px solid #F4B43A;
    border-radius: 12px;
    text-decoration: none;
    font-family: 'Irish Grover', cursive;
    font-size: 16px;
    transition: .25s ease;
}

.back-button:hover {
    background: transparent;
    color: #F4B43A;
}

.cart-list {
    display: grid;
    gap: 16px;
}

.cart-item {
    display: grid;
    grid-template-columns: 30px 100px minmax(0, 1fr) auto;
    align-items: center;
    gap: 18px;
    background: #5C2A66;
    border: 1px solid rgba(244,180,58,.2);
    border-radius: 16px;
    padding: 18px;
}

.pick {
    width: 19px;
    height: 19px;
    accent-color: #F4B43A;
    cursor: pointer;
}

.cover {
    width: 100px;
    height: 135px;
    object-fit: cover;
    border-radius: 9px;
    background: #eee;
}

.book-info h3 {
    margin: 0 0 7px;
    color: #fff;
    font-size: 20px;
}

.muted {
    color: #e2d8e5;
    margin: 5px 0;
}

.price {
    color: #F4B43A;
    font-weight: bold;
}

.item-actions {
    display: flex;
    flex-direction: column;
    align-items: flex-end;
    gap: 10px;
}

.qty-form {
    display: flex;
    align-items: center;
    gap: 8px;
    margin: 0;
}

.qty-form button {
    display: inline-flex;
    justify-content: center;
    align-items: center;
    width: 38px;
    height: 38px;
    min-width: 38px;
    padding: 0;
    border: 0;
    border-radius: 9px;
    background: #F4B43A;
    color: #2B1033;
    font-family: 'Irish Grover', cursive;
    font-size: 18px;
    cursor: pointer;
    transition: .2s ease;
}

.qty-form button:hover:not(:disabled) {
    background: #ffd16b;
    transform: translateY(-2px);
}

.qty-form button:disabled {
    opacity: .4;
    cursor: not-allowed;
}

.qty-value {
    min-width: 28px;
    text-align: center;
}

.delete-btn {
    display: inline-block;
    width: auto;
    padding: 9px 15px;
    border: 0;
    border-radius: 9px;
    background: #96394e;
    color: white;
    font-family: 'Irish Grover', cursive;
    font-size: 14px;
    cursor: pointer;
    transition: .2s ease;
}

.delete-btn:hover {
    background: #b84c63;
}

.summary {
    margin: 24px 0 0 auto;
    max-width: 390px;
    background: #4B2154;
    border-radius: 16px;
    padding: 22px;
}

.summary-line {
    display: flex;
    justify-content: space-between;
    gap: 15px;
    margin: 8px 0;
}

.summary-total {
    border-top: 1px solid #87658e;
    padding-top: 14px;
    margin-top: 14px;
    color: #F4B43A;
    font-size: 21px;
}

.checkout-btn {
    display: block;
    width: 100%;
    margin-top: 18px;
    padding: 13px 20px;
    border: 2px solid #F4B43A;
    border-radius: 10px;
    background: #F4B43A;
    color: #2B1033;
    font-family: 'Irish Grover', cursive;
    font-size: 17px;
    font-weight: bold;
    cursor: pointer;
    transition: .25s ease;
}

.checkout-btn:hover {
    background: transparent;
    color: #F4B43A;
}

.empty {
    background: #4B2154;
    padding: 45px 20px;
    border-radius: 16px;
    text-align: center;
}

.empty p {
    color: #e6dce8;
}

.empty a {
    display: inline-block;
    margin-top: 12px;
    background: #F4B43A;
    color: #2B1033;
    padding: 12px 20px;
    border-radius: 9px;
    text-decoration: none;
}

@media(max-width:650px) {
    body {
        padding: 22px 4%;
    }

    .cart-item {
        grid-template-columns: 24px 75px minmax(0,1fr);
        gap: 10px;
        padding: 12px;
    }

    .cover {
        width: 75px;
        height: 105px;
    }

    .book-info h3 {
        font-size: 16px;
    }

    .item-actions {
        grid-column: 2/4;
        flex-direction: row;
        justify-content: space-between;
        align-items: center;
    }

    .summary {
        max-width: none;
    }

    .top-actions {
        align-items: center;
    }

    .back-button {
        padding: 10px 13px;
        font-size: 13px;
    }
}
</style>
</head>

<body>

<div class="container">

    <h1>Shopping Cart 🛒</h1>

    <div class="top-actions">

        <a class="back-button" href="../index.php">
            ← Continue Shopping
        </a>

        <span>
            <?= count($items) ?> book(s) in your cart
        </span>

    </div>

    <?php if (!$items): ?>

        <div class="empty">
            <h2>Your cart is empty</h2>

            <p>
                Looks like you haven't added any books yet.
            </p>

            <a href="../index.php">
                Explore Books
            </a>
        </div>

    <?php else: ?>

        <form
            id="selectedCheckout"
            action="checkout.php"
            method="POST">
        </form>

        <div class="cart-list">

            <?php foreach ($items as $item): ?>

                <div class="cart-item">

                    <input
                        class="pick"
                        type="checkbox"
                        name="selected_ids[]"
                        value="<?= (int)$item['book_id'] ?>"
                        form="selectedCheckout"
                        checked
                        aria-label="Select <?= htmlspecialchars($item['title'], ENT_QUOTES, 'UTF-8') ?>"
                    >

                    <img
                        class="cover"
                        src="../assets/images/books/<?= htmlspecialchars($item['image'] ?? '', ENT_QUOTES, 'UTF-8') ?>"
                        alt="<?= htmlspecialchars($item['title'], ENT_QUOTES, 'UTF-8') ?>"
                    >

                    <div class="book-info">

                        <h3>
                            <?= htmlspecialchars($item['title'], ENT_QUOTES, 'UTF-8') ?>
                        </h3>

                        <p class="muted">
                            By <?= htmlspecialchars($item['author'], ENT_QUOTES, 'UTF-8') ?>
                        </p>

                        <p class="price">
                            <?= rupiah($item['price']) ?> / book
                        </p>

                        <p class="muted">
                            Subtotal:

                            <strong
                                class="price item-subtotal"
                                data-price="<?= (float)$item['price'] ?>"
                                data-qty="<?= (int)$item['qty'] ?>"
                            >
                                <?= rupiah($item['subtotal']) ?>
                            </strong>
                        </p>

                    </div>

                    <div class="item-actions">

                        <form
                            class="qty-form"
                            action="../process/cart_action.php"
                            method="POST"
                        >

                            <input
                                type="hidden"
                                name="action"
                                value="update"
                            >

                            <input
                                type="hidden"
                                name="cart_id"
                                value="<?= (int)$item['cart_id'] ?>"
                            >

                            <button
                                type="submit"
                                name="change"
                                value="minus"
                                aria-label="Decrease quantity"
                            >
                                −
                            </button>

                            <span class="qty-value">
                                <?= (int)$item['qty'] ?>
                            </span>

                            <button
                                type="submit"
                                name="change"
                                value="plus"
                                aria-label="Increase quantity"
                                <?= ((int)$item['qty'] >= (int)$item['stock']) ? 'disabled title="Stock limit reached"' : '' ?>
                            >
                                +
                            </button>

                        </form>

                        <form
                            action="../process/cart_action.php"
                            method="POST"
                            onsubmit="return confirm('Remove this book from your cart?');"
                        >

                            <input
                                type="hidden"
                                name="action"
                                value="delete"
                            >

                            <input
                                type="hidden"
                                name="cart_id"
                                value="<?= (int)$item['cart_id'] ?>"
                            >

                            <button
                                class="delete-btn"
                                type="submit"
                            >
                                Delete Book
                            </button>

                        </form>

                    </div>

                </div>

            <?php endforeach; ?>

        </div>

        <div class="summary">

            <div class="summary-line">
                <span>All Cart Total</span>

                <strong>
                    <?= rupiah($cart_total) ?>
                </strong>
            </div>

            <div class="summary-line summary-total">
                <span>Selected Total</span>

                <strong id="selectedTotal">
                    Rp 0.00
                </strong>
            </div>

            <button
                class="checkout-btn"
                type="submit"
                form="selectedCheckout"
            >
                Checkout Selected Books →
            </button>

            <p
                id="selectionHint"
                style="text-align:center;color:#e5dce8;font-size:13px;margin-bottom:0"
            >
                All books are selected by default. Untick books you don't want to buy.
            </p>

        </div>

    <?php endif; ?>

</div>

<script>
const checkboxes = [
    ...document.querySelectorAll('.pick')
];

const totalOutput =
    document.getElementById('selectedTotal');

const checkoutForm =
    document.getElementById('selectedCheckout');

const hint =
    document.getElementById('selectionHint');

function formatRupiah(value) {
    return 'Rp ' + new Intl.NumberFormat('en-US', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    }).format(value);
}

function updateSelectedTotal() {

    let total = 0;
    let count = 0;

    checkboxes.forEach(box => {

        if (box.checked) {

            count++;

            const row = box.closest('.cart-item');

            const subtotal =
                row.querySelector('.item-subtotal');

            total +=
                Number(subtotal.dataset.price) *
                Number(subtotal.dataset.qty);
        }

    });

    if (totalOutput) {
        totalOutput.textContent =
            formatRupiah(total);
    }

    if (hint) {
        hint.textContent = count
            ? `${count} book(s) selected for checkout.`
            : 'Select at least one book to continue.';
    }
}

checkboxes.forEach(box => {
    box.addEventListener('change', updateSelectedTotal);
});

if (checkoutForm) {

    checkoutForm.addEventListener('submit', event => {

        if (!checkboxes.some(box => box.checked)) {
            event.preventDefault();
            alert('Please select at least one book to checkout.');
        }

    });

}

updateSelectedTotal();
</script>
</body>
</html>