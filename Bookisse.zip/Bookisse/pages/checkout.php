
<?php
session_start();

require_once __DIR__ . '/../config/database.php';

// Gunakan zona waktu Indonesia.
date_default_timezone_set('Asia/Jakarta');

// Cek login.
if (!isset($_SESSION['user'])) {
    header("Location: ../pages/login.php");
    exit;
}

$user_id = (int) $_SESSION['user']['id'];

// Ambil ID buku yang dipilih dari halaman checkout.
$selected_ids = $_POST['selected_ids'] ?? [];

if (!is_array($selected_ids)) {
    $selected_ids = [];
}

$selected_ids = array_values(array_unique(array_filter(
    array_map('intval', $selected_ids),
    function ($id) {
        return $id > 0;
    }
)));

if (empty($selected_ids)) {
    echo "<script>
        alert('Please select at least one book.');
        window.location='../pages/cart.php';
    </script>";
    exit;
}

// Siapkan placeholder untuk query IN.
$placeholders = implode(',', array_fill(0, count($selected_ids), '?'));

// Fungsi untuk menjalankan prepared statement dengan parameter dinamis.
function bindDynamicParams($stmt, $types, &$params)
{
    $bind = [$types];

    foreach ($params as $key => &$value) {
        $bind[] = &$value;
    }

    call_user_func_array([$stmt, 'bind_param'], $bind);
}

// Mulai database transaction.
mysqli_begin_transaction($conn);

try {

    // Ambil hanya buku yang dipilih dan milik user.
    // FOR UPDATE mengunci baris selama proses checkout.
    $sql = "
        SELECT
            c.id AS cart_id,
            c.qty,
            b.id AS book_id,
            b.title,
            b.price,
            b.stock
        FROM cart c
        INNER JOIN books b ON b.id = c.book_id
        WHERE c.user_id = ?
        AND b.id IN ($placeholders)
        FOR UPDATE
    ";

    $stmt = $conn->prepare($sql);

    $params = array_merge([$user_id], $selected_ids);
    $types = str_repeat('i', count($params));

    bindDynamicParams($stmt, $types, $params);

    $stmt->execute();
    $result = $stmt->get_result();

    $items = [];
    $total = 0;

    while ($item = $result->fetch_assoc()) {

        $qty = (int) $item['qty'];
        $stock = (int) $item['stock'];

        // Validasi jumlah pembelian.
        if ($qty <= 0) {
            throw new Exception(
                "Invalid quantity for: " . $item['title']
            );
        }

        // Validasi stok.
        if ($stock < $qty) {
            throw new Exception(
                "Stock is insufficient for: " . $item['title']
            );
        }

        $item['qty'] = $qty;
        $item['price'] = (float) $item['price'];

        $total += $item['price'] * $qty;

        $items[] = $item;
    }

    $stmt->close();

    // Pastikan semua buku pilihan benar-benar ada di keranjang user.
    if (count($items) !== count($selected_ids)) {
        throw new Exception(
            "Some selected books are no longer available in your cart."
        );
    }

    // Buat data order terlebih dahulu.
    $order_stmt = $conn->prepare("
        INSERT INTO orders
        (user_id, total, status, payment_status)
        VALUES (?, ?, 'pending', 'pending')
    ");

    $order_stmt->bind_param("id", $user_id, $total);

    if (!$order_stmt->execute()) {
        throw new Exception($order_stmt->error);
    }

    // Ambil ID asli dari database.
    $order_id = $conn->insert_id;

    $order_stmt->close();

    // Buat kode transaksi:
    // TBJ + tanggal + bulan + tahun + ID asli.
    // Contoh: TBJ10112632
    $tanggal_transaksi = date('dmy');

    $order_code = 'TBJ' . $tanggal_transaksi . $order_id;

    // Simpan kode transaksi ke tabel orders.
    $code_stmt = $conn->prepare("
        UPDATE orders
        SET order_code = ?
        WHERE id = ?
    ");

    $code_stmt->bind_param("si", $order_code, $order_id);

    if (!$code_stmt->execute()) {
        throw new Exception($code_stmt->error);
    }

    $code_stmt->close();

    // Siapkan query detail order.
    $item_stmt = $conn->prepare("
        INSERT INTO order_items
        (order_id, book_id, quantity, price)
        VALUES (?, ?, ?, ?)
    ");

    // Siapkan query pengurangan stok.
    $stock_stmt = $conn->prepare("
        UPDATE books
        SET stock = stock - ?
        WHERE id = ?
        AND stock >= ?
    ");

    // Simpan detail pesanan dan kurangi stok.
    foreach ($items as $item) {

        $book_id = (int) $item['book_id'];
        $qty = (int) $item['qty'];
        $price = (float) $item['price'];

        // Kurangi stok buku.
        $stock_stmt->bind_param(
            "iii",
            $qty,
            $book_id,
            $qty
        );

        if (!$stock_stmt->execute()) {
            throw new Exception($stock_stmt->error);
        }

        if ($stock_stmt->affected_rows !== 1) {
            throw new Exception(
                "Stock changed or is insufficient for: " . $item['title']
            );
        }

        // Simpan detail buku ke order_items.
        $item_stmt->bind_param(
            "iiid",
            $order_id,
            $book_id,
            $qty,
            $price
        );

        if (!$item_stmt->execute()) {
            throw new Exception($item_stmt->error);
        }
    }

    $item_stmt->close();
    $stock_stmt->close();

    // Hapus hanya buku yang sudah dipilih untuk checkout.
    $delete_sql = "
        DELETE FROM cart
        WHERE user_id = ?
        AND book_id IN ($placeholders)
    ";

    $delete_stmt = $conn->prepare($delete_sql);

    $delete_params = array_merge([$user_id], $selected_ids);
    $delete_types = str_repeat('i', count($delete_params));

    bindDynamicParams(
        $delete_stmt,
        $delete_types,
        $delete_params
    );

    if (!$delete_stmt->execute()) {
        throw new Exception($delete_stmt->error);
    }

    $delete_stmt->close();

    // Semua proses berhasil.
    mysqli_commit($conn);

    echo "<script>
        alert('Order berhasil dibuat!\\nOrder Code: $order_code');
        window.location='../pages/payment.php?order_id=$order_id';
    </script>";

    exit;

} catch (Throwable $e) {

    // Batalkan seluruh proses jika terjadi kesalahan.
    mysqli_rollback($conn);

    $error_message = addslashes($e->getMessage());

    echo "<script>
        alert('Gagal membuat order: $error_message');
        window.location='../pages/cart.php';
    </script>";

    exit;
}
?>
