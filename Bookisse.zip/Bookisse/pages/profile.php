<?php
session_start();
if (!isset($_SESSION['user']['id'])) {
    header("Location: login.php");
    exit;
}

require "../config/database.php";
$user_id = (int) $_SESSION['user']['id'];
$upload_message = $_GET['upload'] ?? '';
$edit_message = $_GET['edit'] ?? '';

/* =========================
   PROSES EDIT PROFILE
========================= */

if ($_SERVER['REQUEST_METHOD'] === 'POST'
    && isset($_POST['update_profile'])) {

    $new_name = trim($_POST['name'] ?? '');
    $new_email = trim($_POST['email'] ?? '');

    // Validasi nama
    if ($new_name === '' || strlen($new_name) > 100) {
        header("Location: profile.php?edit=invalid_name");
        exit;
    }

    // Validasi email
    if (!filter_var($new_email, FILTER_VALIDATE_EMAIL)) {
        header("Location: profile.php?edit=invalid_email");
        exit;
    }

    // Cek apakah email digunakan akun lain
    $check_stmt = mysqli_prepare(
        $conn,
        "SELECT id FROM users WHERE email = ? AND id != ? LIMIT 1"
    );

    if (!$check_stmt) {
        die("Database error: " . mysqli_error($conn));
    }

    mysqli_stmt_bind_param(
        $check_stmt,
        "si",
        $new_email,
        $user_id
    );

    mysqli_stmt_execute($check_stmt);

    $check_result = mysqli_stmt_get_result($check_stmt);
    $existing_user = mysqli_fetch_assoc($check_result);

    mysqli_stmt_close($check_stmt);

    if ($existing_user) {
        header("Location: profile.php?edit=email_used");
        exit;
    }

    // Update database
    $update_stmt = mysqli_prepare(
        $conn,
        "UPDATE users SET name = ?, email = ? WHERE id = ?"
    );

    if (!$update_stmt) {
        die("Database error: " . mysqli_error($conn));
    }

    mysqli_stmt_bind_param(
        $update_stmt,
        "ssi",
        $new_name,
        $new_email,
        $user_id
    );

    if (mysqli_stmt_execute($update_stmt)) {

        mysqli_stmt_close($update_stmt);

        // Update session
        $_SESSION['user']['name'] = $new_name;
        $_SESSION['user']['email'] = $new_email;

        header("Location: profile.php?edit=success");
        exit;

    } else {

        mysqli_stmt_close($update_stmt);

        header("Location: profile.php?edit=failed");
        exit;
    }
}

// =====================================
// PROSES UPLOAD FOTO PROFIL
// =====================================

if ($_SERVER['REQUEST_METHOD'] === 'POST'
    && isset($_POST['change_photo'])) {

    if (
        !isset($_FILES['profile_picture']) ||
        $_FILES['profile_picture']['error'] !== UPLOAD_ERR_OK
    ) {
        header("Location: profile.php?upload=error");
        exit;
    }

    $file = $_FILES['profile_picture'];

    if ($file['size'] > 5 * 1024 * 1024 || $file['size'] <= 0) {
        header("Location: profile.php?upload=large");
        exit;
    }

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($file['tmp_name']);

    $allowed = [
        'image/jpeg' => 'jpg',
        'image/png'  => 'png',
        'image/webp' => 'webp'
    ];

    if (!isset($allowed[$mime])) {
        header("Location: profile.php?upload=invalid");
        exit;
    }

    // Pastikan akun tersedia
    $stmt = mysqli_prepare(
        $conn,
        "SELECT profile_picture FROM users WHERE id = ? LIMIT 1"
    );

    if (!$stmt) {
        die("Database error: " . mysqli_error($conn));
    }

    mysqli_stmt_bind_param($stmt, "i", $user_id);
    mysqli_stmt_execute($stmt);

    $result = mysqli_stmt_get_result($stmt);
    $user_data = mysqli_fetch_assoc($result);

    mysqli_stmt_close($stmt);

    if (!$user_data) {
        die("User tidak ditemukan.");
    }

    $old_picture = $user_data['profile_picture'] ?? '';

    // Folder penyimpanan
    $upload_dir = __DIR__ . "/../uploads/profile/";

    if (!is_dir($upload_dir)) {
        if (!mkdir($upload_dir, 0755, true)) {
            die("Folder upload gagal dibuat.");
        }
    }

    // Nama file unik
    $extension = $allowed[$mime];

    $filename = "user_" . $user_id . "_" .
        bin2hex(random_bytes(8)) . "." . $extension;

    $destination = $upload_dir . $filename;
    $relative_path = "uploads/profile/" . $filename;

    // Pindahkan file
    if (!move_uploaded_file($file['tmp_name'], $destination)) {
        die("Gagal memindahkan foto. Periksa izin folder uploads.");
    }

    // Simpan ke database
    $stmt = mysqli_prepare(
        $conn,
        "UPDATE users SET profile_picture = ? WHERE id = ?"
    );

    if (!$stmt) {
        unlink($destination);
        die("Database error: " . mysqli_error($conn));
    }

    mysqli_stmt_bind_param(
        $stmt,
        "si",
        $relative_path,
        $user_id
    );

    if (!mysqli_stmt_execute($stmt)) {
        $error = mysqli_stmt_error($stmt);
        mysqli_stmt_close($stmt);
        unlink($destination);
        die("Gagal menyimpan database: " . $error);
    }

    mysqli_stmt_close($stmt);

    // Verifikasi hasil database
    $stmt = mysqli_prepare(
        $conn,
        "SELECT profile_picture FROM users WHERE id = ? LIMIT 1"
    );

    mysqli_stmt_bind_param($stmt, "i", $user_id);
    mysqli_stmt_execute($stmt);

    $result = mysqli_stmt_get_result($stmt);
    $saved_data = mysqli_fetch_assoc($result);

    mysqli_stmt_close($stmt);

    if (($saved_data['profile_picture'] ?? '') !== $relative_path) {
        unlink($destination);
        die("Foto belum berhasil tersimpan ke database.");
    }

    // Update session
    $_SESSION['user']['profile_picture'] = $relative_path;

    // Hapus foto lama setelah foto baru tersimpan
    if (
        !empty($old_picture) &&
        strpos($old_picture, 'uploads/profile/') === 0
    ) {
        $old_file = __DIR__ . "/../" . $old_picture;

        if (is_file($old_file)) {
            unlink($old_file);
        }
    }

    header("Location: profile.php?upload=success");
    exit;
}

// =====================================
// AMBIL DATA PROFILE
// =====================================

$user = $_SESSION['user'];

$name = $user['name'] ?? 'Bookisse User';
$email = $user['email'] ?? '-';
$role = $user['role'] ?? 'user';

$cart = 0;

$cart_stmt = mysqli_prepare(
    $conn,
    "SELECT COUNT(*) AS total FROM cart WHERE user_id = ?"
);

if ($cart_stmt) {
    mysqli_stmt_bind_param($cart_stmt, "i", $user_id);
    mysqli_stmt_execute($cart_stmt);

    $cart_result = mysqli_stmt_get_result($cart_stmt);
    $cart_data = mysqli_fetch_assoc($cart_result);

    $cart = (int) ($cart_data['total'] ?? 0);

    mysqli_stmt_close($cart_stmt);
}

// Ambil foto terbaru
$profile_picture = '';

$photo_stmt = mysqli_prepare(
    $conn,
    "SELECT profile_picture FROM users WHERE id = ? LIMIT 1"
);

if ($photo_stmt) {
    mysqli_stmt_bind_param($photo_stmt, "i", $user_id);
    mysqli_stmt_execute($photo_stmt);

    $photo_result = mysqli_stmt_get_result($photo_stmt);
    $photo_data = mysqli_fetch_assoc($photo_result);

    $profile_picture = $photo_data['profile_picture'] ?? '';

    mysqli_stmt_close($photo_stmt);
}

$_SESSION['user']['profile_picture'] = $profile_picture;

$initial = strtoupper(substr(trim($name), 0, 1));

?>

<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>BOOKISSE | My Profile</title>

<link href="https://fonts.googleapis.com/css2?family=Irish+Grover&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">

<style>

:root {
    --bg: #2B1033;
    --card: #4B2154;
    --card-light: #5C2A66;
    --gold: #F4B43A;
    --white: #fff;
    --muted: #D8CADA;
}

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    min-height: 100vh;
    background: radial-gradient(circle at top right, #51245B 0, var(--bg) 42%);
    font-family: 'Irish Grover', cursive;
    color: var(--white);
}

button, input, textarea, select {
    font-family: inherit;
}

a {
    text-decoration: none;
}

.container {
    width: min(1100px, 92%);
    margin: 0 auto;
    padding: 34px 0 50px;
}

.topbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 16px;
    margin-bottom: 28px;
}

.brand {
    color: var(--gold);
    font-weight: 800;
    letter-spacing: 2px;
    font-size: 20px;
}

.home-link {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 11px 18px;
    background: var(--gold);
    color: var(--bg);
    border-radius: 9px;
    font-weight: 700;
    transition: .2s ease;
}

.home-link:hover {
    background: #FFD06B;
    transform: translateY(-1px);
}

.page-title {
    color: var(--gold);
    margin: 0 0 7px;
    font-size: clamp(26px, 4vw, 34px);
}

.subtitle {
    color: var(--muted);
    margin: 0 0 25px;
}

.profile-card {
    display: flex;
    align-items: center;
    gap: 24px;
    padding: 30px;
    border-radius: 20px;
    background: linear-gradient(120deg, #4B2154, #60306A);
    border: 1px solid rgba(244,180,58,.18);
    box-shadow: 0 14px 35px rgba(0,0,0,.18);
}

.avatar {
    width: 88px;
    height: 88px;
    flex: 0 0 88px;
    display: grid;
    place-items: center;
    overflow: hidden;
    border-radius: 50%;
    background: var(--gold);
    color: var(--bg);
    font-size: 36px;
    font-weight: 800;
    border: 4px solid rgba(255,255,255,.25);
}

.avatar img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    display: block;
}

.photo-tools {
    margin-top: 14px;
}

.photo-form {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: 9px;
}

.photo-input {
    max-width: 230px;
    color: var(--muted);
    font-size: 12px;
}

.photo-button {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 9px 14px;
    border: 0;
    border-radius: 8px;
    background: var(--gold);
    color: var(--bg);
    font-size: 12px;
    font-weight: 700;
    cursor: pointer;
}

.photo-button:hover {
    background: #FFD06A;
}

.photo-help {
    color: var(--muted);
    font-size: 11px;
    margin: 7px 0 0;
}

.upload-alert {
    margin: 0 0 18px;
    padding: 12px 16px;
    border-radius: 10px;
    font-size: 13px;
}

.upload-alert.success {
    background: rgba(50,150,90,.18);
    border: 1px solid rgba(100,220,140,.4);
    color: #C9FFD9;
}

.upload-alert.error {
    background: rgba(180,50,60,.18);
    border: 1px solid rgba(255,120,130,.4);
    color: #FFD1D4;
}

.profile-heading h2 {
    margin: 0 0 8px;
    font-size: 24px;
}

.profile-heading p {
    margin: 0;
    color: var(--muted);
    overflow-wrap: anywhere;
}

.role-pill {
    display: inline-block;
    margin-top: 12px;
    padding: 6px 12px;
    border-radius: 20px;
    background: rgba(244,180,58,.16);
    color: var(--gold);
    font-size: 12px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: .7px;
}

.section-title {
    color: var(--gold);
    margin: 34px 0 16px;
    font-size: 20px;
}

.details {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 16px;
}

.detail-item {
    background: rgba(75,33,84,.88);
    padding: 19px 21px;
    border-radius: 14px;
    border: 1px solid rgba(255,255,255,.07);
}

.detail-item span {
    display: block;
    color: var(--muted);
    font-size: 13px;
    margin-bottom: 8px;
}

.detail-item strong {
    font-size: 16px;
    overflow-wrap: anywhere;
}

.menu {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 18px;
    margin-top: 18px;
}

.menu-card {
    min-height: 215px;
    padding: 25px 18px;
    border-radius: 18px;
    background: var(--card-light);
    border: 1px solid rgba(255,255,255,.07);
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    text-align: center;
    transition: .2s ease;
}

.menu-card:hover {
    transform: translateY(-5px);
    border-color: rgba(244,180,58,.5);
    box-shadow: 0 12px 24px rgba(0,0,0,.2);
}

.menu-card i {
    color: var(--gold);
    font-size: 34px;
    margin-bottom: 15px;
}

.menu-card h3 {
    font-size: 20px;
    margin: 0 0 7px;
}

.menu-card p {
    color: var(--muted);
    font-size: 14px;
    margin: 0;
}

.card-action {
    margin-top: 18px;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    background: var(--gold);
    color: var(--bg);
    padding: 10px 18px;
    border-radius: 9px;
    font-size: 13px;
    font-weight: 700;
    transition: .2s ease;
}

.card-action:hover {
    background: #FFD06A;
}

.logout-row {
    display: flex;
    justify-content: flex-end;
    margin-top: 28px;
}

.logout-btn {
    display: inline-flex;
    align-items: center;
    gap: 9px;
    padding: 12px 22px;
    border-radius: 10px;
    background: #8E303B;
    color: white;
    font-weight: 700;
    transition: .2s ease;
}

.logout-btn:hover {
    background: #A83A47;
}

@media (max-width: 900px) {
    .menu {
        grid-template-columns: repeat(2, minmax(0,1fr));
    }
}

@media (max-width: 600px) {
    .container {
        width: 92%;
        padding-top: 23px;
    }

    .topbar {
        align-items: flex-start;
    }

    .profile-card {
        padding: 22px;
        gap: 16px;
    }

    .avatar {
        width: 68px;
        height: 68px;
        flex-basis: 68px;
        font-size: 28px;
    }

    .profile-heading h2 {
        font-size: 19px;
    }

    .details {
        grid-template-columns: 1fr;
    }

    .menu {
        grid-template-columns: 1fr;
        gap: 13px;
    }

    .menu-card {
        min-height: 185px;
    }
}

</style>
</head>

<body>

<div class="container">

    <div class="topbar">
        <div class="brand">BOOKISSE</div>

        <a href="../index.php" class="home-link">
            <i class="fa-solid fa-arrow-left"></i>
            Back to Store
        </a>
    </div>

    <h1 class="page-title">My Profile</h1>

    <p class="subtitle">
        Manage your account and explore your Bookisse activity.
    </p>

    <!-- UPLOAD NOTIFICATION -->

    <?php if ($upload_message === 'success'): ?>
        <div class="upload-alert success">
            <i class="fa-solid fa-circle-check"></i>
            Profile photo updated successfully!
        </div>

    <?php elseif (in_array($upload_message, ['large', 'invalid', 'error'], true)): ?>
        <div class="upload-alert error">
            <i class="fa-solid fa-circle-exclamation"></i>

            <?php
            if ($upload_message === 'large') {
                echo 'The photo is too large. Maximum file size is 5 MB.';
            } elseif ($upload_message === 'invalid') {
                echo 'Invalid file type. Please choose JPG, PNG, or WEBP.';
            } else {
                echo 'Upload failed. Please try again.';
            }
            ?>
        </div>
    <?php endif; ?>

    <!-- PROFILE CARD -->

    <section class="profile-card">
        <div class="avatar">

            <?php if (
                !empty($profile_picture) &&
                is_file(__DIR__ . '/../' . $profile_picture)
            ): ?>
                <img
                    src="../<?= htmlspecialchars($profile_picture, ENT_QUOTES, 'UTF-8'); ?>"
                    alt="Profile photo">

            <?php else: ?>

                <?= htmlspecialchars($initial); ?>

            <?php endif; ?>

        </div>

        <div class="profile-heading">
            <h2>
                Welcome, <?= htmlspecialchars($name); ?>!
            </h2>

            <p><?= htmlspecialchars($email); ?></p>

            <span class="role-pill">
                <?= htmlspecialchars($role); ?> account
            </span>

            <!-- FORM UPLOAD -->

            <div class="photo-tools">

                <form
                    class="photo-form"
                    action="profile.php"
                    method="POST"
                    enctype="multipart/form-data">

                    <input
                        type="file"
                        name="profile_picture"
                        id="profile_picture"
                        class="photo-input"
                        accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp"
                        required>

                    <button
                        type="submit"
                        name="change_photo"
                        value="1"
                        class="photo-button">

                        <i class="fa-solid fa-camera"></i>
                        Change Profile Photo

                    </button>

                </form>

                <p class="photo-help">
                    JPG, PNG, or WEBP · Maximum 5 MB
                </p>

            </div>

        </div>

    </section>
    <!-- ACCOUNT INFORMATION -->

    <h2 class="section-title">Account Information</h2>
    <section class="details">

        <div class="detail-item">
            <span>Full Name</span>
            <strong><?= htmlspecialchars($name); ?></strong>
        </div>

        <div class="detail-item">
            <span>Email Address</span>
            <strong><?= htmlspecialchars($email); ?></strong>
        </div>
    </section>

    <!-- MENU -->

    <h2 class="section-title">Your Bookisse</h2>

    <section class="menu">
        <div class="menu-card">
            <i class="fa-solid fa-cart-shopping"></i>
            <h3><?= $cart; ?></h3>
            <p>Items in your cart</p>

            <a href="cart.php" class="card-action">
                Open Cart
                <i class="fa-solid fa-arrow-right"></i>
            </a>
        </div>

        <div class="menu-card">
            <i class="fa-solid fa-book-open"></i>
            <h3>Shop</h3>
            <p>Discover your next read</p>

            <a href="../index.php" class="card-action">
                Browse Books
                <i class="fa-solid fa-arrow-right"></i>
            </a>
        </div>

        <div class="menu-card">
            <i class="fa-solid fa-box"></i>
            <h3>Orders</h3>
            <p>Track your purchases</p>

            <a href="order.php" class="card-action">
                View Orders
                <i class="fa-solid fa-arrow-right"></i>
            </a>
        </div>

        <div class="menu-card">
            <i class="fa-solid fa-comments"></i>
            <h3>Messages</h3>
            <p>Chat with the admin</p>

            <a href="messages.php" class="card-action">
                Open Chat
                <i class="fa-solid fa-arrow-right"></i>
            </a>
        </div>
    </section>

    <!-- LOGOUT -->

    <div class="logout-row">
        <a
            href="logout.php"
            class="logout-btn"
            onclick="return confirm('Are you sure you want to log out?')">
            <i class="fa-solid fa-right-from-bracket"></i>
            Logout

        </a>
    </div>
</div>

<script>
const profileInput = document.getElementById('profile_picture');
const avatar = document.querySelector('.avatar');

if (profileInput && avatar) {
    profileInput.addEventListener('change', function () {

        const file = this.files && this.files[0];

        if (!file) return;

        if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) {
            alert('Please choose a JPG, PNG, or WEBP image.');
            this.value = '';
            return;
        }

        if (file.size > 5 * 1024 * 1024) {
            alert('Maximum file size is 5 MB.');
            this.value = '';
            return;
        }

        const previewUrl = URL.createObjectURL(file);
        let preview = avatar.querySelector('img');

        if (!preview) {
            avatar.textContent = '';
            preview = document.createElement('img');
            preview.alt = 'Profile photo preview';
            avatar.appendChild(preview);
        }

        preview.src = previewUrl;

    });

}
</script>
</body>
</html>
