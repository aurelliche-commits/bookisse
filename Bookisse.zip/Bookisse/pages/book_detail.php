
<?php
session_start();
require "../config/database.php";

// CEK BOOK ID
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("Book ID tidak valid.");
}

$book_id = (int) $_GET['id'];

// AMBIL DATA BUKU
$stmt = mysqli_prepare(
    $conn,
    "SELECT * FROM books WHERE id = ? LIMIT 1"
);

if (!$stmt) {
    die("Database error: " . mysqli_error($conn));
}

mysqli_stmt_bind_param($stmt, "i", $book_id);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);
$book = mysqli_fetch_assoc($result);

mysqli_stmt_close($stmt);

if (!$book) {
    die("Book not found.");
}

// CEK STATUS WISHLIST
$is_wishlisted = false;

if (isset($_SESSION['user']['id'])) {

    $user_id = (int) $_SESSION['user']['id'];

    $wish_stmt = mysqli_prepare(
        $conn,
        "SELECT id FROM wishlist
         WHERE user_id = ? AND book_id = ?
         LIMIT 1"
    );

    if ($wish_stmt) {

        mysqli_stmt_bind_param(
            $wish_stmt,
            "ii",
            $user_id,
            $book_id
        );

        mysqli_stmt_execute($wish_stmt);

        $wish_result = mysqli_stmt_get_result($wish_stmt);

        $is_wishlisted = mysqli_num_rows($wish_result) > 0;

        mysqli_stmt_close($wish_stmt);
    }
}

$stock = (int) ($book['stock'] ?? 0);

$wishlist_message = $_GET['wishlist'] ?? '';

$fromWishlist = (
    isset($_GET['from']) &&
    $_GET['from'] === 'wishlist'
);

// FORMAT HARGA
function rupiah($number) {
    return 'Rp ' . number_format((float)$number, 2, '.', ',');
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>BOOKISSE | Book Detail</title>

<link
    href="https://fonts.googleapis.com/css2?family=Irish+Grover&display=swap"
    rel="stylesheet"
>

<link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"
>

<style>

:root {
    --bg: #2B1033;
    --card: #4B2154;
    --gold: #F4B43A;
    --white: #fff;
    --muted: #D8CADA;
}

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    min-height: 100vh;
    background: radial-gradient(
        circle at top right,
        #51245B 0,
        var(--bg) 45%
    );
    font-family: 'Irish Grover', cursive;
    color: var(--white);
}

.container {
    width: min(1050px, 92%);
    margin: auto;
    padding: 35px 0 60px;
}

.back-link {
    display: inline-flex;
    align-items: center;
    gap: 9px;
    color: var(--gold);
    text-decoration: none;
    margin-bottom: 28px;
}

.back-link:hover {
    color: #FFD06A;
}

.book-detail {
    display: grid;
    grid-template-columns: 350px 1fr;
    gap: 45px;
    background: linear-gradient(130deg, #4B2154, #60306A);
    padding: 35px;
    border-radius: 20px;
    border: 1px solid rgba(244,180,58,.2);
    box-shadow: 0 15px 35px rgba(0,0,0,.2);
}

.book-image {
    width: 100%;
    max-height: 480px;
    object-fit: contain;
    border-radius: 12px;
}

.book-info h1 {
    color: var(--gold);
    font-size: 32px;
    margin: 0 0 12px;
}

.author {
    color: var(--muted);
    margin-bottom: 20px;
}

.price {
    color: var(--gold);
    font-size: 26px;
    font-weight: bold;
    margin: 20px 0;
}

.description {
    line-height: 1.8;
    color: var(--muted);
    white-space: pre-line;
}

.info-label {
    color: var(--gold);
    font-weight: bold;
}

.stock {
    margin: 20px 0;
}

.in-stock {
    color: #A5F0B5;
}

.low-stock {
    color: #FFD06A;
}

.out-stock {
    color: #FF9999;
}

.actions {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: 13px;
    margin-top: 25px;
}

.action-btn {
    display: inline-flex;
    justify-content: center;
    align-items: center;
    gap: 9px;
    padding: 13px 20px;
    border: none;
    border-radius: 9px;
    text-decoration: none;
    font-family: inherit;
    font-weight: bold;
    font-size: 14px;
    cursor: pointer;
}

.cart-btn {
    background: var(--gold);
    color: var(--bg);
}

.cart-btn:hover {
    background: #FFD06A;
}

.wishlist-btn {
    background: #35153D;
    color: white;
    border: 1px solid rgba(255,255,255,.2);
}

.wishlist-btn i {
    color: #F06A85;
}

.wishlist-btn.active {
    border-color: #F06A85;
    color: #F06A85;
}

.disabled-btn {
    background: #777;
    color: white;
    cursor: not-allowed;
}

.alert {
    padding: 12px;
    margin-bottom: 20px;
    border-radius: 9px;
    background: rgba(244,180,58,.15);
    color: var(--gold);
}

@media(max-width: 750px) {

    .book-detail {
        grid-template-columns: 1fr;
        padding: 22px;
        gap: 25px;
    }

    .book-image {
        max-height: 350px;
    }

    .book-info h1 {
        font-size: 25px;
    }

}

</style>

</head>

<body>

<div class="container">

    <?php if ($fromWishlist): ?>

        <a href="wishlist.php" class="back-link">
            <i class="fa-solid fa-arrow-left"></i>
            Back to Wishlist
        </a>

    <?php else: ?>

        <a href="../index.php" class="back-link">
            <i class="fa-solid fa-arrow-left"></i>
            Back to Store
        </a>

    <?php endif; ?>

    <?php if ($wishlist_message === 'login'): ?>

        <div class="alert">
            Please log in to add books to your Wishlist.
        </div>

    <?php elseif ($wishlist_message === 'error'): ?>

        <div class="alert">
            Something went wrong. Please try again.
        </div>

    <?php elseif ($wishlist_message === 'added'): ?>

        <div class="alert">
            <i class="fa-solid fa-circle-check"></i>
            Book successfully added to your Wishlist!
        </div>

    <?php elseif ($wishlist_message === 'removed'): ?>

        <div class="alert">
            <i class="fa-solid fa-circle-check"></i>
            Book removed from your Wishlist.
        </div>

    <?php endif; ?>

    <section class="book-detail">

        <div>

            <img
                class="book-image"
                src="../assets/images/books/<?= htmlspecialchars($book['image'], ENT_QUOTES, 'UTF-8'); ?>"
                alt="<?= htmlspecialchars($book['title'], ENT_QUOTES, 'UTF-8'); ?>"
            >

        </div>

        <div class="book-info">

            <h1>
                <?= htmlspecialchars($book['title'], ENT_QUOTES, 'UTF-8'); ?>
            </h1>

            <p class="author">
                By <?= htmlspecialchars($book['author'], ENT_QUOTES, 'UTF-8'); ?>
            </p>

            <p>
                <span class="info-label">Category:</span>
                <?= htmlspecialchars($book['category'], ENT_QUOTES, 'UTF-8'); ?>
            </p>

            <p class="price">
                <?= rupiah($book['price']); ?>
            </p>

            <h3 class="info-label">
                Book Description
            </h3>

            <p class="description"><?=
                !empty($book['description'])
                    ? htmlspecialchars($book['description'], ENT_QUOTES, 'UTF-8')
                    : 'No description available.';
            ?></p>

            <div class="stock">

                <span class="info-label">Stock: </span>

                <?php if ($stock <= 0): ?>

                    <span class="out-stock">
                        Out of Stock
                    </span>

                <?php elseif ($stock <= 10): ?>

                    <span class="low-stock">
                        <?= $stock; ?> books left
                    </span>

                <?php else: ?>

                    <span class="in-stock">
                        <?= $stock; ?> books available
                    </span>

                <?php endif; ?>

            </div>

            <div class="actions">

                <!-- ADD TO CART -->

                <?php if ($stock > 0): ?>

                    <a
                        href="../process/add_cart.php?id=<?= $book_id; ?>"
                        class="action-btn cart-btn"
                    >
                        <i class="fa-solid fa-cart-shopping"></i>
                        Add to Cart
                    </a>

                <?php else: ?>

                    <button
                        class="action-btn disabled-btn"
                        disabled
                    >
                        <i class="fa-solid fa-cart-shopping"></i>
                        Out of Stock
                    </button>

                <?php endif; ?>

                <!-- WISHLIST -->

                <form
                    action="../process/wishlist_action.php"
                    method="POST"
                >

                    <input
                        type="hidden"
                        name="book_id"
                        value="<?= $book_id; ?>"
                    >

                    <input
                        type="hidden"
                        name="action"
                        value="<?= $is_wishlisted ? 'remove' : 'add'; ?>"
                    >

                    <input
                        type="hidden"
                        name="from"
                        value="<?= $fromWishlist ? 'wishlist' : 'detail'; ?>"
                    >

                    <button
                        type="submit"
                        class="action-btn wishlist-btn <?= $is_wishlisted ? 'active' : ''; ?>"
                    >

                        <i class="<?= $is_wishlisted ? 'fa-solid' : 'fa-regular'; ?> fa-heart"></i>

                        <?= $is_wishlisted
                            ? 'Remove from Wishlist'
                            : 'Add to Wishlist'; ?>

                    </button>

                </form>

            </div>

        </div>

    </section>

</div>
</body>
</html>