
<?php
session_start();
require "../config/database.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>About Us | BOOKISSE</title>

    <link rel="stylesheet" href="../assets/css/style.css?v=<?php echo time(); ?>">

    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"
    >

    <link
        href="https://fonts.googleapis.com/css2?family=Irish+Grover&display=swap"
        rel="stylesheet"
    >

    <style>
        body {
            font-family: 'Irish Grover', cursive;
            background: #2B1033;
            color: #FFFFFF;
        }

        .about-hero {
            padding: 80px 20px;
            text-align: center;
            background: linear-gradient(135deg, #2B1033, #5C2A66);
        }

        .about-hero h1 {
            color: #F4B43A;
            font-size: 48px;
            margin-bottom: 15px;
        }

        .about-hero p {
            max-width: 700px;
            margin: auto;
            font-size: 17px;
            line-height: 1.8;
        }

        .about-container {
            width: 90%;
            max-width: 1100px;
            margin: auto;
            padding: 60px 0;
        }

        .about-section {
            margin-bottom: 55px;
            text-align: center;
        }

        .about-section h2 {
            color: #F4B43A;
            font-size: 30px;
            margin-bottom: 18px;
        }

        .about-section p {
            font-size: 16px;
            line-height: 1.9;
            max-width: 850px;
            margin: auto;
            color: #ECECEC;
        }

        .about-cards {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 25px;
            margin-top: 35px;
        }

        .about-card {
            background: #5C2A66;
            border: 1px solid rgba(244, 180, 58, 0.35);
            border-radius: 15px;
            padding: 35px 25px;
            text-align: center;
            transition: 0.3s ease;
        }

        .about-card:hover {
            transform: translateY(-7px);
            border-color: #F4B43A;
        }

        .about-card i {
            font-size: 38px;
            color: #F4B43A;
            margin-bottom: 20px;
        }

        .about-card h3 {
            color: #F4B43A;
            font-size: 21px;
            margin-bottom: 15px;
        }

        .about-card p {
            font-size: 14px;
            line-height: 1.8;
            color: #ECECEC;
        }

        .about-cta {
            background: #5C2A66;
            border-radius: 15px;
            padding: 45px 25px;
            text-align: center;
            margin-top: 25px;
        }

        .about-cta h2 {
            color: #F4B43A;
            font-size: 30px;
            margin-bottom: 15px;
        }

        .about-cta p {
            line-height: 1.8;
            margin-bottom: 25px;
        }

        .about-button {
            display: inline-block;
            background: #F4B43A;
            color: #2B1033;
            text-decoration: none;
            padding: 13px 28px;
            border-radius: 10px;
            font-family: 'Irish Grover', cursive;
            font-size: 16px;
            transition: 0.3s;
        }

        .about-button:hover {
            background: #FFFFFF;
            transform: translateY(-3px);
        }

        @media (max-width: 768px) {
            .about-hero {
                padding: 55px 20px;
            }

            .about-hero h1 {
                font-size: 35px;
            }

            .about-cards {
                grid-template-columns: 1fr;
            }

            .about-section h2,
            .about-cta h2 {
                font-size: 25px;
            }
        }
    </style>
</head>

<body>

<?php include "../includes/navbar.php"; ?>

<!-- HERO -->
<section class="about-hero">
    <h1>ABOUT BOOKISSE</h1>

    <p>
        More than just a bookstore, Bookisse is a place where
        every reader can discover new stories, explore ideas,
        and find inspiration through books.
    </p>
</section>

<div class="about-container">

    <!-- OUR STORY -->
    <section class="about-section">
        <h2>Our Story</h2>

        <p>
            Bookisse was created to make discovering and purchasing
            books easier and more enjoyable. We believe that every
            book has something meaningful to offer, whether it is
            a new perspective, an unforgettable story, or valuable
            knowledge.
        </p>
    </section>

    <!-- OUR MISSION -->
    <section class="about-section">
        <h2>Our Mission</h2>

        <p>
            Our mission is to provide a convenient online bookstore
            where readers can explore different genres, discover
            their favorite books, and enjoy a simple shopping
            experience.
        </p>
    </section>

    <!-- WHY CHOOSE US -->
    <section class="about-section">

        <h2>Why Choose Bookisse?</h2>

        <div class="about-cards">

            <div class="about-card">
                <i class="fa-solid fa-book-open"></i>

                <h3>Various Collections</h3>

                <p>
                    Discover books from different genres,
                    including Fiction, Fantasy, Business,
                    Romance, and more.
                </p>
            </div>

            <div class="about-card">
                <i class="fa-solid fa-cart-shopping"></i>

                <h3>Easy Shopping</h3>

                <p>
                    Browse books, save your favorites,
                    and purchase your preferred titles
                    through a convenient online experience.
                </p>
            </div>

            <div class="about-card">
                <i class="fa-solid fa-heart"></i>

                <h3>For Every Reader</h3>

                <p>
                    Whether you enjoy fiction, personal
                    development, or business books,
                    there is always something new to explore.
                </p>
            </div>

        </div>

    </section>

    <!-- CTA -->
    <section class="about-cta">

        <h2>Find Your Next Story</h2>

        <p>
            Every page holds a story. Start discovering yours
            with Bookisse.
        </p>

        <a href="../index.php" class="about-button">
            Explore Books
            <i class="fa-solid fa-arrow-right"></i>
        </a>

    </section>

</div>
</body>
</html>