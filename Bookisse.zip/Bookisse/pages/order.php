
<?php
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

require "../config/database.php";

$user_id = (int) $_SESSION['user']['id'];

/* =========================
   CONFIRM RECEIVED
========================= */

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_received'])) {

    $order_id = (int) ($_POST['order_id'] ?? 0);

    if ($order_id <= 0) {
        echo "<script>
            alert('Invalid order!');
            window.location='order.php';
        </script>";
        exit;
    }

    mysqli_begin_transaction($conn);

    try {

        // Ambil dan kunci pesanan milik pembeli yang sedang login
        $stmt = mysqli_prepare($conn, "
            SELECT id, status
            FROM orders
            WHERE id = ?
            AND user_id = ?
            FOR UPDATE
        ");

        mysqli_stmt_bind_param($stmt, "ii", $order_id, $user_id);
        mysqli_stmt_execute($stmt);

        $result = mysqli_stmt_get_result($stmt);
        $order_check = mysqli_fetch_assoc($result);

        if (!$order_check) {
            throw new Exception("Order not found or you do not have permission.");
        }

        // Hanya pesanan shipped yang bisa diselesaikan
        if ($order_check['status'] !== 'shipped') {
            throw new Exception("Only shipped orders can be confirmed as received.");
        }

        // Ubah status menjadi complete
        $update_stmt = mysqli_prepare($conn, "
            UPDATE orders
            SET status = 'complete'
            WHERE id = ?
            AND user_id = ?
            AND status = 'shipped'
        ");

        mysqli_stmt_bind_param($update_stmt, "ii", $order_id, $user_id);
        mysqli_stmt_execute($update_stmt);

        if (mysqli_stmt_affected_rows($update_stmt) !== 1) {
            throw new Exception("Failed to confirm received order.");
        }

        mysqli_commit($conn);

        echo "<script>
            alert('Thank you! Your order has been completed successfully.');
            window.location='order.php';
        </script>";
        exit;

    } catch (Throwable $e) {

        mysqli_rollback($conn);

        echo "<script>
            alert(" . json_encode($e->getMessage()) . ");
            window.location='order.php';
        </script>";
        exit;
    }
}

/* =========================
   AMBIL DATA ORDERS
========================= */

$query = mysqli_prepare($conn, "
    SELECT *
    FROM orders
    WHERE user_id = ?
    ORDER BY created_at DESC
");

mysqli_stmt_bind_param($query, "i", $user_id);
mysqli_stmt_execute($query);

$orders = mysqli_stmt_get_result($query);

// FORMAT HARGA
function rupiah($number) {
    return 'Rp ' . number_format((float)$number, 2, '.', ',');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>BOOKISSE | My Orders</title>

<style>
* {
    box-sizing: border-box;
}

body {
    margin: 0;
    background: #2B1033;
    font-family: Arial, sans-serif;
    color: white;
}

.container {
    width: 90%;
    max-width: 1000px;
    margin: auto;
    padding: 40px 0;
}

h1 {
    color: #F4B43A;
    margin-bottom: 30px;
}

.order-card {
    background: #4B2154;
    padding: 25px;
    border-radius: 18px;
    margin-bottom: 20px;
}

.order-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid rgba(255,255,255,.15);
    padding-bottom: 15px;
    margin-bottom: 20px;
}

.order-id {
    font-size: 20px;
    font-weight: bold;
}

.order-date {
    color: #ddd;
}

.info {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 20px;
}

.info-box {
    background: #5C2A66;
    padding: 15px;
    border-radius: 10px;
}

.info-box span {
    display: block;
    color: #ccc;
    font-size: 14px;
    margin-bottom: 7px;
}

.total {
    color: #F4B43A;
    font-weight: bold;
}

.status {
    display: inline-block;
    padding: 7px 14px;
    border-radius: 20px;
    font-weight: bold;
    text-transform: capitalize;
}

.pending {
    background: #ffe8a3;
    color: #8a6200;
}

.waiting {
    background: #cce5ff;
    color: #12528a;
}

.paid {
    background: #b8f5c0;
    color: #176b27;
}

.rejected,
.cancelled {
    background: #ffd0d0;
    color: #a51d1d;
}

.processing {
    background: #b9dcff;
    color: #12528a;
}

.shipped {
    background: #d7c1ff;
    color: #54228f;
}

.complete,
.completed {
    background: #b8f5c0;
    color: #176b27;
}

.cancelled,
.canceled,
.rejected {
    background: #ffd0d0;
    color: #a51d1d;
}

.actions {
    margin-top: 20px;
}

.btn {
    display: inline-block;
    padding: 11px 20px;
    border-radius: 9px;
    text-decoration: none;
    font-weight: bold;
    margin-right: 8px;
    border: none;
    cursor: pointer;
    font-size: 14px;
}

.pay {
    background: #F4B43A;
    color: #2B1033;
}

.receipt-btn {
    background: white;
    color: #2B1033;
}

.confirm-btn {
    background: #28a745;
    color: white;
}

.empty {
    background: #4B2154;
    padding: 40px;
    border-radius: 18px;
    text-align: center;
}

.back {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    margin: 0 0 22px;
    padding: 11px 18px;
    background: #F4B43A;
    color: #2B1033;
    border-radius: 9px;
    text-decoration: none;
    font-weight: bold;
    transition: background .2s ease, transform .2s ease;
}

.back:hover {
    background: #ffd06b;
    transform: translateY(-1px);
}

/* RECEIPT MODAL */

.modal-backdrop {
    display: none;
    position: fixed;
    inset: 0;
    background: rgba(0,0,0,.75);
    z-index: 9999;
    justify-content: center;
    align-items: flex-start;
    padding: 35px 20px;
    overflow-y: auto;
}

.modal-backdrop.active {
    display: flex;
}

.receipt-modal {
    background: white;
    color: #2B1033;
    width: 100%;
    max-width: 550px;
    max-height: calc(100vh - 70px);
    overflow-y: auto;
    border-radius: 16px;
    padding: 30px;
    position: relative;
    margin: 0 auto;
}

.receipt-header {
    text-align: center;
    border-bottom: 2px dashed #ccc;
    padding-bottom: 20px;
    margin-bottom: 20px;
}

.receipt-header h2 {
    color: #4B2154;
    margin-bottom: 5px;
}

.receipt-header p {
    color: #777;
    margin: 5px 0;
}

.receipt-success {
    display: inline-block;
    background: #dff7e3;
    color: #176b27;
    padding: 8px 15px;
    border-radius: 20px;
    font-weight: bold;
    margin-top: 10px;
}

.receipt-details {
    margin-bottom: 20px;
}

.receipt-row {
    display: flex;
    justify-content: space-between;
    gap: 15px;
    margin: 12px 0;
    font-size: 14px;
}

.receipt-row span:first-child {
    color: #777;
}

.receipt-items {
    border-top: 1px solid #ddd;
    border-bottom: 1px solid #ddd;
    padding: 15px 0;
}

.receipt-item {
    display: flex;
    justify-content: space-between;
    gap: 15px;
    margin: 12px 0;
    font-size: 14px;
}

.receipt-total {
    display: flex;
    justify-content: space-between;
    font-size: 20px;
    font-weight: bold;
    color: #4B2154;
    margin-top: 20px;
}

.receipt-footer {
    text-align: center;
    color: #777;
    font-size: 13px;
    margin-top: 25px;
    border-top: 2px dashed #ccc;
    padding-top: 20px;
}

.receipt-actions {
    display: flex;
    gap: 10px;
    margin-top: 25px;
}

.receipt-actions button {
    flex: 1;
    padding: 13px;
    border: none;
    border-radius: 8px;
    font-weight: bold;
    cursor: pointer;
}

.print-btn {
    background: #F4B43A;
    color: #2B1033;
}

.close-btn {
    background: #eee;
    color: #333;
}

@media(max-width: 700px) {

    .info {
        grid-template-columns: 1fr;
    }

    .order-header {
        flex-direction: column;
        align-items: flex-start;
        gap: 8px;
    }

    .receipt-modal {
        padding: 20px;
    }
}

/* PRINT RECEIPT */

@page {
    size: A4 portrait;
    margin: 12mm;
}

@media print {

    html,
    body {
        margin: 0 !important;
        padding: 0 !important;
        width: 100% !important;
        height: auto !important;
        background: white !important;
        overflow: visible !important;
    }

    body > .container {
        display: block !important;
        width: 100% !important;
        max-width: none !important;
        margin: 0 !important;
        padding: 0 !important;
    }

    .container > * {
        display: none !important;
    }

    .container > .modal-backdrop.active {
        display: block !important;
        position: static !important;
        width: 100% !important;
        height: auto !important;
        min-height: 0 !important;
        margin: 0 !important;
        padding: 0 !important;
        background: white !important;
        overflow: visible !important;
    }

    .modal-backdrop.active .receipt-modal {
        display: block !important;
        position: relative !important;
        width: 110mm !important;
        max-width: 110mm !important;
        height: auto !important;
        max-height: none !important;
        margin: 0 auto !important;
        padding: 10mm !important;
        overflow: visible !important;
        border: none !important;
        border-radius: 0 !important;
        box-shadow: none !important;
        background: white !important;
        color: #2B1033 !important;
        font-family: Arial, sans-serif !important;
        font-size: 12px !important;
        break-inside: avoid !important;
        page-break-inside: avoid !important;
    }

    .receipt-modal * {
        font-family: Arial, sans-serif !important;
        box-sizing: border-box !important;
    }

    .receipt-actions {
        display: none !important;
    }

    .receipt-header,
    .receipt-details,
    .receipt-items,
    .receipt-total,
    .receipt-footer {
        break-inside: avoid !important;
        page-break-inside: avoid !important;
    }
}

/* STATUS TEXT */

.status,
.status.pending,
.status.waiting,
.status.paid,
.status.rejected,
.status.cancelled,
.status.processing,
.status.shipped,
.status.complete {
    color: #4B2154 !important;
}
</style>

</head>

<body>

<div class="container">

    <a href="profile.php" class="back">← Back to Profile</a>

    <h1>My Orders 📦</h1>

    <?php if (mysqli_num_rows($orders) == 0) { ?>

        <div class="empty">
            <h2>No Orders Yet</h2>
            <p>You haven't placed any orders.</p>

            <a href="../index.php" class="btn pay">
                Start Shopping
            </a>
        </div>

    <?php } else { ?>

        <?php while ($order = mysqli_fetch_assoc($orders)) { ?>

            <?php
            $payment_status = $order['payment_status'] ?? 'pending';

            $status_class = strtolower($order['status'] ?? 'pending');

            $payment_label = [
                'pending' => 'Waiting Payment',
                'waiting_verification' => 'Waiting Verification',
                'paid' => 'Paid',
                'rejected' => 'Rejected'
            ];

            $payment_class = [
                'pending' => 'pending',
                'waiting_verification' => 'waiting',
                'paid' => 'paid',
                'rejected' => 'rejected'
            ];

            $items_stmt = mysqli_prepare($conn, "
                SELECT
                    order_items.quantity,
                    order_items.price,
                    books.title
                FROM order_items
                JOIN books ON order_items.book_id = books.id
                WHERE order_items.order_id = ?
            ");

            mysqli_stmt_bind_param(
                $items_stmt,
                "i",
                $order['id']
            );

            mysqli_stmt_execute($items_stmt);

            $receipt_items = mysqli_stmt_get_result($items_stmt);
            ?>

            <div class="order-card">

                <div class="order-header">

                    <div class="order-id">
                        <?= htmlspecialchars(
                            $order['order_code'] ?? ('#' . $order['id']),
                            ENT_QUOTES,
                            'UTF-8'
                        ); ?>
                    </div>

                    <div class="order-date">
                        <?= date(
                            "d M Y H:i",
                            strtotime($order['created_at'])
                        ); ?>
                    </div>

                </div>

                <div class="info">

                    <div class="info-box">
                        <span>Total</span>

                        <div class="total">
                            <?= rupiah($order['total']); ?>
                        </div>
                    </div>

                    <div class="info-box">
                        <span>Payment</span>

                        <span class="status <?= $payment_class[$payment_status] ?? 'pending'; ?>">
                            <?= htmlspecialchars(
                                $payment_label[$payment_status] ?? ucfirst($payment_status)
                            ); ?>
                        </span>
                    </div>

                    <div class="info-box">
                        <span>Order Status</span>

                        <span class="status <?= htmlspecialchars($status_class); ?>">
                            <?= ucfirst(htmlspecialchars($order['status'])); ?>
                        </span>
                    </div>

                </div>

                <div class="actions">

                    <?php if ($payment_status === 'pending') { ?>

                        <a
                            href="payment.php?order_id=<?= (int)$order['id']; ?>"
                            class="btn pay"
                        >
                            Pay Now
                        </a>

                    <?php } ?>

                    <?php if ($payment_status === 'waiting_verification') { ?>

                        <span class="status waiting">
                            Waiting for Admin Verification
                        </span>

                    <?php } ?>

                    <?php if ($payment_status === 'rejected') { ?>

                        <span class="status rejected">
                            Payment Rejected — Please contact admin
                        </span>

                    <?php } ?>

                    <?php if ($payment_status === 'paid') { ?>

                        <button
                            type="button"
                            class="btn receipt-btn"
                            onclick="openReceipt('receipt-<?= (int)$order['id']; ?>')"
                        >
                            View Receipt
                        </button>

                    <?php } ?>

                    <!-- CONFIRM RECEIVED -->

                    <?php if (
                        $payment_status === 'paid' &&
                        $order['status'] === 'shipped'
                    ) { ?>

                        <form
                            method="POST"
                            style="display:inline-block;"
                            onsubmit="return confirmReceived();"
                        >

                            <input
                                type="hidden"
                                name="order_id"
                                value="<?= (int)$order['id']; ?>"
                            >

                            <button
                                type="submit"
                                name="confirm_received"
                                value="1"
                                class="btn confirm-btn"
                            >
                                <i class="fa-solid fa-check-circle"></i>
                                Confirm Received
                            </button>

                        </form>

                    <?php } ?>

                    <?php if ($order['status'] === 'complete') { ?>

                        <span class="status complete">
                            ✓ Order Completed
                        </span>

                    <?php } ?>

                </div>

            </div>

            <?php if ($payment_status === 'paid') { ?>

                <div
                    class="modal-backdrop"
                    id="receipt-<?= (int)$order['id']; ?>"
                    onclick="closeReceiptOutside(event, 'receipt-<?= (int)$order['id']; ?>')"
                >

                    <div class="receipt-modal">

                        <div class="receipt-header">

                            <h2>BOOKISSE</h2>

                            <p>Your Favorite Bookstore</p>

                            <div class="receipt-success">
                                ✓ PAYMENT SUCCESSFUL
                            </div>

                        </div>

                        <h3>Purchase Receipt</h3>

                        <div class="receipt-details">

                            <div class="receipt-row">
                                <span>Order Code</span>
                                <strong>
                                    <?= htmlspecialchars(
                                        $order['order_code'] ?? ('#' . $order['id'])
                                    ); ?>
                                </strong>
                            </div>

                            <div class="receipt-row">
                                <span>Order Date</span>
                                <strong>
                                    <?= date(
                                        "d M Y H:i",
                                        strtotime($order['created_at'])
                                    ); ?>
                                </strong>
                            </div>

                            <div class="receipt-row">
                                <span>Paid At</span>
                                <strong>
                                    <?= !empty($order['paid_at'])
                                        ? date(
                                            "d M Y H:i",
                                            strtotime($order['paid_at'])
                                        )
                                        : '-'; ?>
                                </strong>
                            </div>

                            <div class="receipt-row">
                                <span>Payment Method</span>

                                <strong>
                                    <?= htmlspecialchars(
                                        $order['payment_method'] ?? '-'
                                    ); ?>

                                    <?php if (!empty($order['payment_provider'])) { ?>
                                        - <?= htmlspecialchars(
                                            $order['payment_provider']
                                        ); ?>
                                    <?php } ?>
                                </strong>
                            </div>

                            <div class="receipt-row">
                                <span>Payment Status</span>
                                <strong style="color:#218838;">
                                    PAID
                                </strong>
                            </div>

                        </div>

                        <h3>Order Details</h3>

                        <div class="receipt-items">

                            <?php
                            mysqli_data_seek($receipt_items, 0);

                            while ($item = mysqli_fetch_assoc($receipt_items)) {
                            ?>

                                <div class="receipt-item">

                                    <div>
                                        <strong>
                                            <?= htmlspecialchars($item['title']); ?>
                                        </strong>

                                        <br>

                                        <small>
                                            <?= (int)$item['quantity']; ?>
                                            x <?= rupiah($item['price']); ?>
                                        </small>
                                    </div>

                                    <strong>
                                        <?= rupiah(
                                            $item['quantity'] * $item['price']
                                        ); ?>
                                    </strong>

                                </div>

                            <?php } ?>

                        </div>

                        <div class="receipt-total">
                            <span>Total Paid</span>

                            <span>
                                <?= rupiah($order['total']); ?>
                            </span>
                        </div>

                        <div class="receipt-footer">
                            Thank you for shopping at Bookisse!<br>
                            We hope you enjoy your books.
                        </div>

                        <div class="receipt-actions">

                            <button
                                type="button"
                                class="print-btn"
                                onclick="printReceipt()"
                            >
                                🖨 Print Receipt
                            </button>

                            <button
                                type="button"
                                class="close-btn"
                                onclick="closeReceipt('receipt-<?= (int)$order['id']; ?>')"
                            >
                                Close
                            </button>

                        </div>

                    </div>

                </div>

            <?php } ?>

            <?php
            mysqli_stmt_close($items_stmt);
            ?>

        <?php } ?>

    <?php } ?>

</div>

<script>

function confirmReceived() {
    return confirm(
        "Have you received your books in good condition? Once confirmed, this order will be completed."
    );
}

function openReceipt(id) {

    const modal = document.getElementById(id);

    if (modal) {
        modal.classList.add("active");
        document.body.style.overflow = "hidden";
    }
}

function closeReceipt(id) {

    const modal = document.getElementById(id);

    if (modal) {
        modal.classList.remove("active");
        document.body.style.overflow = "";
    }
}
 
function closeReceiptOutside(event, id) {

    if (event.target.id === id) {
        closeReceipt(id);
    }
}

function printReceipt() {
    window.print();
}

document.addEventListener("keydown", function(event) {

    if (event.key === "Escape") {

        document.querySelectorAll(".modal-backdrop.active")
            .forEach(function(modal) {
                closeReceipt(modal.id);
            });
    }
});

</script>

</body>
</html>
