<?php

session_start();

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

require "../config/database.php";

$user = $_SESSION['user'];
$user_id = $user['id'];


/* =========================
   CARI ADMIN
========================= */

$admin_query = mysqli_query(
    $conn,
    "SELECT id, name
     FROM users
     WHERE role = 'admin'
     LIMIT 1"
);

$admin = mysqli_fetch_assoc($admin_query);

if (!$admin) {
    die("Admin tidak ditemukan!");
}

$admin_id = $admin['id'];


/* =========================
   KIRIM PESAN
========================= */

if (isset($_POST['send_message'])) {

    $message = trim($_POST['message']);

    if (!empty($message)) {

        $message = mysqli_real_escape_string(
            $conn,
            $message
        );

        mysqli_query(
            $conn,
            "INSERT INTO messages
            (sender_id, receiver_id, message)
            VALUES
            ('$user_id', '$admin_id', '$message')"
        );

        header("Location: messages.php");
        exit;
    }
}


/* =========================
   AMBIL PERCAKAPAN
========================= */

$messages_query = mysqli_query(
    $conn,
    "
    SELECT
        messages.*,
        users.name AS sender_name
    FROM messages
    JOIN users
        ON messages.sender_id = users.id
    WHERE

        (messages.sender_id = '$user_id'
        AND messages.receiver_id = '$admin_id')

        OR

        (messages.sender_id = '$admin_id'
        AND messages.receiver_id = '$user_id')

    ORDER BY messages.created_at ASC
    "
);

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta
name="viewport"
content="width=device-width, initial-scale=1.0"
>

<title>BOOKISSE | Messages</title>

<link
rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"
>

<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    background: #2B1033;
    font-family: Arial, sans-serif;
    color: white;
}

.container {
    width: 90%;
    max-width: 850px;
    margin: auto;
    padding: 40px 0;
}

h1 {
    color: #F4B43A;
}

.subtitle {
    color: #ccc;
    margin-bottom: 30px;
}


/* CHAT BOX */

.chat-box {

    background: #4B2154;

    border-radius: 20px;

    padding: 25px;

    min-height: 450px;

    max-height: 550px;

    overflow-y: auto;

}


/* MESSAGE */

.message-row {

    display: flex;

    margin-bottom: 18px;

}

.message-row.me {
    justify-content: flex-end;
}

.message-row.admin {
    justify-content: flex-start;
}


.message {

    max-width: 70%;

    padding: 14px 18px;

    border-radius: 18px;

    line-height: 1.5;

}


.me .message {

    background: #F4B43A;

    color: #2B1033;

    border-bottom-right-radius: 3px;

}


.admin .message {

    background: #5C2A66;

    color: white;

    border-bottom-left-radius: 3px;

}


.message small {

    display: block;

    margin-top: 7px;

    font-size: 11px;

    opacity: 0.7;

}


/* EMPTY */

.empty {

    text-align: center;

    color: #ccc;

    margin-top: 170px;

}


/* FORM */

.message-form {

    display: flex;

    gap: 10px;

    margin-top: 20px;

}


.message-form textarea {

    flex: 1;

    resize: none;

    border: none;

    outline: none;

    padding: 15px;

    border-radius: 12px;

    font-family: Arial;

}


.message-form button {

    width: 60px;

    border: none;

    border-radius: 12px;

    background: #F4B43A;

    color: #2B1033;

    cursor: pointer;

    font-size: 20px;

}


/* BACK */

.back {

    display: inline-block;

    margin-top: 25px;

    color: white;

    text-decoration: none;

}


.back:hover {

    color: #F4B43A;

}

</style>

</head>


<body>

<div class="container">


<h1>
<i class="fa-solid fa-comments"></i>
Messages
</h1>


<p class="subtitle">

Chat directly with BOOKISSE Admin.

</p>


<div class="chat-box">


<?php if (mysqli_num_rows($messages_query) == 0) { ?>

    <div class="empty">

        <i
        class="fa-regular fa-comments"
        style="font-size:50px;"
        ></i>

        <p>

            No messages yet.

        </p>

        <small>

            Send a message to start a conversation with Admin.

        </small>

    </div>

<?php } ?>


<?php while ($row = mysqli_fetch_assoc($messages_query)) { ?>


    <?php

    $is_me =
        $row['sender_id'] == $user_id;

    ?>


    <div class="message-row <?= $is_me ? 'me' : 'admin'; ?>">


        <div class="message">


            <?= nl2br(
                htmlspecialchars($row['message'])
            ); ?>


            <small>

                <?= date(
                    "d M Y H:i",
                    strtotime($row['created_at'])
                ); ?>

            </small>


        </div>


    </div>


<?php } ?>

</div>

<form
method="POST"
class="message-form"
>

<textarea
name="message"
placeholder="Write your message..."
required
></textarea>

<button
type="submit"
name="send_message"
>
<i class="fa-solid fa-paper-plane"></i>

</button>

</form>

<a
href="profile.php"
class="back"
>

← Back to Profile

</a>

</div>

</body>

</html>