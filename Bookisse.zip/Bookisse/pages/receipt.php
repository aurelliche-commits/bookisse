<?php
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

require "../config/database.php";

$user_id = $_SESSION['user']['id'];

/* =========================
   CEK ORDER ID
========================= */

if (!isset($_GET['order_id']) || empty($_GET['order_id'])) {
    die("Order ID tidak ditemukan!");
}

$order_id = (int) $_GET['order_id'];


/* =========================
   AMBIL DATA ORDER
========================= */

$order_query = mysqli_query(
    $conn,
    "
    SELECT 
        orders.*,
        users.name,
        users.email
    FROM orders
    JOIN users
        ON orders.user_id = users.id
    WHERE orders.id='$order_id'
    AND orders.user_id='$user_id'
    "
);

if (!$order_query) {

    die(
        "Database Error: " .
        mysqli_error($conn)
    );

}

$order = mysqli_fetch_assoc($order_query);


/* =========================
   CEK ORDER
========================= */

if (!$order) {

    die("Order tidak ditemukan!");

}


/* =========================
   AMBIL ORDER ITEMS
========================= */

$items_query = mysqli_query(
    $conn,
    "
    SELECT
        order_items.*,
        books.title,
        books.author
    FROM order_items
    JOIN books
        ON order_items.book_id = books.id
    WHERE order_items.order_id='$order_id'
    "
);

?>
<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>BOOKISSE | Order Receipt</title>

<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    background: #2B1033;
    font-family: Arial, sans-serif;
    color: #2B1033;
}

.container {
    width: 90%;
    max-width: 700px;
    margin: 50px auto;
}

.receipt {
    background: white;
    border-radius: 20px;
    padding: 40px;
}

.logo {
    text-align: center;
    color: #2B1033;
    font-size: 35px;
    font-weight: bold;
}

.subtitle {
    text-align: center;
    color: #777;
    margin-bottom: 30px;
}

.status-box {
    padding: 15px;
    border-radius: 10px;
    text-align: center;
    font-weight: bold;
    margin-bottom: 30px;
}

.pending {
    background: #fff3cd;
    color: #856404;
}

.paid {
    background: #d4edda;
    color: #155724;
}

.info-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 15px;
}

.info-box {
    background: #f7f4f8;
    padding: 15px;
    border-radius: 10px;
}

.info-box small {
    color: #777;
}

.info-box strong {
    display: block;
    margin-top: 6px;
}

.items {
    margin-top: 30px;
    border-top: 1px solid #ddd;
}

.item {
    display: flex;
    justify-content: space-between;
    padding: 18px 0;
    border-bottom: 1px solid #ddd;
}

.item-name span {
    color: #777;
    font-size: 14px;
}

.total {
    display: flex;
    justify-content: space-between;
    margin-top: 25px;
    padding-top: 20px;
    border-top: 2px solid #2B1033;
    font-size: 22px;
    font-weight: bold;
}

.total-price {
    color: #D99A18;
}

.buttons {
    display: flex;
    gap: 15px;
    margin-top: 30px;
}

.btn {
    flex: 1;
    padding: 14px;
    border-radius: 10px;
    text-align: center;
    text-decoration: none;
    font-weight: bold;
    border: none;
    cursor: pointer;
}

.back {
    background: #2B1033;
    color: white;
}

.print {
    background: #F4B43A;
    color: #2B1033;
}

@media(max-width:600px) {

    .info-grid {
        grid-template-columns: 1fr;
    }

    .buttons {
        flex-direction: column;
    }

}

</style>

</head>

<body>

<div class="container">

<div class="receipt">

<div class="logo">

BOOKISSE

</div>

<div class="subtitle">

Order Details & Digital Receipt

</div>


<?php

$payment_status = strtolower(
    $order['payment_status'] ?? 'pending'
);

?>

<div class="status-box <?= $payment_status == 'paid' ? 'paid' : 'pending'; ?>">

<?php if ($payment_status == 'paid') { ?>

✓ PAYMENT SUCCESSFUL

<?php } else { ?>

⏳ PAYMENT PENDING

<?php } ?>

</div>


<div class="info-grid">

<div class="info-box">

<small>Order Code</small>

<strong>
    <?= htmlspecialchars(
        !empty($order['order_code'])
            ? $order['order_code']
            : '#' . $order['id'],
        ENT_QUOTES,
        'UTF-8'
    ); ?>
</strong>
</div>


<div class="info-box">

<small>Customer</small>

<strong>

<?= htmlspecialchars($order['name']); ?>

</strong>

</div>


<div class="info-box">

<small>Email</small>

<strong>

<?= htmlspecialchars($order['email']); ?>

</strong>

</div>


<div class="info-box">

<small>Payment Status</small>

<strong>

<?= ucfirst(
    htmlspecialchars($payment_status)
); ?>

</strong>

</div>


<div class="info-box">

<small>Payment Method</small>

<strong>

<?= !empty($order['payment_method'])
    ? htmlspecialchars($order['payment_method'])
    : 'Not Paid'; ?>

</strong>

</div>


<div class="info-box">

<small>Order Status</small>

<strong>

<?= ucfirst(
    htmlspecialchars($order['status'])
); ?>

</strong>

</div>


<div class="info-box">

<small>Order Date</small>

<strong>

<?= date(
    'd M Y H:i',
    strtotime($order['created_at'])
); ?>

</strong>

</div>


<div class="info-box">

<small>Paid At</small>

<strong>

<?php

if (!empty($order['paid_at'])) {

    echo date(
        'd M Y H:i',
        strtotime($order['paid_at'])
    );

} else {

    echo '-';

}

?>

</strong>

</div>

</div>


<h3>Order Items</h3>


<div class="items">

<?php while ($item = mysqli_fetch_assoc($items_query)) { ?>

<div class="item">

<div class="item-name">

<strong>

<?= htmlspecialchars($item['title']); ?>

</strong>

<br>

<span>

<?= htmlspecialchars($item['author']); ?>

× <?= $item['quantity']; ?>

</span>

</div>


<div>

Rp <?= number_format(
    $item['price'] * $item['quantity'],
    0,
    ',',
    '.'
); ?>

</div>

</div>

<?php } ?>

</div>


<div class="total">

<span>Total</span>

<span class="total-price">

Rp <?= number_format(
    $order['total'],
    0,
    ',',
    '.'
); ?>

</span>

</div>


<div class="buttons">

<a
    href="my_orders.php"
    class="btn back"
>

← My Orders

</a>


<button
    onclick="window.print()"
    class="btn print"
>

🖨 Print Receipt

</button>

</div>

</div>

</div>

</body>

</html>